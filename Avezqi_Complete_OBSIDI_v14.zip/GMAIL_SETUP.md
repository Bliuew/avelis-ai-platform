# Gmail sending over HTTPS — local implementation, not configured or deployed

The Render service is on its Free plan, which blocks standard SMTP ports. The local application now supports the Gmail API over HTTPS while preserving optional SMTP compatibility for other hosting environments. Gmail passwords and app passwords cannot authorize the Gmail API.

## Owner-controlled Google setup

1. In your own Google Cloud project, enable the Gmail API.
2. Configure Google OAuth consent for the application and create an OAuth web client. Follow Google's official web-server OAuth flow. Request only the Gmail sending scope: https://www.googleapis.com/auth/gmail.send . This does not require reading the inbox.
3. The Gmail account owner must personally authorize sending. Obtain offline access and a refresh token through Google's authorization-code flow using the client's registered redirect URI. Do not paste the client secret, refresh token or Gmail password into chat, GitHub files, browser URLs or application logs.
4. Configure these privately in Render's service Environment settings after reviewing the intended release:
   - AVELIS_MAIL_TRANSPORT = gmail_api
   - AVELIS_MAIL_FROM = the authorized Gmail sender or an approved send-as alias
   - AVELIS_GMAIL_CLIENT_ID = your OAuth client's identifier
   - AVELIS_GMAIL_CLIENT_SECRET = the client's secret
   - AVELIS_GMAIL_REFRESH_TOKEN = the owner's securely obtained refresh token
   - AVELIS_ORIGIN = the actual HTTPS origin of the application
5. Review Google's OAuth publishing/verification requirements. External OAuth apps in Testing can issue short-lived refresh tokens; a temporary testing authorization is not a durable production configuration. Confirm authorization lifetime and the intended account type using Google's documentation.
6. After approval to deploy the implementation, use a controlled test account to request verification. Confirm the API's acceptance status and actual arrival in the recipient mailbox. API acceptance alone is not a delivery guarantee. Verify the link, sign in, and test recovery.

## What the implementation does

Refreshes an access token through https://oauth2.googleapis.com/token, builds an RFC-compatible MIME message, encodes it using base64url and calls https://gmail.googleapis.com/gmail/v1/users/me/messages/send. It reports accepted_by_provider only when Gmail returns a message identifier. Missing configuration and provider errors are reported without exposing credentials. No SMTP fallback is attempted when Gmail API mode is selected.

All verification, recovery, request confirmations and booking notifications call the same mail transport. Browser code never receives Google credentials. No emails have been sent by this local implementation during preparation.

## Checks

python tests/test_gmail_transport.py verifies the transport with mocked provider responses, including refusal to fall back to SMTP. It does not verify live Google authorization or delivery. Account-security and existing operational regressions also pass locally.

Official references:
- https://developers.google.com/workspace/gmail/api/guides/sending
- https://developers.google.com/identity/protocols/oauth2/web-server
- https://render.com/docs/free
