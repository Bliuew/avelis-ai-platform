# Avëzqi OBSIDI readiness implementation

Local preparation only. No ZIP generation, repository push or deployment is authorized.

## Verified source and constraints

The starting point is the exact archive consumed by repository main commit `6e4b81e0c7bb635b44583a52911ff3bc127f3837`, Git blob `ceb14f79af8a78c38317434b921bde599caf46ce`. Its release is website/accounts v13. Render lists that commit as live and automatic deployments on main. Work stays in this isolated local preparation branch.

The existing Python/FastAPI/SQLite application includes shared sessions, invitation-based workspaces, separate customer accounts, seven specialist destinations, sixteen Mëvqi modules, eleven real phone catalogue entries, saved phones, an illustrative plan builder, organization-scoped business records, internal decision approvals, private incidents and scoped API identities. A feature page does not establish the full specialist service as operational.

Baseline tests: current v13 account behavior and saved-phone/plan-builder flows pass. The account test confirms verification is bypassed when email is unconfigured and an email-unbound first-owner code is printed to logs. Those behaviors need tightening for confidential investor access. Existing mail delivery and live sign-in are not yet verified. Render reports a free service; durable database storage, backups and restore are not established by that configuration.

## Priority order and acceptance

1. Preserve account/session architecture; require verification for new accounts, remove automatic email-unbound owner initialization, protect confidential documents with verified identity, explicit grants, expiry, revocation and audit logs. Retain existing records and sessions without an unreviewed destructive migration.
2. Add founder/company profile, public Investor Relations, partnership opportunities and persisted investor/partnership/support/document requests. Requests must never grant an account or document access automatically. Public financial information remains qualitative; the CAD 250,000 scenario stays illustrative and confidential.
3. Add a secure document room and operator review inbox, with genuine uploads/download authorization. The master plan exists; missing decks/forecasts are not invented.
4. Connect existing business operations through a saved customer case workflow, owner-approved internal preparation and real draft invoices; add organization documents, access lifecycle controls and in-app notices. No external purchase, carrier provisioning, payment or physical-security dispatch is simulated.
5. Expand Naëqo with verified Nothing/CMF entries and clearly scoped categories/service requests, preserving the existing phone browser, saved items and plan builder. Any product category without verified models must be represented as a requirements enquiry, not fictional stock.
6. Improve navigation/responsive layouts using the supplied enterprise references. Keep all five specialized platforms and seven capabilities visible. Preserve existing logos, campaign imagery, taglines, homepages and the integrated architecture.
7. Run meaningful functional/security regression tests and browser checks. Report every incomplete provider/infrastructure requirement; no blanket production-ready claim.

## Completion checkpoint

The scoped local v14 increment is implemented and tested. Naëqo now has 22 verified-image catalogue products across 10 categories, including 13 phones; the original financing destination is restored as a user-input estimate and enquiry. See OBSIDI_READINESS_REVIEW.md for exact scope, evidence and uncompleted production/provider requirements. No push, ZIP or deployment was performed.

## External dependencies and remaining implementation

Durable storage and tested backups; real mail transport and inbox-delivery test; approved AI/provider credentials; MFA/identity-provider and device-management integrations; carrier/number/calling/eSIM/internet/outage integrations; manufacturer/distributor authorizations; device fulfilment, repair and loaner operations; regulated payment infrastructure and validation of the proposed $1 fee; licensed physical-security operations and authorized monitoring integrations. These are distinct from locally working software records and interfaces.

## Content source

The current confidential Avezqi_Master_Business_Plan.pdf (2026–2029 working draft) was read. Founder qualifications and accelerator acceptance are supplied by Chinyere. Do not invent staff, customers, revenue, endorsements or financing awards. Maarah remains Sharim's parent. SleekBella and other ventures are excluded from this presentation.
