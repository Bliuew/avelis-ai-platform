# Avëzqi — professional website implementation review

This source build changes the actual website, account flows and settings. It is not a PDF mockup. No live deployment was performed for this increment.

## Design and service references

These references inform information architecture and customer journeys; their offers, claims, designs and functionality are not attributed to Avëzqi or copied as commercial availability.

- Mëvqi: Microsoft Teams collaboration and business communication — https://www.microsoft.com/en-ca/microsoft-teams/small-medium-business
- Naëqo: Bell's separate device, plan and financing journeys — https://www.bell.ca/Mobility/Smartphones_and_mobile_internet_devices and https://www.bell.ca/Mobility/Mobility-promotions/smartpay
- Sharim: clearly distinguish cards, wallets and payment methods — https://stripe.com/en-ca/payments/payment-methods
- Vëqzi / Ëzqir: identity, application policies and access boundaries — https://www.cloudflare.com/products/access/
- Account token handling: https://cheatsheetseries.owasp.org/cheatsheets/Forgot_Password_Cheat_Sheet.html

## Actual local changes

- Retains approved homepage hero and logos; adds practical product journeys, real Schedule links, product-specific request entry points and clear invitation/account steps.
- Six brand destinations keep their own colours, names, campaign assets and service descriptions. Proposed carrier, payment and specialist security services remain labelled accurately.
- Public account recovery and verification page uses expiring single-use tokens. Raw tokens are not stored in the account-token table, placed in query strings or returned by the API. Email links carry tokens in the fragment; the page removes the fragment and submits only on the user's action.
- Invitation sign-up creates a pending unverified account. The email must be verified before login or authenticated access. Passwords require at least 12 characters. Successful password recovery invalidates every existing session and outstanding account token.
- Resend and recovery responses do not confirm whether an account exists. Mail is attempted through the actual configured SMTP service. Verification/recovery email is not guaranteed delivered by an HTTP success.
- Product requests save independently from account approval. Failed/unconfigured request confirmations can be retried through resubmission without creating a duplicate request.
- Accept All, Reject All and Manage Preferences, saved choices, persistent Cookie settings and a consent-gated optional integration loader are present across audited pages and the workspace. Essential authentication cookies remain necessary. No optional tracker is currently installed.
- Versioned approved-logo filenames avoid reusing old logo URLs; document revalidation helps prevent stale asset references.

## Local verification

Passed: tests/test_app.py, tests/test_operational.py, tests/test_release.py, tests/test_account_security.py, tests/test_public_assets.py and tests/test_consent.cjs. JavaScript syntax checks passed for app.js, account/account.js, cookies-v2.js and consent.js. Synthetic test accounts and captured test SMTP calls are isolated from production. Actual SMTP delivery has not been tested.

## Release gates — not complete

1. Review actual responsive layout and controls in desktop and mobile browsers. Automated link and API checks are not browser acceptance.
2. Configure and verify real sender identity, SMTP delivery, verification and recovery email in staging. Existing users must verify their email under this build; deploying without mail readiness can prevent sign-in.
3. Confirm persistent storage and backup/restore on the actual hosting service.
4. Review migration of existing unverified accounts, resend rate limits and operational recovery procedures with the owner.
5. Complete privacy/terms and service-specific access review; verify separate specialist security infrastructure before enabling its capabilities.
6. Obtain the owner's explicit permission before modifying the live website or deploying.

The website is not a replacement for actual carrier contracts, payment processing, hardware engineering or independent identity/security implementation. No customer evidence, partnerships, prices outside the agreed proposed range or operational capabilities have been fabricated.
