# Avëzqi deployment package v13

Website v13. /product-release.json reports avezqi-website-v13 and /api/status reports avezqi-accounts-v13. Prepared for review; not deployed.

## What changed so it works on upload
- Site address: the server reads Render's own RENDER_EXTERNAL_URL automatically. You only need AVELIS_ORIGIN if you use a custom domain (for example https://www.yourdomain.com).
- Accounts without email: while email is not set up, new accounts are created already verified and can sign in straight away. Once the Gmail settings are added, verification turns back on automatically.
- First owner code: when the site starts with no accounts, it prints a one-time owner invitation code in the Render log.
- New features: Naëqo plan builder (/naeqo/plans/), Save buttons on every phone, a full My account dashboard (plan, saved phones, enquiries, profile, notifications, password, devices, data download), and a My account button in the header once signed in. The homepage tour and product experience stay as they were.

## Upload to GitHub
1. Extract this OUTER ZIP on your computer.
2. Put Avezqi_Render_Deploy.zip (this original downloaded archive) and the Dockerfile together in the repository root, replacing the old ones. Do not rename the archive or put it in a folder.
3. Commit. If automatic deploys are on, this starts a live deploy, so only commit when you are ready to release.

## Create your owner account
1. In Render, open the service, then Logs.
2. Find the box headed "FIRST OWNER INVITATION CODE". Copy the code.
3. On the website go to Avëzqi, choose Invitation code, and register with your email, a strong password (12+ characters) and that code.
4. That account becomes the owner and operator. The code works once and only while no account exists. Invite everyone else from inside the workspace.
Naëqo and Sharim visitors sign up without a code. Ëzqir has no public registration.

## Optional settings (Render, Environment)
- Email (verification and password recovery): AVELIS_MAIL_TRANSPORT=gmail_api, AVELIS_MAIL_FROM, AVELIS_GMAIL_CLIENT_ID, AVELIS_GMAIL_CLIENT_SECRET, AVELIS_GMAIL_REFRESH_TOKEN. See GMAIL_SETUP.md inside the application archive. Enter these in Render only, never in GitHub or chat.
- AVELIS_REQUIRE_EMAIL_VERIFICATION: true pauses sign-up until email works; false keeps verification off even with email set. Leave it unset for the automatic behaviour.
- AVELIS_ORIGIN: only for a custom domain.

## Things to know
- Without email, addresses are not confirmed and "forgot password" cannot send a link. Add the Gmail settings before inviting outside users.
- Render's free plan has no persistent disk. Each restart or redeploy starts with an empty database, so accounts disappear and a new first owner code is printed. For accounts that last, add a Render persistent disk mounted at /app/data (paid plan), keep a single instance, and back it up.
- This package contains no database, passwords, keys or invitation codes. Carrier and payment services need their own real provider connections; nothing here presents them as live.

After deploying, check /product-release.json, /api/status (email_verification, origin_configured), sign-up on Naëqo and Sharim, owner registration with the log code, building and saving a plan, saving a phone, My account, and sign-in on a phone.
