"""Website v13 features: Naëqo plan builder, saved phones, customer profile, data download, footer logo, tour kept."""
import json, re
from pathlib import Path
from test_app import client, request, server
PUBLIC = Path(__file__).resolve().parents[1] / 'public'


def run():
    c = client()
    opts = c.get('/api/naeqo/plan-options').json()
    assert opts['min'] == 25 and opts['max'] == 150 and opts['currency'] == 'CAD'
    q = lambda **d: request(client(), 'naeqo/plan-price', d)['monthly_cad']
    assert q(data='10', calling='canada', extras=[]) == 25
    assert q(data='50', calling='canada-us', extras=['hotspot']) == 60
    assert q(data='unlimited', calling='global', extras=['hotspot', 'roaming', 'device-care', 'home-internet']) == 150  # capped
    request(client(), 'naeqo/plan-price', dict(data='999', calling='canada', extras=[]), expected=400)
    request(client(), 'naeqo/plan-price', dict(data='10', calling='canada', extras=['hotspot', 'hotspot']), expected=400)
    # Profile needs sign-in.
    assert client().get('/api/customer/profile').status_code == 401
    original = server.configured_mail
    messages=[];sender=server.send_notice
    server.configured_mail = lambda: True
    server.send_notice=lambda recipient,subject,message:(messages.append(message) or 'accepted_by_mail_server')
    try:
        a = client()
        request(a, 'signup', dict(name='Ada Lovelace', email='ada13@example.com', password='NaeqoPassword2026!', product='Naëqo', terms=True))
        import re
        token=re.search(r'#token=([A-Za-z0-9_-]+)',messages[-1]).group(1)
        request(a,'account/verify',dict(token=token))
        request(a, 'login', {'email': 'ada13@example.com', 'password': 'NaeqoPassword2026!'})
    finally:
        server.configured_mail = original
        server.send_notice=sender
    csrf = a.get('/api/account/summary').json()['csrf']
    a.headers['X-CSRF-Token'] = csrf
    p = a.get('/api/customer/profile').json()
    assert p['revision'] == 0 and p['plan'] is None and p['saved_devices'] == []
    saved = request(a, 'customer/profile', dict(revision=0, plan=dict(data='50', calling='canada-us', extras=['hotspot'], sim='eSIM', monthly_cad=1), saved_devices=['iphone-17', 'pixel-10'], notifications={'new_phones': True}, name='Ada L.'))
    assert saved['plan']['monthly_cad'] == 60  # the server sets the price, not the browser
    assert saved['notifications'] == {'enquiry_updates': True, 'new_phones': True, 'offers': False} and saved['name'] == 'Ada L.'
    assert a.get('/api/account/summary').json()['name'] == 'Ada L.'
    request(a, 'customer/profile', dict(revision=0, saved_devices=[]), expected=409)  # stale revision
    request(a, 'customer/profile', dict(revision=1, saved_devices=['not-a-phone']), expected=400)
    request(a, 'customer/profile', dict(revision=1, saved_devices=['iphone-17'] * 2), expected=400)
    ex = a.get('/api/customer/export')
    assert ex.status_code == 200 and 'attachment' in ex.headers.get('content-disposition', '')
    data = json.loads(ex.text)
    assert data['account']['email'] == 'ada13@example.com' and data['preferences']['saved_devices'] == ['iphone-17', 'pixel-10']
    assert 'password' not in ex.text.lower()
    # Workspace data stays closed to customer accounts.
    assert a.get('/api/records').status_code in (403, 404)
    # Pages.
    plans = c.get('/naeqo/plans/').text
    assert 'id="plan-builder"' in plans and '/naeqo-tools.js' in plans and '/brand-auth.js' in plans
    assert '/naeqo-tools.js' in c.get('/naeqo/phones/').text and 'href="/naeqo/plans/"' in c.get('/naeqo/').text
    acct = c.get('/my-account/').text
    for marker in ['id="saved-phones"', 'id="plan-body"', 'id="notify-form"', '/api/customer/export', 'ditheka']:
        assert marker in acct, marker
    js = (PUBLIC / 'naeqo-tools.js').read_text() + (PUBLIC / 'my-account' / 'my-account.js').read_text()
    assert 'innerHTML' not in js
    # Homepage tour and the product experience are kept.
    assert 'id="tour"' in c.get('/').text and c.get('/experience/').status_code == 200
    # Every footer shows the Ditheka logo and tagline.
    for f in PUBLIC.rglob('*.html'):
        m = re.search(r'<footer.*?</footer>', f.read_text(), re.S)
        if m:
            assert re.search(r'<img[^>]*Ditheka', m.group(0)) and 'Belong. Connect For A Smarter Tomorrow' in m.group(0), f
    print('PASS: plan builder prices (server-set, $25-$150 CAD cap, invalid options refused); customer profile saves plan, up to six phones, notifications and name with revision checks; data download; tour and experience kept; Ditheka logo in every footer.')


if __name__ == '__main__':
    run()
