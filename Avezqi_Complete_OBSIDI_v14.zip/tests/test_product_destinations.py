"""Regression checks for the broken product-browsing journeys reported by the owner."""
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlsplit
import json
from test_app import client
ROOT=Path(__file__).resolve().parents[1]
class Page(HTMLParser):
 def __init__(self):super().__init__();self.urls=[];self.ids=set();self.links=[]
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  if a.get('id'):self.ids.add(a['id'])
  for key in ['href','src']:
   if a.get(key,'').startswith('/'):self.urls.append(a[key])
  if tag=='a':self.links.append(a)
def run():
 c=client();mapping=json.loads((ROOT/'public/feature-destinations.json').read_text());assert len(mapping['mevqi'])==16 and len(mapping['avezqi'])==7
 pages=[p for brand in mapping for p in (ROOT/'public'/brand).rglob('*.html')];seen=set()
 for p in pages:
  route='/'+str(p.relative_to(ROOT/'public')).replace('index.html','');r=c.get(route);assert r.status_code==200,route
  assert '/cookies-v2.js' in r.text and '/consent.js' in r.text,route
  parser=Page();parser.feed(r.text)
  assert all(a.get('href')!='#' for a in parser.links),route
  for u in parser.urls:
   if u in seen:continue
   seen.add(u);reply=c.get(u);assert reply.status_code==200,(route,u,reply.status_code)
   fragment=urlsplit(u).fragment
   if fragment and not u.startswith('/app.html#'):
    target=Page();target.feed(reply.text);assert fragment in target.ids,(route,u)
 catalog=c.get('/naeqo/phones/').text
 for key in ['apple','samsung','google']:
  assert '/naeqo/phones/'+key+'/' in catalog
  assert c.get('/naeqo/phones/'+key+'/').status_code==200
 for item in json.loads((ROOT/'public/device-catalog.json').read_text()):
  assert c.get('/naeqo/phones/'+item['id']+'/').status_code==200
  image=c.get(item['image']);assert image.status_code==200 and len(image.content)>1000
 mevqi=c.get('/mevqi/').text
 for title,path in mapping['mevqi'].items():assert path in mevqi,title
 assert '/app.html#relations' in c.get(mapping['mevqi']['Relations']).text
 assert '/app.html#schedule' in c.get(mapping['mevqi']['Schedule']).text
 for path in mapping['ezqir'].values():
  assert 'data-auth=' not in c.get(path).text
 print('PASS:',len(pages),'brand/detail pages and',len(seen),'internal links/assets; 16 linked Mëvqi modules, seven specialists, five manufacturer labels, thirteen image-backed phone models, protected workspace links and restricted Ëzqir.')
if __name__=='__main__':run()
