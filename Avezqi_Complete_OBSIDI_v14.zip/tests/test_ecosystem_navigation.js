'use strict';
const fs=require('fs'),vm=require('vm'),assert=require('assert');
let destination='';const replies={
 'account/summary':{name:'Test Owner',email:'owner@example.com',organization:'Test Org',role:'owner',email_verified:true},
 team:[{name:'Test Owner',email:'owner@example.com',role:'owner'}],audit:[{created:'2026-11-21',action:'Saved contact',actor:'Test Owner'}],
 'records/integrations':[], 'naeqo/options':{accepting_enquiries:true}, 'naeqo/operations':[]
};
const calls=[];const ctx={render:async v=>({html:'Existing '+v,bind:()=>{ctx.originalBound=true}}),head:(t,s)=>`<h1>${t}</h1><p>${s}</p>`,panel:(t,s)=>`<section><h2>${t}</h2>${s}</section>`,metric:(t,n)=>t+n,table:(h,r)=>JSON.stringify({h,r}),esc:s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])),me:{role:'owner'},view:'worlds',api:async p=>{calls.push(p);assert(p in replies,'Unexpected API '+p);return replies[p]},go:v=>{destination=v},document:{querySelectorAll:()=>[]},console};
vm.createContext(ctx);vm.runInContext(fs.readFileSync('public/ecosystem-workspace.js','utf8'),ctx);
(async()=>{
 assert(destination==='worlds','Loaded sessions refresh after the extension initializes');
 const worlds=await ctx.render('worlds');for(const id of ['avezqi','mevqi','naeqo','sharim','veqzi','ezqir']){assert(worlds.html.includes(`data-workspace-tool="${id}"`));const page=await ctx.render(id);assert(page.html.includes(`aria-label="Connected workspaces"`));assert(!page.html.includes('under development'));assert(typeof page.bind==='function');}
 assert((await ctx.render('mevqi')).html.includes('data-workspace-tool="schedule"'));
 assert((await ctx.render('sharim')).html.includes('Existing sharim'));(await ctx.render('sharim')).bind();assert(ctx.originalBound);
 assert((await ctx.render('naeqo')).html.includes('/naeqo/operations/'));
 ctx.me.role='member';calls.length=0;assert((await ctx.render('ezqir')).html.includes('Restricted workspace'));assert(calls.length===0);assert(!(await ctx.render('naeqo')).html.includes('/naeqo/operations/'));
 const publicAuth=fs.readFileSync('public/brand-auth.js','utf8');assert(publicAuth.includes("s.account_type==='customer'?'/my-account/':'/app.html#'+workspace"));for(const flow of ["kind==='request'","kind==='code'","kind==='signup'","kind==='signin'"])assert(publicAuth.includes(flow));
 console.log('PASS: six shared-session brand destinations, existing tool links and Sharim behavior, contextual sign-in redirect, customer boundary and restricted owner navigation.');
})().catch(e=>{console.error(e);process.exitCode=1});
