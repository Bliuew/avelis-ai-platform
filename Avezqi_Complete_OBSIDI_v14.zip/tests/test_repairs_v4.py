"""Repair build v4 checks. All email is MOCKED (captured in-process); no provider is contacted."""
from test_app import client, user, request, server
from concurrent.futures import ThreadPoolExecutor
import re, time, secrets


def mail_capture():
    box = []
    def capture(recipient, subject, message):
        box.append((recipient, subject, message)); return 'accepted_by_provider'
    return box, capture


def invite_for(address):
    code = secrets.token_urlsafe(24)
    with server.db() as c:
        c.execute('INSERT INTO invites VALUES(?,?,?,?,0)', (server.digest(code), None, address, int(time.time()) + 3600))
    return code


def registration_preserves_invitation_without_mail():
    code = invite_for('paused@example.com')
    original = server.configured_mail
    server.configured_mail = lambda: False
    import os
    os.environ['AVELIS_REQUIRE_EMAIL_VERIFICATION'] = 'true'  # v13: the pause applies when verification is forced on
    try:
        reply = client().post('/api/register', json=dict(email='paused@example.com', password='PausedPassword2026!', name='Paused', company='Paused Co', invite=code))
        assert reply.status_code == 503 and 'has not been used' in reply.json()['detail']
    finally:
        server.configured_mail = original
        os.environ.pop('AVELIS_REQUIRE_EMAIL_VERIFICATION', None)
    with server.db() as c:
        assert c.execute('SELECT used FROM invites WHERE token=?', (server.digest(code),)).fetchone()['used'] == 0
        assert c.execute("SELECT 1 FROM users WHERE email='paused@example.com'").fetchone() is None
    assert client().get('/api/status').json()['mail'] in ('configured', 'not_configured')
    # The same invitation works once a sender is configured (mocked).
    m = user(client(), 'paused@example.com', 'Paused Co', code)
    assert m['org_name'] == 'Paused Co'


def account_settings():
    a = client(); me = user(a, 'settings@example.com', 'Settings Co')
    other = client(); request(other, 'login', dict(email='settings@example.com', password='TestPassword2026!'))
    summary = a.get('/api/account/summary').json()
    assert summary['email'] == 'settings@example.com' and summary['active_sessions'] == 2 and summary['organization'] == 'Settings Co'
    # Missing CSRF header is refused.
    assert a.post('/api/account/password', json=dict(current='TestPassword2026!', password='ChangedPassword2026!'), headers={'X-CSRF-Token': 'wrong'}).status_code == 403
    request(a, 'account/password', dict(current='not-the-password', password='ChangedPassword2026!'), expected=400)
    request(a, 'account/password', dict(current='TestPassword2026!', password='short'), expected=400)
    # Outstanding recovery link must stop working after a password change.
    box, capture = mail_capture(); orig, origc = server.send_notice, server.configured_mail
    server.send_notice = capture; server.configured_mail = lambda: True
    try:
        request(client(), 'account/forgot', {'email': 'settings@example.com'})
    finally:
        server.send_notice, server.configured_mail = orig, origc
    stale = re.search(r'#token=([A-Za-z0-9_-]+)', box[-1][2]).group(1)
    request(a, 'account/password', dict(current='TestPassword2026!', password='ChangedPassword2026!'))
    assert a.get('/api/me').status_code == 200, 'current session continues'
    assert other.get('/api/me').status_code == 401, 'other sessions signed out'
    request(client(), 'account/reset', dict(token=stale, password='HijackPassword2026!'), expected=400)
    request(client(), 'login', dict(email='settings@example.com', password='TestPassword2026!'), expected=401)
    request(client(), 'login', dict(email='settings@example.com', password='ChangedPassword2026!'))
    request(a, 'account/sessions/revoke', {})
    assert a.get('/api/me').status_code == 401
    with server.db() as c:
        assert c.execute('SELECT COUNT(*) FROM sessions WHERE user=?', (me['id'],)).fetchone()[0] == 0


def scheduling():
    owner = client(); host = user(owner, 'host@example.com', 'Schedule Co')
    first = request(owner, 'ama/events', dict(title='Discovery', duration=30, link=''))['id']
    second = request(owner, 'ama/events', dict(title='Follow-up', duration=30, link=''))['id']
    start = int(time.time()) + 7200
    for ev in (first, second):
        request(owner, 'ama/events/' + ev + '/slots', dict(host=host['id'], start=start))
    box, capture = mail_capture(); orig = server.send_notice; server.send_notice = capture
    try:
        def reserve(i):
            ev = first if i % 2 == 0 else second
            return client().post('/api/booking/' + ev, json=dict(name='Synthetic ' + str(i), email=f'c{i}@example.com', start=start, consent=True, timezone='America/Toronto'))
        with ThreadPoolExecutor(max_workers=8) as pool:
            results = list(pool.map(reserve, range(8)))
        codes = sorted(r.status_code for r in results)
        assert codes == [200] + [409] * 7, codes  # one host, one time: exactly one booking across both pages
        win = next(r.json() for r in results if r.status_code == 200)
        assert win['cancel_token'] and win['host'] == host['name']
        sent = next(x for x in box if x[0].startswith('c') and 'confirmed' in x[1])
        assert 'America/Toronto' in sent[2] and 'UTC' in sent[2] and '/book/?cancel=1#token=' in sent[2]
        with server.db() as c:
            assert c.execute('SELECT token FROM ama_booking_cancel WHERE token=?', (win['cancel_token'],)).fetchone() is None, 'raw token not stored'
        assert client().get('/api/booking/' + first).json()['slots'] == []
        request(client(), 'booking-cancel', {'token': 'not-a-real-token-value'}, expected=400)
        request(client(), 'booking-cancel', {'token': win['cancel_token']})
        request(client(), 'booking-cancel', {'token': win['cancel_token']}, expected=400)  # single use
        assert client().get('/api/booking/' + first).json()['slots'] == [start], 'availability restored'
        assert any('cancelled by client' in x[1] for x in box), 'host notified (mocked)'
        # Invalid time zone falls back to UTC rather than failing.
        again = request(client(), 'booking/' + first, dict(name='Zone', email='zone@example.com', start=start, consent=True, timezone='Not/AZone'))
        assert 'Not/AZone' not in box[-2][2]
        # Host cancels; the customer's link then refuses.
        request(owner, 'ama/bookings/' + again['id'], dict(status='Cancelled', meeting_link=''))
        request(client(), 'booking-cancel', {'token': again['cancel_token']}, expected=400)
        # A link cannot cancel a meeting that has started.
        late = request(client(), 'booking/' + first, dict(name='Late', email='late@example.com', start=start, consent=True))
        with server.db() as c:
            c.execute('UPDATE ama_booking_cancel SET expires=? WHERE token=?', (int(time.time()) - 1, server.digest(late['cancel_token'])))
        request(client(), 'booking-cancel', {'token': late['cancel_token']}, expected=400)
        # Another tenant cannot see or manage these bookings.
        outsider = client(); user(outsider, 'outsider@example.com', 'Other Co')
        assert outsider.get('/api/ama/schedule').json()['bookings'] == []
        request(outsider, 'ama/bookings/' + late['id'], dict(status='Cancelled', meeting_link=''), expected=404)
    finally:
        server.send_notice = orig


def product_requests():
    box, capture = mail_capture(); orig, origc = server.send_notice, server.configured_mail
    server.send_notice = capture; server.configured_mail = lambda: True
    try:
        base = dict(name='Synthetic', company='Synthetic Co', email='limit@example.com', note='', consent=True)
        reply = request(client(), 'product-interest', {**base, 'product': 'Mëvqi'})
        assert reply['product'] == 'Mëvqi' and box[-1][1] == 'Mëvqi — request received' and 'not an approval' in box[-1][2]
        assert 'Amā' not in box[-1][2]
        request(client(), 'product-interest', {**base, 'product': 'Ëzqir'}, expected=400)
        request(client(), 'product-interest', {**base, 'consent': False, 'product': 'Naëqo'}, expected=400)
        request(client(), 'product-interest', {**base, 'email': 'not-an-email', 'product': 'Naëqo'}, expected=400)
        for product in ['Naëqo', 'Sharim', 'Vëqzi', 'Avëzqi']:
            request(client(), 'product-interest', {**base, 'product': product})
        with server.db() as c:
            c.execute("DELETE FROM limits WHERE key LIKE 'product-interest:%'")  # isolate the per-email limit from the per-IP limit
        request(client(), 'product-interest', {**base, 'product': 'Sharim'}, expected=429)
    finally:
        server.send_notice, server.configured_mail = orig, origc
    with server.db() as c:  # fresh connection: persisted rows; internal keys unchanged
        rows = {r['product'] for r in c.execute("SELECT product FROM product_requests WHERE email='limit@example.com'")}
    assert rows == {'Amā', 'Naëqo', 'Sharim', 'Kavéra', 'Avelis AI'}, rows


def run():
    registration_preserves_invitation_without_mail()
    account_settings()
    scheduling()
    product_requests()
    print('PASS: invitation preserved when mail is unconfigured; change password (CSRF, current password, other sessions and recovery links revoked); sign out everywhere; account summary; 8 concurrent bookings across two pages for one host -> exactly one; customer cancellation (hashed, single-use, expires at start, refused after host cancel); time-zone confirmation with UTC; tenant isolation; product requests persisted with internal keys, public names in email, Ëzqir refused, per-email limit. Email MOCKED.')


if __name__ == '__main__':
    run()
