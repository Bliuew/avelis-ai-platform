'use strict';
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const replies={
 'connected-overview':{counts:{contacts:0,tasks:0,cases:0,invoices:0}},notifications:[],
 'platform/readiness':{operator:true,mail_configured:false,naeqo_configured:false},
 'customer-workflows':[{id:'case',name:'Test case',contact:'c',device:'iphone-17',stage:'Captured',revision:1,history:[]}],
 'records/contacts':[{id:'c',name:'Customer'}],team:[{id:'u',name:'Owner'}],
 'mevqi/documents':[], 'identity/overview':{members:[{id:'u',name:'Owner',email:'owner@example.com',role:'owner',suspended:false}],mfa:'Not connected'},
 'ezqir/register':[], 'operator/enquiries':[], 'operator/access-requests':[],
 'records/payment_requests':[],'records/benefit_rules':[],'records/merchants':[{id:'m',name:'Merchant'}], 'identity/devices':[]
};
const elems=new Map(),element=id=>{if(!elems.has(id))elems.set(id,{querySelector:()=>({disabled:false}),elements:{},reportValidity:()=>true});return elems.get(id);};
const ctx={render:async v=>({html:'Existing '+v}),navs:[],specs:{},field:(...x)=>x,editor:async()=>({html:'Merchant editor',bind:()=>{}}),head:(a,b)=>a+b,panel:(a,b)=>a+b,table:(a,b)=>JSON.stringify([a,b]),metric:(a,b)=>a+b,money:n=>String(n),esc:s=>String(s??''),me:null,view:'worlds',api:async p=>{assert(p in replies,'Unexpected API '+p);return replies[p]},fetch:async()=>({json:async()=>JSON.parse(fs.readFileSync('public/device-catalog.json'))}),go:()=>{},toast:()=>{},ecosystemHeader:x=>x,ecosystemLinks:x=>JSON.stringify(x),ecosystemBind:()=>{},document:{querySelectorAll:()=>[]},$:element,console};
vm.createContext(ctx);vm.runInContext(fs.readFileSync('public/obsidi-workspace.js','utf8'),ctx);ctx.me={id:'u',role:'owner',org_name:'Test organization'};
(async()=>{for(const v of ['connected-overview','customer-workflow','documents','identity','security-register','enquiries','notifications','merchants','payment-requests','benefit-rules','device-inventory']){const r=await ctx.render(v);assert(r.html.length>10,v);assert(!r.html.includes('undefined'),v);if(r.bind)r.bind();}
for(const v of ['worlds','avezqi','mevqi','naeqo','ezqir','veqzi','sharim'])assert((await ctx.render(v)).html.includes('Existing '+v));ctx.me.role='member';assert((await ctx.render('identity')).html.includes('owners'));assert((await ctx.render('device-inventory')).html.includes('owners'));replies['platform/readiness'].operator=false;assert((await ctx.render('enquiries')).html.includes('operator'));assert((await ctx.render('security-register')).html.includes('Private operator'));console.log('PASS: 11 new workspace screens render and bind; preserved brand screens and restricted role views.');})().catch(e=>{console.error(e);process.exitCode=1});
