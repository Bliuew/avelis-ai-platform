from test_app import client, user, server

def run():
    owner = client()
    user(owner, 'mail-owner@example.com', 'Mail checks')
    original = server.configured_mail
    server.configured_mail = lambda: False
    try:
        with server.db() as connection:
            before = connection.execute('SELECT COUNT(*) FROM account_tokens').fetchone()[0]
        for action in ['resend', 'forgot']:
            replies = [client().post('/api/account/' + action, json={'email': address})
                       for address in ['mail-owner@example.com', 'unknown-mail@example.com']]
            assert all(reply.status_code == 503 for reply in replies)
            assert replies[0].json() == replies[1].json()
            assert 'not configured' in replies[0].json()['detail']
        with server.db() as connection:
            assert connection.execute('SELECT COUNT(*) FROM account_tokens').fetchone()[0] == before
    finally:
        server.configured_mail = original
    print('PASS: unavailable mail reports 503 uniformly, preserves account privacy and creates no unusable tokens.')

if __name__ == '__main__':
    run()
