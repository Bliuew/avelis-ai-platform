from test_app import server
from unittest.mock import patch
import io,json,base64,urllib.parse
from email import policy
from email.parser import BytesParser

def run():
 config={'AVELIS_MAIL_TRANSPORT':'gmail_api','AVELIS_GMAIL_CLIENT_ID':'synthetic-client','AVELIS_GMAIL_CLIENT_SECRET':'synthetic-secret','AVELIS_GMAIL_REFRESH_TOKEN':'synthetic-refresh','AVELIS_MAIL_FROM':'sender@example.com'}
 requests=[]
 def provider(request,timeout):
  requests.append(request)
  if request.full_url=='https://oauth2.googleapis.com/token':return io.BytesIO(json.dumps({'access_token':'synthetic-access-token'}).encode())
  assert request.full_url=='https://gmail.googleapis.com/gmail/v1/users/me/messages/send'
  return io.BytesIO(json.dumps({'id':'synthetic-message-id'}).encode())
 with patch.dict(server.os.environ,config),patch.object(server.urllib.request,'urlopen',side_effect=provider),patch.object(server.smtplib,'SMTP',side_effect=AssertionError('SMTP must not run')):
  assert server.configured_mail()
  assert server.send_notice('recipient@example.com','Synthetic verification','Synthetic message body')=='accepted_by_provider'
  assert len(requests)==2 and all(r.full_url.startswith('https://') for r in requests)
  form=urllib.parse.parse_qs(requests[0].data.decode());assert form['grant_type']==['refresh_token']
  encoded=json.loads(requests[1].data)['raw'];msg=BytesParser(policy=policy.default).parsebytes(base64.urlsafe_b64decode(encoded));assert msg['To']=='recipient@example.com' and msg['Subject']=='Synthetic verification'
 with patch.dict(server.os.environ,config),patch.object(server.urllib.request,'urlopen',side_effect=OSError('Synthetic failure')):
  assert server.send_notice('recipient@example.com','Test','Test')=='send_failed'
 with patch.dict(server.os.environ,{**config,'AVELIS_GMAIL_REFRESH_TOKEN':''}):
  assert not server.configured_mail() and server.send_notice('recipient@example.com','Test','Test')=='not_configured'
 print('PASS: Gmail HTTPS OAuth refresh, MIME/base64url message, confirmed provider acceptance, no SMTP fallback, safe failures and missing configuration. Provider network calls mocked; no email sent.')
if __name__=='__main__':run()
