from test_app import client,server,user,request
from concurrent.futures import ThreadPoolExecutor
import os,time,json,secrets

def run():
 owner=client();other=client();member=client();anon=client()
 a=user(owner,'founder-product@example.com','Operating Company');b=user(other,'other-product@example.com','Other Company')
 server.configure_operator(a['email'])
 invite=request(owner,'invite',{'email':'member-product@example.com'})['invite'];user(member,'member-product@example.com','',invite)
 os.environ.pop('AVELIS_NAEQO_ORG_ID',None)
 assert anon.get('/api/platform/readiness').status_code==401
 assert other.post('/api/platform/naeqo/enable',json={}).status_code==403
 assert member.post('/api/platform/naeqo/enable',json={}).status_code==403
 assert owner.get('/api/platform/readiness').json()['operator'] is True
 request(owner,'platform/naeqo/enable',{});assert anon.get('/api/naeqo/options').json()['accepting_enquiries'] is True
 enquiry={'service':'Device enquiry','device':'pixel-10','storage':'128 GB','name':'Customer','email':'customer-product@example.com','consent':True,'access_key':secrets.token_hex(32)}
 q=request(anon,'naeqo/requests',enquiry)['request'];assert owner.get('/api/naeqo/operations').json()[0]['id']==q['id']
 rid=request(member,'avezqi/decisions',{'name':'Review customer connectivity request','reason':'Review recorded enquiry '+q['id']})['id']
 for revision in [1,2,3]:request(member,'avezqi/decisions/'+rid+'/advance',{'revision':revision,'note':'Reviewed evidence for this step.'})
 request(member,'avezqi/decisions/'+rid+'/advance',{'revision':4,'note':'Approve'},expected=403)
 request(owner,'avezqi/decisions/'+rid+'/advance',{'revision':4,'note':'Owner approves internal task.'})
 clones=[]
 for _ in range(2):
  c=client();c.cookies.update(owner.cookies);c.headers['X-CSRF-Token']=a['csrf'];clones.append(c)
 with ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(lambda c:c.post('/api/avezqi/decisions/'+rid+'/advance',json={'revision':5,'note':'Execute approved internal action.'}),clones))
 assert sorted(r.status_code for r in results)==[200,409]
 x=request(owner,'avezqi/decisions/'+rid+'/advance',{'revision':6,'note':'Checked task persisted.'});assert x['stage']=='Verify'
 assert any(t['id']==x['task'] for t in member.get('/api/records/tasks').json())
 assert other.get('/api/avezqi/decisions').json()==[]
 request(other,'avezqi/decisions/'+rid+'/advance',{'revision':7,'note':'Other'},expected=404)
 scenario=request(member,'avezqi/scenarios',{'name':'Business assumption','baseline':1000,'change':10,'cost':600,'assumption':'10 percent illustrative increase.'});assert scenario['projected']==1100 and scenario['projected_margin']==500
 request(owner,'avezqi/scenarios',{'name':'Invalid','baseline':100,'change':-101,'cost':20,'assumption':'Invalid'},expected=400)
 knowledge=request(member,'mevqi/knowledge',{'name':'Customer procedure','text':'Review the customer enquiry before replying.'});assert owner.get('/api/mevqi/knowledge').json()[0]['id']==knowledge['id']
 assert other.get('/api/mevqi/knowledge').json()==[]
 preferences=owner.get('/api/sharim/preferences').json();modules=[{**m,'budget_cad':100} for m in preferences['modules']]
 request(owner,'sharim/preferences',{'modules':modules,'revision':0});assert sum(m['budget_cad'] for m in owner.get('/api/sharim/preferences').json()['modules'])==400
 assert all(m['budget_cad']==0 for m in other.get('/api/sharim/preferences').json()['modules'])
 request(owner,'sharim/preferences',{'modules':modules,'revision':0},expected=409)
 assert owner.post('/api/sharim/preferences',json={'modules':modules,'revision':1},headers={'X-CSRF-Token':'bad'}).status_code==403
 request(owner,'veqzi/agents',{'name':'Invalid scope','scopes':[{}]},expected=400)
 agent=request(owner,'veqzi/agents',{'name':'Tasks integration','scopes':['tasks:create']});key=agent['token'];assert 'token' not in owner.get('/api/veqzi/agents').json()[0]
 assert member.get('/api/veqzi/agents').status_code==403
 request(other,'veqzi/agents/'+agent['id']+'/revoke',{},expected=404)
 bearer=client();bearer.headers['Authorization']='Bearer '+key
 assert bearer.get('/api/veqzi/agent/contacts').status_code==403
 task=bearer.post('/api/veqzi/agent/tasks',json={'name':'Authorized agent task'},headers={'Origin':'https://authorized-agent.example'});assert task.status_code==200,task.text
 assert any(t['id']==task.json()['id'] for t in owner.get('/api/records/tasks').json())
 assert not any(t['id']==task.json()['id'] for t in other.get('/api/records/tasks').json())
 request(owner,'veqzi/agents/'+agent['id']+'/revoke',{});assert bearer.post('/api/veqzi/agent/tasks',json={'name':'Denied'}).status_code==401
 with server.db() as c:assert c.execute('SELECT 1 FROM veqzi_agents WHERE token_hash=?',(key,)).fetchone() is None
 expired=request(owner,'veqzi/agents',{'name':'Expired integration','scopes':['contacts:read']})
 with server.db() as c:c.execute('UPDATE veqzi_agents SET expires=? WHERE id=?',(int(time.time())-1,expired['id']))
 bearer.headers['Authorization']='Bearer '+expired['token'];assert bearer.get('/api/veqzi/agent/contacts').status_code==401
 incident=request(owner,'ezqir/incidents',{'name':'Review scoped access','severity':'Medium','notes':'Customer enquiry workflow reviewed.'})
 assert other.get('/api/ezqir/incidents').status_code==403 and member.get('/api/ezqir/incidents').status_code==403
 request(owner,'ezqir/incidents/'+incident['id'],{'revision':1,'status':'Resolved','notes':'Scoped key revoked and verified.'});assert owner.get('/api/ezqir/incidents').json()[0]['status']=='Resolved'
 assert owner.get('/api/records/incidents').status_code==404
 # Customer accounts keep their previous restriction while gaining only their own payment-module preferences.
 customer=client();u=user(customer,'sharim-product@example.com','Customer')
 with server.db() as c:c.execute('INSERT INTO customer_accounts VALUES(?,?,?)',(u['id'],'Sharim',server.now()))
 assert customer.get('/api/sharim/preferences').status_code==200
 assert customer.get('/api/avezqi/decisions').status_code==403 and customer.get('/api/mevqi/knowledge').status_code==403
 raw='name,email,company\nImported Contact,imported@example.com,Imported Co'
 preview=request(owner,'mevqi/passage/preview',{'csv':raw});assert preview['count']==1
 before=len(owner.get('/api/records/contacts').json())
 imported=request(owner,'mevqi/passage/import',{'csv':raw,'confirmed':True});assert imported['imported']==1
 assert len(owner.get('/api/records/contacts').json())==before+1
 repeated=request(owner,'mevqi/passage/import',{'csv':raw,'confirmed':True});assert repeated['existing'] is True
 request(owner,'mevqi/passage/preview',{'csv':'name,email\nInvalid,bad'},expected=400)
 assert len(owner.get('/api/records/contacts').json())==before+1
 print('PASS: trusted operator setup, real enquiry routing, reviewed approval and single task execution, saved scenarios, shared knowledge, isolated module preferences, hashed scoped expiring/revocable agents, actual cross-brand task creation, private incidents, CSRF, owner/member/customer and tenant boundaries. No external payment or carrier operation simulated.')
if __name__=='__main__':run()
