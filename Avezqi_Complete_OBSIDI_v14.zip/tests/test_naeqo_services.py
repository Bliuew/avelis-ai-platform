from test_app import client, server, user
from concurrent.futures import ThreadPoolExecutor
import os,secrets,json

def run():
 owner=client();other=client();m=user(owner,'naeqo-owner@example.com','Naëqo operations');user(other,'unrelated@example.com','Other organization')
 public=client();os.environ.pop('AVELIS_NAEQO_ORG_ID',None)
 assert public.get('/api/naeqo/options').json()['accepting_enquiries'] is False
 data={'service':'Device enquiry','device':'iphone-17','storage':'256 GB','name':'Enquiry Test','email':'enquiry@example.com','region':'Mississauga','notes':'A device enquiry','consent':True,'access_key':secrets.token_hex(32)}
 assert public.post('/api/naeqo/requests',json=data).status_code==503
 os.environ['AVELIS_NAEQO_ORG_ID']=m['org'];assert public.get('/api/naeqo/options').json()['accepting_enquiries'] is True
 assert public.get('/api/naeqo/operations').status_code==401
 assert other.get('/api/naeqo/operations').status_code==403
 assert public.post('/api/naeqo/requests',json={**data,'device':'imaginary-phone'}).status_code==400
 assert public.post('/api/naeqo/requests',json={**data,'storage':'999 TB'}).status_code==400
 assert public.post('/api/naeqo/requests',json={**data,'consent':False}).status_code==400
 assert public.post('/api/naeqo/requests',json=data,headers={'Origin':'https://evil.example'}).status_code==403
 # Simultaneous retries produce one row and a stable reference.
 with ThreadPoolExecutor(max_workers=2) as pool:replies=list(pool.map(lambda _:client().post('/api/naeqo/requests',json=data),range(2)))
 assert all(r.status_code==200 for r in replies),[(r.status_code,r.text) for r in replies]
 ids=[r.json()['request']['id'] for r in replies];assert len(set(ids))==1
 rid=ids[0];assert sorted(r.json()['existing'] for r in replies)==[False,True]
 assert all(r.json()['email_sent'] is False for r in replies)
 assert public.post('/api/naeqo/requests',json={**data,'notes':'Different'}).status_code==409
 credentials={'id':rid,'access_key':data['access_key']}
 assert public.post('/api/naeqo/track',json={**credentials,'access_key':secrets.token_hex(32)}).status_code==404
 tracked=public.post('/api/naeqo/track',json=credentials).json();assert tracked['status']=='Received'
 assert all(k not in tracked for k in ['email','name','details','access_hash','notes'])
 assert data['email'] not in json.dumps(tracked)
 queue=owner.get('/api/naeqo/operations').json();assert len(queue)==1 and queue[0]['details']['email']==data['email']
 payload={'status':'In review','public_update':'We are reviewing your requirements.','revision':1}
 assert public.post('/api/naeqo/operations/'+rid,json=payload).status_code==401
 assert other.post('/api/naeqo/operations/'+rid,json=payload).status_code==403
 assert owner.post('/api/naeqo/operations/'+rid,json=payload,headers={'X-CSRF-Token':'wrong'}).status_code==403
 updated=owner.post('/api/naeqo/operations/'+rid,json=payload);assert updated.status_code==200,updated.text
 assert updated.json()['revision']==2
 assert owner.post('/api/naeqo/operations/'+rid,json=payload).status_code==409
 assert owner.post('/api/naeqo/operations/'+rid,json={**payload,'status':'Activated','revision':2}).status_code==400
 tracked=public.post('/api/naeqo/track',json=credentials).json();assert tracked['status']=='In review' and tracked['public_update']==payload['public_update']
 with server.db() as c:
  row=c.execute('SELECT * FROM naeqo_requests WHERE id=?',(rid,)).fetchone();assert row['access_hash']==server.digest(data['access_key']) and data['access_key'] not in json.dumps(dict(row))
  assert c.execute('SELECT COUNT(*) FROM naeqo_requests').fetchone()[0]==1
  assert c.execute('SELECT COUNT(*) FROM audit WHERE target=?',(rid,)).fetchone()[0]==1
 # A customer account can never operate the queue, even if manually assigned the organization.
 outsider=client();u=user(outsider,'naeqo-customer@example.com','Customer')
 with server.db() as c:
  c.execute('UPDATE users SET org=? WHERE id=?',(m['org'],u['id']))
  c.execute('INSERT INTO customer_accounts VALUES(?,?,?)',(u['id'],'Naëqo',server.now()))
 assert outsider.get('/api/naeqo/operations').status_code==403
 # Budget is user preference, validated independently of any supplier offer.
 for service in ['Mobile connectivity','Home internet']:
  d={**data,'service':service,'device':'','storage':'','budget_cad':75,'access_key':secrets.token_hex(32)}
  r=client().post('/api/naeqo/requests',json=d);assert r.status_code==200,r.text
  assert r.json()['request']['budget_cad']==75
 for budget in [24,151,'bad']:
  assert client().post('/api/naeqo/requests',json={**data,'service':'Home internet','budget_cad':budget,'access_key':secrets.token_hex(32)}).status_code==400
 for route in ['/naeqo/connect/','/naeqo/track/','/naeqo/operations/']:assert public.get(route).status_code==200
 print('PASS: real persisted Naëqo enquiries, concurrent idempotent submissions, correct device/storage/budget validation, consent and origin checks, hashed tracking keys, minimal public status, owner/org/customer isolation, CSRF, optimistic revisions, customer-visible updates and audit; no email, payment or carrier operation simulated.')
if __name__=='__main__':run()
