from test_app import client,user,request,server
import re,time

def run():
 a=client();user(a,'security-owner@example.com','Security organization')
 messages=[];original=server.send_notice;original_configured=server.configured_mail
 server.configured_mail=lambda:True
 def capture(recipient,subject,message):messages.append((recipient,subject,message));return 'accepted_by_mail_server'
 server.send_notice=capture
 try:
  known=request(client(),'account/forgot',{'email':'security-owner@example.com'})
  unknown=request(client(),'account/forgot',{'email':'unknown-security@example.com'})
  assert known==unknown and len(messages)==1
  token=re.search(r'#token=([A-Za-z0-9_-]+)',messages[-1][2]).group(1)
  with server.db() as c:
   assert c.execute('SELECT token FROM account_tokens WHERE token=?',(token,)).fetchone() is None
  request(client(),'account/verify',{'token':token},expected=400)
  request(client(),'account/reset',{'token':token,'password':'short'},expected=400)
  request(client(),'account/reset',{'token':token,'password':'NewSecurePassword2026!'})
  assert a.get('/api/me').status_code==401
  request(client(),'login',{'email':'security-owner@example.com','password':'TestPassword2026!'},expected=401)
  request(client(),'account/reset',{'token':token,'password':'AnotherSecurePassword2026!'},expected=400)
  b=client();request(b,'login',{'email':'security-owner@example.com','password':'NewSecurePassword2026!'})
  assert b.get('/api/me').status_code==200
  request(client(),'account/forgot',{'email':'security-owner@example.com'})
  expired=re.search(r'#token=([A-Za-z0-9_-]+)',messages[-1][2]).group(1)
  with server.db() as c:c.execute('UPDATE account_tokens SET expires=? WHERE token=?',(int(time.time())-1,server.digest(expired)))
  request(client(),'account/reset',{'token':expired,'password':'AnotherSecurePassword2026!'},expected=400)
  # A new account must verify ownership before any session is issued.
  invite=server.secrets.token_urlsafe(24)
  with server.db() as c:c.execute('INSERT INTO invites VALUES(?,?,?,?,0)',(server.digest(invite),None,'verify-user@example.com',int(time.time())+3600))
  n=client();created=request(n,'register',dict(email='verify-user@example.com',name='Synthetic user',company='Synthetic company',password='AnotherSecurePassword2026!',invite=invite))
  assert created['verification_required'] and n.get('/api/me').status_code==401
  request(n,'login',dict(email='verify-user@example.com',password='AnotherSecurePassword2026!'),expected=403)
  vt=re.search(r'#token=([A-Za-z0-9_-]+)',messages[-1][2]).group(1)
  request(n,'account/verify',{'token':vt});request(n,'account/verify',{'token':vt},expected=400)
  request(n,'login',dict(email='verify-user@example.com',password='AnotherSecurePassword2026!'))
  assert n.get('/api/me').status_code==200
 finally:server.send_notice=original;server.configured_mail=original_configured
 print('PASS: generic recovery response, hashed tokens, purpose/expiry checks, 12-character minimum, single use, verification-before-login and session invalidation. SMTP captured only by the test; actual delivery not tested.')
if __name__=='__main__':run()
