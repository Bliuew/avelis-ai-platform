"""Website v13: accounts work without email setup; first-owner code from the server log; site address from Render."""
import os, sys, subprocess, tempfile
from pathlib import Path
from test_app import client, request, server
ROOT = Path(__file__).resolve().parents[1]


def run():
    # Latest security requirement supersedes v13's automatic verification and unbound owner code.
    original=server.configured_mail;server.configured_mail=lambda:False
    try:
        assert server.first_owner_code() is None
        assert client().get('/api/status').json()['email_verification']=='required'
        request(client(),'signup',dict(name='Nia',email='nia13@example.com',password='NaeqoPassword2026!',product='Naëqo',terms=True),expected=503)
    finally:server.configured_mail=original
    # 4. The site address comes from Render's RENDER_EXTERNAL_URL when AVELIS_ORIGIN is not set.
    env = {k: v for k, v in os.environ.items() if k != 'AVELIS_ORIGIN'}
    env.update(RENDER_EXTERNAL_URL='https://example-app.onrender.com', AVELIS_DEV='1', AVELIS_DB=str(Path(tempfile.mkdtemp()) / 'o.sqlite3'))
    import fastapi
    env['PYTHONPATH'] = os.pathsep.join([os.path.dirname(os.path.dirname(fastapi.__file__)), env.get('PYTHONPATH', '')])
    out = subprocess.run([sys.executable, '-c', 'import server;print(server.ORIGIN)'], cwd=ROOT, env=env, capture_output=True, text=True)
    assert out.stdout.strip().endswith('https://example-app.onrender.com'), out.stderr[-400:]
    print('PASS: no email-unbound owner code, verification remains required when mail is unavailable, customer creation pauses safely, and site address still reads RENDER_EXTERNAL_URL.')


if __name__ == '__main__':
    run()
