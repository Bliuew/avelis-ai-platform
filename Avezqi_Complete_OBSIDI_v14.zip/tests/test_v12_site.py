"""Website v12: account panel on every brand page, redesigned cookie centre, product experience, homepage tour, no financing, no 'planned' labels."""
from pathlib import Path
import re, subprocess
from test_app import client
ROOT = Path(__file__).resolve().parents[1]
PUBLIC = ROOT / 'public'
BRAND_DIRS = ['avezqi', 'mevqi', 'naeqo', 'sharim', 'veqzi', 'ezqir', 'products', 'demo', 'experience']


def run():
    c = client()
    for f in ['brand-auth.js', 'cookies-v2.js', 'experience/experience.js', 'experience/tour.js']:
        assert subprocess.run(['node', '--check', str(PUBLIC / f)]).returncode == 0, f
    auth = (PUBLIC / 'brand-auth.js').read_text()
    # Account panel: correct options per brand; Ëzqir never gets public accounts.
    assert "naeqo:{name:'Naëqo',mode:'open'" in auth and "sharim:{name:'Sharim',mode:'open'" in auth
    for b in ['avezqi', 'mevqi', 'veqzi']:
        assert re.search(b + r":\{name:'[^']+',mode:'access'", auth), b
    assert 'ezqir:{' not in auth
    for kind in ['signin', 'signup', 'code', 'request']:
        assert f"'{kind}'" in auth, kind
    # Every brand sub-page loads the account panel and cookie consent.
    pages = [p for d in BRAND_DIRS for p in (PUBLIC / d).rglob('*.html')] + [PUBLIC / 'index.html']
    for p in pages:
        t = p.read_text()
        assert '/brand-auth.js' in t and '/account-panel.css' in t and '/cookies-v2.js' in t, str(p)
    # Cookie centre keeps the consent contract used by consent.js.
    ck = (PUBLIC / 'cookies-v2.js').read_text()
    assert "avezqi.cookie-preferences.v2" in ck and 'avezqi:cookie-preferences' in ck and 'role="switch"' in ck and 'aria-modal="true"' in ck
    assert 'cookie-settings-v2' in ck
    # Product experience and homepage tour.
    assert c.get('/experience/').status_code == 200
    js = (PUBLIC / 'experience' / 'experience.js').read_text()
    assert 'fetch(' not in js and 'XMLHttpRequest' not in js and 'sendBeacon' not in js
    home = c.get('/').text
    assert 'id="tour"' in home and '/experience/tour.js' in home and home.count('class="tr-scene"') == 6
    for b in ['mevqi', 'naeqo', 'sharim', 'veqzi', 'ezqir']:
        assert f'href="/experience/#{b}"' in c.get(f'/{b}/').text, b
    # Latest brief requests purchase/financing interfaces while forbidding fabricated lender offers.
    assert c.get('/naeqo/features/financing/').status_code == 200
    purchase=c.get('/naeqo/purchase-options/').text
    assert 'not a financing offer' in (PUBLIC/'purchase-options.js').read_text()
    assert 'No lender' in purchase and 'purchase-estimate' in purchase
    print('PASS: existing account panels and cookie contract, isolated example experience and homepage tour retained; financing is a user-input estimate and enquiry interface, not an offer.')


if __name__ == '__main__':
    run()
