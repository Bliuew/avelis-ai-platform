from test_app import client, server, user, request
from concurrent.futures import ThreadPoolExecutor
import json,time

def start():
 c=client();r=c.post('/api/demo/start',json={});assert r.status_code==200,r.text;state=r.json();c.headers['X-Demo-CSRF']=state['csrf'];return c,state

def action(c,action_name,expected=200,**extra):
 r=c.post('/api/demo/action',json={'action':action_name,**extra});assert r.status_code==expected,(action_name,r.status_code,r.text);return r.json()

def run():
 with server.db() as d:before={table:d.execute('SELECT COUNT(*) FROM '+table).fetchone()[0] for table in ['users','orgs','records','leads','ama_bookings']}
 a,initial=start();b,_=start()
 assert initial['example_data'] and initial['opportunity'] is None
 assert a.get('/api/me').status_code==401
 assert a.get('/api/records/contacts').status_code==401
 assert a.post('/api/demo/action',json={'action':'opportunity'},headers={'X-Demo-CSRF':'invalid'}).status_code==403
 assert a.post('/api/demo/action',json={'action':'opportunity'},headers={'Origin':'https://other.example'}).status_code==403
 action(a,'qualify',409);action(a,'book',409,slot='09:00')
 one=action(a,'opportunity');assert one['opportunity']['stage']=='Discovery'
 assert b.get('/api/demo/state').json()['opportunity'] is None
 action(a,'qualify')
 clones=[]
 for _ in range(2):
  c=client();c.cookies.update(a.cookies);c.headers['X-Demo-CSRF']=initial['csrf'];clones.append(c)
 with ThreadPoolExecutor(max_workers=2) as pool:replies=list(pool.map(lambda c:c.post('/api/demo/action',json={'action':'book','slot':'10:30'}),clones))
 assert sorted(r.status_code for r in replies)==[200,409]
 raw='Month,Appointments,Revenue_CAD\nJanuary,12,1200\nFebruary,16,1600\nMarch,20,2000'
 report=action(a,'analyze',csv=raw,name='example.csv')['report']
 metrics={x['column']:x for x in report['metrics']};assert metrics['Revenue_CAD']['total']==4800 and metrics['Appointments']['mean']==16
 assert report==server.numeric_csv_report(raw,'example.csv')
 action(a,'analyze',400,csv='a,b\n1,2,3',name='bad.csv')
 action(a,'analyze',400,csv='a'*(100001),name='large.csv')
 token=a.cookies.get(server.DEMO_COOKIE)
 with server.db() as d:
  assert d.execute('SELECT 1 FROM demo_sessions WHERE token=?',(token,)).fetchone() is None
  data=d.execute('SELECT data FROM demo_sessions WHERE token=?',(server.digest(token),)).fetchone()['data'];assert raw not in data
  after={table:d.execute('SELECT COUNT(*) FROM '+table).fetchone()[0] for table in before};assert before==after
 action(a,'reset');assert a.get('/api/demo/state').json()['booking'] is None
 with server.db() as d:d.execute('UPDATE demo_sessions SET expires=? WHERE token=?',(int(time.time())-1,server.digest(token)))
 assert a.get('/api/demo/state').status_code==401
 assert c.get('/demo/').status_code==200
 print('PASS: independent expiring demo sessions, CSRF/origin protections, no workspace privileges, hashed tokens, sample-only persistence, concurrent booking exclusion, real shared CSV statistics, invalid input, reset and expiry; no production business records or provider messages created.')
if __name__=='__main__':run()
