"""Static checks of the six public brand routes, their logos, exact taglines and retired names."""
from pathlib import Path
import re, html

PUBLIC = Path(__file__).resolve().parents[1] / 'public'
BRANDS = {
    'avezqi': ('brand/avezqi-light.png', 'Intelligence Behind Every Connection.'),
    'mevqi': ('brand/mevqi.png', 'Exploring Both Worlds.'),
    'naeqo': ('brand/naeqo.png', 'A Free Connection Everywhere Possible'),
    'ezqir': ('brand/ezqir.png', 'Within The Walls.'),
    'veqzi': ('brand/veqzi.png', 'Your Identity. Your Authority.'),
    'sharim': ('brand/sharim.png', 'Live Fully With Every Connected Purchase.'),
}
ACCESS = {'avezqi': {'request', 'code', 'signin'}, 'mevqi': {'request', 'code', 'signin'}, 'veqzi': {'request', 'code', 'signin'},
          'naeqo': {'signup', 'signin'}, 'sharim': {'signup', 'signin'}, 'ezqir': set()}
LEGACY = {'avelis': 'avezqi', 'ama': 'mevqi', 'eziro': 'ezqir', 'kavera': 'veqzi'}
RETIRED = re.compile(r'Avelis AI|Amā|\bAma\b|\bNay\b|Ezirö|Kavéra|Kavera|Kedàh|Libroll|Jalon|Bulun|Shalom')


def visible(text):
    text = re.sub(r'<script.*?</script>|<style.*?</style>', ' ', text, flags=re.S)
    alts = ' '.join(re.findall(r'alt="([^"]*)"', text))
    return html.unescape(re.sub(r'<[^>]+>', ' ', text) + ' ' + alts)


def run():
    for slug, (logo, tagline) in BRANDS.items():
        page = (PUBLIC / slug / 'index.html').read_text()
        assert f'/assets/{logo}' in page, (slug, 'logo')
        assert (PUBLIC / 'assets' / logo).stat().st_size > 1000, (slug, 'logo file')
        assert tagline in visible(page), (slug, 'tagline')
        assert '/cookies-v2.js' in page and '/consent.js' in page, (slug, 'consent')
        # Website v5: Ditheka Intelligence footer, no phase labels, only same-origin resources, correct account options.
        assert '/assets/brand/ditheka-' in page and 'Belong. Connect For A Smarter Tomorrow.' in visible(page), (slug, 'ditheka')
        assert not re.search(r'\bphase\b', visible(page), re.I), (slug, 'phase label')
        assert not re.search(r'(src|href)="(https?:)?//', page), (slug, 'external resource')
        forms = set(re.findall(r'data-auth="([a-z]+)"', page))
        assert forms == ACCESS[slug], (slug, forms)
        for f in re.findall(r'<form[^>]*>.*?</form>', page, re.S):
            assert 'onsubmit' not in f and all(re.search(r'name="[a-z_]+"', i) for i in re.findall(r'<input[^>]*>', f)), (slug, 'form fields')
    for old, new in LEGACY.items():  # compatibility routes serve the current page
        assert (PUBLIC / old / 'index.html').read_bytes() == (PUBLIC / new / 'index.html').read_bytes(), old
    for page in PUBLIC.rglob('*.html'):
        hit = RETIRED.search(visible(page.read_text()))
        assert not hit, (str(page), hit.group(0))
    for script in ['app.js', 'ama-operational.js', 'editorial.js', 'cookies-v2.js', 'book/booking.js', 'account/account.js']:
        strings = ' '.join(re.findall(r"'([^']*)'|`([^`]*)`", (PUBLIC / script).read_text(), flags=re.S).__str__().split())
        hit = RETIRED.search(strings)
        assert not hit, (script, hit.group(0))
    ezqir = (PUBLIC / 'ezqir' / 'index.html').read_text()
    assert 'product=ezqir' not in ezqir and 'mode=register' not in ezqir and 'no public registration' in visible(ezqir).lower()
    early = (PUBLIC / 'early' / 'index.html').read_text()
    options = re.findall(r'<option value="([^"]+)"', early)
    assert options == ['Avëzqi', 'Mëvqi', 'Naëqo', 'Vëqzi', 'Sharim'], options
    avezqi = visible((PUBLIC / 'avezqi' / 'index.html').read_text())
    for name in ['Advisor™', 'Forge™', 'Guardian™', 'Digital Twin™', 'AutoRepair™', 'Trust Passport™', 'Opportunity Intelligence™']:
        assert name in avezqi, name
    assert re.search(r'Discover.*Understand.*Govern.*Simulate.*Approve.*Execute.*Verify', avezqi, re.S)
    assert 'Planned' not in avezqi and 'In development' not in avezqi
    home = (PUBLIC / 'index.html').read_text()
    assert 'entrance' not in home.lower() and '<h1' in home and home == (PUBLIC / 'avezqi' / 'index.html').read_text()
    print('PASS: six brand routes use the approved logo files and exact taglines; Ditheka footer; no phase labels; same-origin resources only; access request + invitation code + sign-in on Avëzqi, Mëvqi and Vëqzi; open sign-up + sign-in on Naëqo and Sharim; no Ëzqir account forms; legacy routes mirror current pages; no retired names in public text or UI strings; no public Ëzqir request path; request form lists five products; seven specialists with status and the seven-step sequence present; homepage opens directly.')


if __name__ == '__main__':
    run()
