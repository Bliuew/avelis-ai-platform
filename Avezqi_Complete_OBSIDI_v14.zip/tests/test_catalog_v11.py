"""The visible product catalogue must feed the real enquiry API without dead choices."""
from pathlib import Path
from html.parser import HTMLParser
from test_app import client,user,server
import json,os,secrets
ROOT=Path(__file__).resolve().parents[1]
class Cards(HTMLParser):
 def __init__(self):super().__init__();self.entries=[]
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  if 'data-product-entry' in a:self.entries.append(a)
def run():
 owner=client();member=user(owner,'catalog-owner@example.com','Catalogue review');os.environ['AVELIS_NAEQO_ORG_ID']=member['org'];public=client()
 catalog=json.loads((ROOT/'public/device-catalog.json').read_text());options=public.get('/api/naeqo/options').json()
 assert len(catalog)==13 and options['devices']==catalog
 assert {x['category'] for x in catalog}=={'everyday','premium','foldable','lightweight'}
 for phone in catalog:
  payload=dict(service='Device enquiry',device=phone['id'],storage=phone['storage'].split(' / ')[0],name='Catalogue review',email='catalogue@example.com',region='Ontario',notes='',consent=True,access_key=secrets.token_hex(32))
  reply=public.post('/api/naeqo/requests',json=payload);assert reply.status_code==200,(phone['id'],reply.text)
  assert public.post('/api/naeqo/track',json=dict(id=reply.json()['request']['id'],access_key=payload['access_key'])).status_code==200
  if phone is catalog[0]:
   invalid=public.post('/api/naeqo/requests',json={**payload,'storage':'999 TB','access_key':secrets.token_hex(32)})
   assert invalid.status_code==400,invalid.text
 assert len(owner.get('/api/naeqo/operations').json())==13
 mapping=json.loads((ROOT/'public/feature-destinations.json').read_text());total=0
 for brand,features in mapping.items():
  page=public.get('/'+brand+'/features/');assert page.status_code==200
  parsed=Cards();parsed.feed(page.text);assert len(parsed.entries)==len(features)
  for url in features.values():assert 'href="'+url+'"' in page.text
  assert 'id="product-search"' in page.text and '/products/' in page.text
  total+=len(features)
 assert total==50  # Latest brief restores the original Financing destination with enquiry-only scope.
 print('PASS: all 13 visible models and valid storage choices persist and track through the real enquiry API; invalid storage rejected; all 50 original feature links retained across six searchable product directories.')
if __name__=='__main__':run()
