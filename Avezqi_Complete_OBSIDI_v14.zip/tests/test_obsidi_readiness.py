"""Actual storage and authorization, not mocked successful commercial services."""
from test_app import client,user,request,server
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import base64,secrets,time,os

def run():
 owner=client();om=user(owner,'operator14@example.com','Ditheka review');server.configure_operator(om['email']);reviewer=client();rv=user(reviewer,'reviewer14@example.com','Independent reviewer');other=client();ot=user(other,'other14@example.com','Unrelated company');anon=client()
 # Public requests persist but never grant account or document access.
 for kind in ['Investor','Partnership','Support','Document access']:
  data=dict(kind=kind,email=kind.split()[0].lower()+'@example.com',name='Synthetic enquiry',company='Test organization',product='Avëzqi',message='A request for review',consent=True,partner_type='Authorized distributor',documents=['Master business plan'])
  r=anon.post('/api/enquiries',json=data);assert r.status_code==200,r.text;assert not r.json()['approved'] and r.json()['email_status']=='not_configured'
 assert len(owner.get('/api/operator/enquiries').json())==4
 assert reviewer.get('/api/operator/enquiries').status_code==403
 assert anon.get('/api/investor-room/documents').status_code==401
 # Use a minimal synthetic PDF, never real confidential data in tests.
 pdf=b'%PDF-1.4\nSynthetic authorization test\n%%EOF\n';payload=dict(title='Private test plan',category='Master business plan',content_base64=base64.b64encode(pdf).decode())
 assert reviewer.post('/api/investor-room/documents',json=payload).status_code==403
 doc=request(owner,'investor-room/documents',payload)['id'];download='/api/investor-room/documents/'+doc+'/download'
 assert owner.get(download).content==pdf
 assert reviewer.get(download).status_code==404 and other.get(download).status_code==404
 assert reviewer.get('/api/investor-room/documents').json()['documents']==[]
 assert owner.post('/api/investor-room/grants',json=dict(document=doc,email=rv['email'],days=7),headers={'X-CSRF-Token':'invalid'}).status_code==403
 grant=request(owner,'investor-room/grants',dict(document=doc,email=rv['email'],days=7))['id']
 r=reviewer.get(download);assert r.status_code==200 and r.content==pdf and 'no-store' in r.headers['cache-control']
 assert other.get(download).status_code==404
 request(owner,'investor-room/grants/'+grant+'/revoke',{});assert reviewer.get(download).status_code==404
 request(owner,'investor-room/grants',dict(document=doc,email=rv['email'],days=1))
 with server.db() as c:c.execute('UPDATE document_grants SET expires=0 WHERE id=?',(grant,))
 assert reviewer.get(download).status_code==404
 # The old verified flag and an invalidated token do NOT prove email ownership.
 with server.db() as c:
  c.execute('DELETE FROM email_proofs WHERE user=?',(ot['id'],));c.execute("INSERT INTO account_tokens VALUES(?,?,?,0,1)",(server.digest('invalidated-old-token'),ot['id'],'verify'))
 assert owner.post('/api/investor-room/grants',json=dict(document=doc,email=ot['email'],days=1)).status_code==409
 assert other.get('/api/investor-room/documents').status_code==403
 assert anon.get('/private/Avezqi_Master_Business_Plan.pdf').status_code==404
 # Organization documents use a separate org boundary, even from investor grants.
 workspace_doc=request(owner,'mevqi/documents',dict(title='Organization note',content_base64=payload['content_base64']))['id']
 assert owner.get('/api/mevqi/documents/'+workspace_doc+'/download').content==pdf
 assert reviewer.get('/api/mevqi/documents/'+workspace_doc+'/download').status_code==404
 assert owner.post('/api/investor-room/documents',json={**payload,'content_base64':base64.b64encode(b'<html>bad</html>').decode()}).status_code==400
 # Independent reviewer invitations never join the founder organization or auto-grant documents.
 invite=request(owner,'operator/invitations',dict(email='newreview14@example.com',reason='Approved limited review'))
 with server.db() as c:assert c.execute('SELECT org FROM invites WHERE token=?',(server.digest(invite['invitation']),)).fetchone()['org'] is None
 assert invite['document_access'] is False and invite['email_sent'] is False
 # Saved customer journey creates only approved internal task and zero-value draft invoice, exactly once.
 cid=request(owner,'records/contacts',dict(name='Workflow customer',company='Test',email='customer14@example.com',phone='',status='Customer',notes=''))['id']
 case=request(owner,'customer-workflows',dict(name='Device support request',contact=cid,device='iphone-17',assignee=om['id']))['id']
 assert reviewer.post('/api/customer-workflows/'+case+'/advance',json=dict(revision=1,note='Unauthorized')).status_code==404
 for rev in [1,2]:request(owner,'customer-workflows/'+case+'/advance',dict(revision=rev,note='Reviewed requirements and authority'))
 def prepare(_):return owner.post('/api/customer-workflows/'+case+'/advance',json=dict(revision=3,note='Prepare internal work only'))
 with ThreadPoolExecutor(max_workers=2) as pool:responses=list(pool.map(prepare,range(2)))
 assert sorted(r.status_code for r in responses)==[200,409],[(r.status_code,r.text) for r in responses]
 result=next(r.json() for r in responses if r.status_code==200)
 invoice=owner.get('/api/records/invoices').json();assert len(invoice)==1 and invoice[0]['status']=='Draft' and invoice[0]['total']==0
 assert owner.get('/api/customer-workflows').json()[0]['invoice']==result['invoice']
 assert len(owner.get('/api/records/tasks').json())==1
 assert owner.get('/api/notifications').json()
 # Internal security records remain operator-only, with actual audit records.
 request(owner,'ezqir/register',dict(kind='Risk assessment',name='Test assessment',notes='Observed facts',status='Recorded'))
 assert reviewer.get('/api/ezqir/register').status_code==403
 assert len(owner.get('/api/ezqir/register').json())==1
 # Identity changes are org-scoped and cannot suspend the acting owner.
 assert owner.post('/api/identity/members/'+rv['id'],json=dict(action='Suspend')).status_code==404
 assert owner.post('/api/identity/members/'+om['id'],json=dict(action='Suspend')).status_code==400
 with server.db() as c:
  assert c.execute('SELECT COUNT(*) FROM audit WHERE action LIKE ?',('%confidential investor document%',)).fetchone()[0]>=2
  assert c.execute('SELECT COUNT(*) FROM enquiries').fetchone()[0]==4
 # New accounts cannot bypass verification when email is missing, and unbound owner codes cannot be used.
 original=server.configured_mail;server.configured_mail=lambda:False
 try:
  code=secrets.token_urlsafe(32)
  with server.db() as c:c.execute('INSERT INTO invites VALUES(?,?,?,?,0)',(server.digest(code),None,'paused14@example.com',int(time.time())+3600))
  assert anon.post('/api/register',json=dict(email='paused14@example.com',password='StrongPassword2026!',name='Paused',company='Paused org',invite=code)).status_code==503
  with server.db() as c:assert c.execute('SELECT used FROM invites WHERE token=?',(server.digest(code),)).fetchone()['used']==0
  assert server.first_owner_code() is None and server.verification_required() is True
 finally:server.configured_mail=original
 for route in ['/company/','/investors/','/investors/enquire/','/investors/request-documents/','/investors/room/','/partnerships/','/support/','/walkthrough/']:
  page=anon.get(route);assert page.status_code==200 and '/cookies-v2.js' in page.text
 print('PASS: persisted enquiries without approval; email-proved confidential document access; per-user grants, expiry/revocation, CSRF, audit and tenant boundaries; independent invitations; concurrent owner-approved case preparation creates one task and one draft invoice; private security records; no mail bypass or owner-code logging.')
if __name__=='__main__':run()
