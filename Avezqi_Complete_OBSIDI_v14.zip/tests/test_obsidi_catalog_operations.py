from test_app import client,user,request,server
from pathlib import Path
from PIL import Image
import json,base64

def run():
 r=Path(__file__).resolve().parents[1];catalog=json.loads((r/'public/technology-catalog.json').read_text());assert len(catalog)==22 and len({x['category'] for x in catalog})==10
 a=client();m=user(a,'operations14@example.com','Test operations');b=client();user(b,'boundary14@example.com','Different organization');server.configure_operator(m['email'])
 for x in catalog:
  assert a.get(x['detail']).status_code==200,x['id'];Image.open(r/'public'/x['image'].lstrip('/')).verify()
  assert x['source'].startswith('https://')
 selected=dict(kind='Support',email='catalog-qa@example.com',name='Test selection',company='Synthetic company',product='Naëqo',message='Request model information',consent=True,product_id='ipad-a16')
 assert a.post('/api/enquiries',json=selected).status_code==200
 assert a.post('/api/enquiries',json={**selected,'product_id':'fabricated-device'}).status_code==400
 merchant=request(a,'records/merchants',dict(name='Test merchant',contact_email='merchant@example.com',status='Recorded',notes='Test only'))['id']
 customer=request(a,'records/contacts',dict(name='Customer',company='Test',email='customer@example.com',phone='',status='Customer',notes=''))['id']
 payment=dict(merchant=merchant,customer=customer,description='Internal record only',amount=1000,status='Requested')
 request(a,'records/payment_requests',payment);request(b,'records/payment_requests',payment,expected=404)
 request(a,'records/benefit_rules',dict(merchant=merchant,name='Review benefit',discount_percent=10,status='Draft',terms='Not applied at checkout'))
 assert b.get('/api/records/merchants').json()==[] and b.get('/api/records/payment_requests').json()==[]
 device=request(a,'identity/devices',dict(name='Test laptop',platform='Example OS',status='Registered',notes='Manual inventory'))['id']
 assert len(a.get('/api/identity/devices').json())==1 and b.get('/api/identity/devices').json()==[]
 rid=request(a,'ezqir/register',dict(kind='Visitor record',name='Synthetic visit',notes='Observed',status='Recorded'))['id']
 request(a,'ezqir/register/'+rid,dict(revision=1,notes='Reviewed',status='Closed'))
 request(a,'ezqir/register/'+rid,dict(revision=1,notes='Stale update',status='Recorded'),expected=409)
 payload=dict(title='Capacity test',content_base64=base64.b64encode(b'%PDF-1.4\nTest\n%%EOF').decode())
 with server.db() as c:
  for i in range(100):c.execute('INSERT INTO private_documents VALUES(?,?,?,?,?,?,?,0,?)',(str(i),'Synthetic','Organization document',m['org'],'workspace',b'%PDF-1.4','test',server.now()))
 assert a.post('/api/mevqi/documents',json=payload).status_code==409
 assert a.post('/api/investor-room/documents',json={**payload,'category':'Master business plan'}).status_code==409
 print('PASS: 22 genuine-image catalogue entries, 10 categories, detail routes, selected-product validation; merchant/request/discount records and tenant boundaries; manual inventory, security revision conflicts and document capacity protections.')
if __name__=='__main__':run()
