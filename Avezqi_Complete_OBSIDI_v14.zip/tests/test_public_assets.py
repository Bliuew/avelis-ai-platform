from test_app import client
from html.parser import HTMLParser
class Links(HTMLParser):
 def __init__(self):super().__init__();self.urls=[]
 def handle_starttag(self,tag,attrs):
  for key,value in attrs:
   if key in ['src','href'] and value.startswith('/') and not value.startswith('//'):self.urls.append(value)
def run():
 c=client();seen=set()
 for route in ['/','/avezqi/','/mevqi/','/naeqo/','/sharim/','/veqzi/','/ezqir/','/app.html','/account/?action=forgot','/early/?product=mevqi','/ecosystem/','/access/','/about/']:
  response=c.get(route);assert response.status_code==200,route
  assert '/cookies-v2.js' in response.text and '/consent.js' in response.text,route
  p=Links();p.feed(response.text)
  for path in p.urls:
   if path in seen:continue
   seen.add(path);r=c.get(path);assert r.status_code==200,(path,r.status_code)
 assert c.get('/').headers['cache-control']=='no-cache'
 print('PASS:',len(seen),'internal links/assets; cookie settings and consent gate across audited routes; document revalidation enabled.')
if __name__=='__main__':run()
