'use strict';
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const apiReplies={
 'avezqi/decisions':[{id:'decision1',name:'Customer request',reason:'Review enquiry',stage:'Discover',revision:1,history:[]}],
 'avezqi/scenarios':[{name:'Scenario',baseline:100,change:10,projected:110,difference:10,projected_margin:60,assumption:'Assumed change'}],
 'mevqi/knowledge':[{id:'knowledge1',name:'Instructions',text:'Saved knowledge',author:'Owner',created:'2026-11-21'}],
 'sharim/preferences':{revision:0,modules:['Essentials','Ritual','Curated','Founder’s Circle'].map(name=>({name,budget_cad:0,enabled:true}))},
 'veqzi/agents':[{id:'agent1',name:'Agent',scopes:['tasks:create'],created:'2026-11-21',revoked:false}],
 'platform/readiness':{operator:true,naeqo_configured:false},
 'ezqir/incidents':[{id:'incident1',name:'Incident',severity:'Medium',status:'Open',revision:1,notes:'Evidence'}]
};
const ctx={render:async v=>({html:'Existing '+v}),navs:[],head:(t,s)=>`<h1>${t}</h1><p>${s}</p>`,panel:(t,s)=>`<section><h2>${t}</h2>${s}</section>`,table:(h,r)=>JSON.stringify({h,r}),fmt:String,esc:s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])),me:{role:'owner',org_name:'Operating Co'},view:'worlds',api:async p=>{assert(p in apiReplies,'Unexpected API '+p);return apiReplies[p]},go:()=>{},ecosystemHeader:x=>`<h1>${x}</h1>`,ecosystemLinks:x=>JSON.stringify(x),ecosystemBind:()=>{},document:{querySelectorAll:()=>[]},console};
vm.createContext(ctx);vm.runInContext(fs.readFileSync('public/connected-product-tools.js','utf8'),ctx);
(async()=>{
 for(const view of ['decisions','scenarios','memory','passage','sharim-modules','agents','incidents']){const r=await ctx.render(view);assert(r.html.length>100);assert(typeof r.bind==='function',view);assert(!r.html.includes('undefined'),view);}
 for(const brand of ['avezqi','mevqi','naeqo','sharim','veqzi','ezqir']){const r=await ctx.render(brand);assert(!r.html.includes('undefined'));assert(r.html.includes('Existing '+brand));}
 ctx.me.role='member';assert((await ctx.render('agents')).html.includes('organization owner'));
 apiReplies['platform/readiness'].operator=false;assert((await ctx.render('incidents')).html.includes('Private operator'));
 assert(fs.readFileSync('public/app.html','utf8').includes('/connected-product-tools.js'));
 console.log('PASS: connected tool screens render and bind, brand hubs expose their tools, private/owner views remain restricted, and existing screens are retained.');
})().catch(e=>{console.error(e);process.exitCode=1});
