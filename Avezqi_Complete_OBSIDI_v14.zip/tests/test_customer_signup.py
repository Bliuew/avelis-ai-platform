"""Website v5: open sign-up for Naëqo and Sharim only. All email is MOCKED (captured in-process)."""
from test_app import client, user, request, server
import re


def capture_mail():
    box = []
    send, configured = server.send_notice, server.configured_mail
    def capture(recipient, subject, message):
        box.append((recipient, subject, message)); return 'accepted_by_provider'
    server.send_notice, server.configured_mail = capture, (lambda: True)
    return box, (send, configured)


def restore(saved):
    server.send_notice, server.configured_mail = saved


def signup_creates_verified_customer_account_without_workspace():
    c = client()
    box, saved = capture_mail()
    try:
        r = request(c, 'signup', dict(name='Nia', email='nia@example.com', password='NaeqoPassword2026!', product='Naëqo', terms=True))
        assert r['verification_required'] is True
        # Duplicate email is refused.
        request(c, 'signup', dict(name='Nia', email='nia@example.com', password='NaeqoPassword2026!', product='Naëqo', terms=True), expected=409)
    finally:
        restore(saved)
    # Cannot sign in before verifying.
    request(c, 'login', {'email': 'nia@example.com', 'password': 'NaeqoPassword2026!'}, expected=403)
    token = re.search(r'#token=([A-Za-z0-9_-]+)', box[-1][2]).group(1)
    request(c, 'account/verify', {'token': token})
    request(c, 'login', {'email': 'nia@example.com', 'password': 'NaeqoPassword2026!'})
    summary = c.get('/api/account/summary').json()
    assert summary['account_type'] == 'customer' and summary['product'] == 'Naëqo' and summary['organization'] is None
    # Workspace data and workspace identity are refused for customer accounts.
    for path in ('/api/me', '/api/records/contacts', '/api/overview', '/api/team'):
        assert c.get(path).status_code == 403, path
    c.headers['X-CSRF-Token'] = summary['csrf']
    assert c.post('/api/records/contacts', json=dict(name='X', company='Y', email='x@example.com', phone='+14165550100', status='Prospect', notes='')).status_code == 403
    # Account controls still work for the customer.
    request(c, 'account/password', {'current': 'NaeqoPassword2026!', 'password': 'NaeqoPassword2027!'})
    request(c, 'logout', {})
    request(c, 'login', {'email': 'nia@example.com', 'password': 'NaeqoPassword2027!'})


def signup_rules():
    c = client()
    box, saved = capture_mail()
    try:
        # Only Naëqo and Sharim accept open sign-up.
        for product in ('Mëvqi', 'Avëzqi', 'Vëqzi', 'Ëzqir', 'Anything'):
            request(c, 'signup', dict(name='A', email='a-' + str(len(product)) + '@example.com', password='LongEnoughPass2026!', product=product, terms=True), expected=400)
        request(c, 'signup', dict(name='A', email='short@example.com', password='short', product='Sharim', terms=True), expected=400)
        request(c, 'signup', dict(name='A', email='terms@example.com', password='LongEnoughPass2026!', product='Sharim'), expected=400)
        request(c, 'signup', dict(name='Sam', email='sam@example.com', password='SharimPassword2026!', product='Sharim', terms=True))
    finally:
        restore(saved)
    # Without a configured sender no account is created.
    send, configured = server.send_notice, server.configured_mail
    server.configured_mail = lambda: False
    import os
    os.environ['AVELIS_REQUIRE_EMAIL_VERIFICATION'] = 'true'  # verification forced on while mail is missing: sign-up pauses
    try:
        request(c, 'signup', dict(name='P', email='paused-signup@example.com', password='LongEnoughPass2026!', product='Sharim', terms=True), expected=503)
    finally:
        server.configured_mail = configured
        os.environ.pop('AVELIS_REQUIRE_EMAIL_VERIFICATION', None)
    with server.db() as db:
        assert not db.execute("SELECT 1 FROM users WHERE email='paused-signup@example.com'").fetchone()


def workspace_accounts_unaffected():
    c = client()
    m = user(c, 'owner5@example.com', 'Org Five')
    assert c.get('/api/me').status_code == 200 and c.get('/api/records/contacts').status_code == 200
    s = c.get('/api/account/summary').json()
    assert s['account_type'] == 'workspace' and s['organization'] == 'Org Five'
    status = c.get('/api/status').json()
    assert status['registration'] == 'invite-only' and status['customer_signup'] == ['Naëqo', 'Sharim']


if __name__ == '__main__':
    signup_creates_verified_customer_account_without_workspace()
    signup_rules()
    workspace_accounts_unaffected()
    print('PASS: Naëqo/Sharim open sign-up with verification, duplicate refusal, product restriction, password rule, terms, mail-paused refusal, no workspace access for customer accounts, account controls, workspace accounts unchanged (mail MOCKED)')
