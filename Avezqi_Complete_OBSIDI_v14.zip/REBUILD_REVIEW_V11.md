# Avëzqi — industry browsing update v11

Prepared 22 November 2026. Release: `avezqi-industry-browsing-v11`.
This review is the current description of this increment; older review files describe earlier builds. No production deployment was performed.

## What changed

Naëqo now has 11 real manufacturer models, expanded from three. Everyday, Pro & premium, Foldable and Lightweight categories connect to manufacturer, operating-system and display-size filters. Search, alphabetical/display sorting, reset and a persistent session shortlist of up to three models work in the browser. Each model has an individual specifications page, local manufacturer product image, source attribution and a selection link to the existing enquiry flow. No supplier prices, inventory, financing approval or commercial agreement are fabricated.

Apple: iPhone 16, iPhone 17, iPhone Air, iPhone 18 Pro.
Samsung: Galaxy S25, Galaxy S25 Ultra, Galaxy Z Flip7, Galaxy Z Fold7.
Google: Pixel 9a, Pixel 10, Pixel 10 Pro.

The comparison includes manufacturer, category, display, storage, operating system and availability information. Samsung's foldable display sizes refer to their main displays. Apple's iPhone 18 Pro family photograph also depicts Pro Max; it is identified as such on the model page. Images are observed manufacturer assets, not generated illustrations. Sources and image provenance are retained in DEVICE_IMAGE_SOURCES.json and linked model pages. Manufacturer inclusion does not mean Naëqo has a supply agreement.

A public `/products/` directory connects all six brands. Their separate feature directories now organize all 50 original feature destinations into service groups, with useful descriptions, feature search and existing workspace actions. The approved homepage compositions, updated brand artwork and Naëqo rabbit/fox assets are retained. Homepage navigation gains public product/phone entry points; feature links remain visible on narrow screens rather than disappearing below 800px. Long mobile feature bars can scroll horizontally and existing menu buttons can expand them.

## Real-company references applied to navigation

| Brand | Reference | Pattern applied |
|---|---|---|
| Naëqo | Fido, https://www.fido.ca/phones | Separate mobile/internet/device/support journeys; product catalogue, real product photographs, filtering and individual details |
| Mëvqi | HubSpot, https://www.hubspot.com/products ; Slack, https://slack.com/features | Customer, collaboration and operations groups; clear routes into workspace tools |
| Avëzqi | Microsoft Power BI, https://www.microsoft.com/en-ca/power-platform/products/power-bi | Intelligence, decisions, governance and relevant tool entry points |
| Sharim | Mastercard, https://www.mastercard.com/global/en/business/industry-segment/large-corporations.html | Separate card collection, ways to pay, account experience and security; Maarah ownership retained |
| Vëqzi | Okta, https://www.okta.com/ | Identity/authority tools separated from evidence and governance |
| Ëzqir | Cloudflare One, https://www.cloudflare.com/sase/ | Private security boundaries separated from response and accountability |

These are information-architecture references, not partnerships, certifications or a claim to implement another company's infrastructure. Their prices, branding and proprietary interfaces have not been copied.

## Preserved behavior

Existing invitation-based business sign-up, email verification, recovery, sign-in, product access requests, separate customer account boundaries and cookies are retained. Existing private brand tools and organization permissions are retained. This increment changes the API release identifier but not the account or operational API implementations.

## Verification completed

- Browser: root Browse phones entry; 11 catalogue models; foldable filter gives two, Apple filter four, Pixel search three; alphabetical sorting; three-device comparison and fourth-selection limit; observed foldable product photographs load; individual Fold7 specifications and selected-model/storage handoff into the enquiry form.
- Browser: all-six product hub, Mëvqi Schedule feature search and Sharim grouped product directory; visual review of catalogue and directory layouts. The local preview correctly disables enquiry submission until an authorized operating organization is configured.
- `tests/test_catalog_v11.py`: all 11 valid device/storage choices submit, persist and track through the real API in isolated test databases; invalid storage rejected; all 50 original feature links retained in six directories.
- `tests/test_product_destinations.py`: 80 brand/detail pages and 198 linked routes/assets checked successfully.
- `tests/test_release.py`, `tests/test_naeqo_services.py`, `tests/test_public_assets.py`, `tests/test_account_security.py`, `tests/test_ecosystem_navigation.js`, `tests/test_consent.cjs`: passed. Email transport is mocked in account tests; real email delivery is not established by these tests.
- JavaScript syntax checks passed for the new catalogue and directory scripts.

Private signed-in browser journeys and physical phone layout acceptance were not performed in this increment. Existing private functionality was previously API-tested; do not equate those tests with a full signed-in browser test. Responsive CSS is included; test on the founder's actual phone before production acceptance. No Render container rebuild, actual mail delivery, live carrier activation, device fulfilment or payment-provider transaction was performed.

## What makes the enquiry form accept submissions

A real Naëqo operations organization must exist. The trusted configured platform operator signs in to the existing business workspace and enables Naëqo enquiry operations for their organization. The server uses AVELIS_NAEQO_ORG_ID when explicitly configured, otherwise the stored platform setting. `/api/naeqo/options` reports accepting_enquiries. If false, the frontend deliberately disables submission. It must not pretend an enquiry was received.

The trusted operator is initialized from the server's existing AVELIS_OWNER_EMAIL configuration. An ordinary visitor or unrelated organization cannot select an operating organization. Never expose invitation codes or secrets in public assets. Backend tests use isolated accounts and databases; those are not included in the package.

## Commercial boundaries

Phone browsing, enquiry recording/tracking and the existing internal tools are distinct from device sales, financing, SIM activation, internet provisioning, repairs/loaner fulfilment, wallet provisioning and payment processing. Those commercial actions still require their actual authorized supplier/provider connections. All six brands remain integrated through Avëzqi; no Phase II split was introduced. Ëzqir has no public enrollment.
