# Rebuild review v13

Builds on v12. Not deployed.

- Accounts work on first upload: origin from RENDER_EXTERNAL_URL; accounts auto-verified while no mail transport is configured (override with AVELIS_REQUIRE_EMAIL_VERIFICATION); one-time first-owner '*' invitation printed to the server log at start-up, valid 72 hours, usable only while no users exist; that owner becomes operator.
- Homepage tour, /experience/ and all "Try it" links are kept as in v12.
- Naëqo plan builder at /naeqo/plans/: data, talk & text, extras, SIM and optional phone; estimated monthly price in CAD, capped to $25-$150; the server sets the saved price. "Ask Naëqo about this plan" pre-fills the enquiry form (service, budget, phone, plan summary). Nothing is ordered or charged.
- Save buttons on phone cards and phone pages (up to six per account).
- My account rebuilt: plan, saved phones, enquiries, profile name, notification choices, password, sign-out, devices and "Download my data". Sharim customers keep their module budgets there.
- Header shows "My account" (or "Open workspace") once signed in.
- Ditheka logo and tagline added to every footer that was missing the logo (79 pages). Header menus no longer wrap mid-phrase on phones.
- New API: GET /api/naeqo/plan-options, POST /api/naeqo/plan-price, GET/POST /api/customer/profile (revision-checked), GET /api/customer/export.
- Tests: 19 Python test files and 2 Node UI tests pass, including tests/test_v13_accounts.py and tests/test_v13_features.py; browser-checked on desktop and phone sizes.
- Trade-off: without email, addresses are unconfirmed and password recovery is unavailable.
