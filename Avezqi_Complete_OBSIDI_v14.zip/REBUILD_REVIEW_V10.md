# Avëzqi connected tools v10 — replacement prepared for review

**Not deployed.** This replaces the v9 navigation-only update with real saved product tools. Existing names, logos, approved homepage/brand layouts, rabbit/fox artwork and account flows remain. Public copy now directs visitors to actual tools and explains their scope rather than showing generic roadmap badges.

## Implemented and tested

| Brand | Actions that run in this build |
| --- | --- |
| Avëzqi | Saved approval workflows follow Discover → Understand → Govern → Simulate → Approve → Execute → Verify. Only an owner approves/executes; execution creates exactly one internal Mëvqi task and verification checks its saved record. Revenue/cost scenarios calculate and persist explicit assumptions. Existing CSV analysis, integration telemetry, audit and pipeline tools remain. |
| Mëvqi | Existing contacts, opportunities, qualification/preferences, scheduling, tasks, channel messaging and activated task workflows remain. Memory adds saved/searchable organization knowledge. Passage validates and previews contact CSVs, then imports transactionally without overwriting matching emails or repeating the same file. |
| Naëqo | Existing real manufacturer/device browsing, comparison, device selection, saved enquiries, private receipts, tracking and operator queue remain. A trusted operator can now enable the operating inbox in the interface, without manually copying an organization ID into hosting settings. |
| Sharim | Essentials, Ritual, Curated and Founder’s Circle preferences and monthly budgets save to the actual signed-in user. Business and Sharim customer-account screens support them; users cannot read another user’s preferences. Card/payment information and existing commerce tools remain. |
| Vëqzi | Owners can create scoped API identities, obtain a credential once, export identity records and revoke credentials. Tokens are hashed, expire after 30 days and enforce contacts:read and/or tasks:create for the existing organization only. A permitted agent can genuinely create a Mëvqi task; revoked/expired credentials stop working. |
| Ëzqir | The trusted private operator can record incidents, assign severity and update investigation/resolution notes. Other customer organizations, members and ordinary customer accounts cannot read or update these records. Existing integration/agent revocation and audit destinations are connected. |

These are bounded software functions. They do not amount to completion of every specialist capability or every proposed brand service. No external telecom activation, device checkout/fulfilment, financial transaction, issued card, certified identity service, malware scan or automated network containment is simulated or claimed.

## Preserved account behavior

The public forms, brand request/sign-up/sign-in handlers, password minimum, invitations, verification, recovery and consent controls remain unchanged. Tests verify the prior customer/workspace boundary. Existing authorization is required for all business tools. Naëqo and Sharim customer signup never grants business-workspace access. The new agent endpoint uses explicit scoped bearer credentials; it does not accept the human session cookie instead.

## Required production preparation — do this before release

1. Back up and verify durable storage for the current SQLite database using the existing backup procedure. This update adds tables and preserves existing ones. Do not assume an ephemeral container filesystem survives deployment. No live database or hosting storage was inspected or changed during this build.
2. Keep the existing **AVELIS_OWNER_EMAIL** set to the intended founder/operator’s verified business account. At boot it seeds a trusted operator identity only if one does not already exist. Only that verified organization owner can enable the Naëqo operating inbox or enter the private incident register. Existing operator assignment is not silently replaced. No public endpoint can choose the trusted email.
3. Keep the existing mail transport credentials and HTTPS origin configured. No credentials are included in this ZIP. Real verification/recovery mail delivery must be checked with the configured provider. Existing account requirements have not been bypassed.
4. After the approved deployment, sign in using the existing operator account. Open Naëqo and select **Enable Naëqo enquiries** if the inbox has not yet been assigned. Existing AVELIS_NAEQO_ORG_ID takes precedence when already configured. Review customer privacy/retention and operational responsibility before collecting actual enquiries.
5. Keep the Dockerfile beside Avezqi_Render_Deploy.zip in the repository root. The supplied outer Dockerfile unpacks this exact outer archive and its embedded application archive. Both the updated bootstrap and server import support the trusted operator configuration.

No supplier contracts, carrier accounts, payment-provider accounts, funding negotiations, customer validation, revenue or partnerships are fabricated. Device financing remains an input-only estimate, never an available loan offer.

## Validation performed

- End-to-end backend regression: genuine enquiry routing → approval → single task creation; actual agent-authorized task creation and revocation; stored scenarios and knowledge; private incident updates; per-user module preferences; validated and repeat-safe CSV contact import.
- Security: organization isolation, owner/member/customer restrictions, operator restrictions, CSRF, malformed scopes, hashed/expiring/revoked credentials, stale revision and simultaneous execution conflicts.
- Existing app workflows, account security, brand release/scheduling, customer signup, unavailable mail behavior, Gmail transport, Naëqo enquiries, public assets and consent checks passed. Email and provider network calls are mocked in automated tests, never treated as real delivery.
- Product-destination check: 72 pages and 143 internal links/assets. JavaScript tool-render/navigation tests and syntax checks passed. Python compilation passed.
- Byte comparison against v9 confirms all six brand account-form blocks, brand-auth.js, consent.js and cookies-v2.js remain unchanged.
- Browser review verified the updated public homepage entry and the Digital Twin tool detail destination, preserving the design and linking to the matching authenticated tool. Protected screens were tested through the render/binding harness and real API tests, **not** a signed-in browser session. Full authenticated browser/mobile/accessibility QA and live email delivery remain unverified.

## After an approved release

Check **/api/status** and **/product-release.json** both identify **avezqi-connected-tools-v10**. Verify an existing account, an invitation signup and actual verification email, a customer signup, an access request confirmation, all six brand entries, a saved/reloaded record in each implemented tool, and a backup/restore. Use controlled test records; do not represent them as customer traction.

Historical review documents in the application archive describe earlier releases. This v10 review is the current release scope. No branch push, hosting configuration change, live data modification or deployment has been performed.
