# Avëzqi website v5 — release notes (review build, not deployed)

Prepared November 20, 2026 from repair build v4. Nothing was pushed, deployed, emailed or purchased.

## Website
- New homepage and brand pages for Avëzqi (`/` and `/avezqi/`), Mëvqi, Naëqo, Sharim, Vëqzi and Ëzqir, built from the approved canvas designs. Legacy routes (`/avelis/`, `/ama/`, `/eziro/`, `/kavera/`) serve identical copies.
- Ditheka Intelligence logo and tagline in every footer. No "Phase I" or "Phase II" wording on any public page.
- Fonts (Inter Display, DM Sans, Cardo; SIL OFL) and images are served from this site, so the existing Content-Security-Policy (`'self'` only) is unchanged.
- Cookie Settings in every footer opens the existing consent panel (`cookies-v2.js`, `consent.js`).

## Accounts
| Page | Options |
|---|---|
| Avëzqi, Mëvqi, Vëqzi | Request access (`/api/product-interest`), sign up with invitation code (`/api/register`), sign in (`/api/login`) |
| Naëqo, Sharim | Open sign-up (new `/api/signup`), sign in |
| Ëzqir | None. Restricted, no public registration |

- New `/api/signup`: Naëqo or Sharim only, 12-character password minimum, Terms acceptance, rate limits per IP and per email, email verification before sign-in, refused with 503 when mail is not configured (no account is created).
- These are customer accounts. A new table `customer_accounts` marks them, and every workspace API refuses them (403). Workspace access still needs an invitation. They can use `/my-account/` (details, change password, sign out, sign out everywhere).
- `/api/account/summary` adds `account_type`, `product` and `csrf`. `/api/status` adds `customer_signup` and reports release `avezqi-website-v5`.
- Schema change is additive only: new table `customer_accounts`. No existing table or column changed.

## Tests (all pass)
Run `python tests/<name>.py` for each file and `node tests/test_consent.cjs`. FastAPI could not be installed in the preparation environment, so the Python tests ran through a test-only stand-in for FastAPI's request layer (not included). Application logic, SQLite, hashing, tokens, limits and origin checks are the real code. All email is mocked.
- New `tests/test_customer_signup.py`: sign-up, verification before login, duplicates, product restriction, password rule, terms, mail-paused refusal, no workspace access for customer accounts, account controls, workspace accounts unchanged.
- Updated `tests/test_brand_pages.py`: logos, taglines, Ditheka footer, no phase labels, same-origin resources only, correct account forms per brand.
- Pages were also loaded in Chrome (desktop 1440 and phone 390) behind the production Content-Security-Policy: no blocked resources, fonts load, cookie panel opens, no horizontal overflow; form payloads checked against the API.
