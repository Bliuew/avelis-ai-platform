# Avëzqi — OBSIDI readiness preparation v14

This is a local, unpushed preparation based on the exact live v13 source at repository commit `6e4b81e0c7bb635b44583a52911ff3bc127f3837`. No ZIP, publication or deployment was performed. See [OBSIDI_IMPLEMENTATION_PLAN.md](OBSIDI_IMPLEMENTATION_PLAN.md) for the scoped priorities and [OBSIDI_READINESS_REVIEW.md](OBSIDI_READINESS_REVIEW.md) for changes, tests and remaining requirements.

## Preserve the existing environment

Python 3.13, FastAPI, SQLite, shared sessions and existing internal configuration/API names are retained. The five specialized platforms remain within Avëzqi. Public identities are Avëzqi, Mëvqi, Naëqo, Ëzqir, Vëqzi and Sharim; Maarah remains Sharim’s parent. Original brand artwork and homepage campaigns are retained.

## Local use

Install requirements in an isolated environment. Set `AVELIS_DEV=1`, `AVELIS_ORIGIN=http://127.0.0.1:8000` and `AVELIS_DB` to an isolated test database; then run `python server.py`. Use synthetic records for local tests. Configure real email transport before testing account registration/verification end to end; an unconfigured sender deliberately prevents new account creation. No verification bypass or wildcard owner invitation is created.

For a new organization, a trusted server operator can run `python server.py invite YOUR_BUSINESS_EMAIL`; share the returned email-bound invitation privately, never in public logs or source. Existing founder bootstrap supports `AVELIS_OWNER_EMAIL` and a strong `AVELIS_OWNER_INVITE` through `bootstrap.py`, without printing secrets. An invitation still requires email verification. Explicit trusted operator configuration is required for private Ëzqir records and investor grants. Do not rotate production founder configuration or reset customer data during local review.

## Production gates

The current remote repository builds nested source archives. Local source edits are not consumed by the existing root Dockerfile until a separately reviewed release is prepared. Do not push main: it has automatic deployment enabled. This task does not authorize changing that pipeline.

Before any approved release: verified database backup and restore; isolated staging service/database; durable production storage and permissions; HTTPS origin and cookies; configured email transport with an actual inbox test; reviewed operator bootstrap and existing-account re-verification for private documents; privacy/terms/retention review; dependency/security review; and post-release smoke tests. Do not redeploy an ephemeral service holding unbacked customer data.

Document uploads accept PDF signatures with a 1 MB per-file limit, and enforce organization capacity. They are not malware-scanned. Investor documents require email proof and individual expiring, revocable grants; ordinary workspace members share only organization documents. Do not place confidential files in `public/` or Git.

Live carrier provisioning, calling/video, device fulfilment, lender financing, regulated payments, licensed security operations, vendor monitoring, MFA/SSO and managed endpoint enforcement require separate authorized integrations. Their records and enquiry interfaces do not activate those services.

## Validation

Tests use isolated temporary databases, synthetic records and mocked mail providers. Run the Python test scripts and Node consent/navigation/workspace checks listed in the review. Provider acceptance in a mock is not inbox delivery. Local browser checks do not replace production HTTPS and physical-device acceptance.
