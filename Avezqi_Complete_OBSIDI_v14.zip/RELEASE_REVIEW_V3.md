# Avëzqi — local review build v3

Prepared November 20, 2026. This note supersedes older build-status descriptions in the retained project documents. No GitHub push, production configuration change or deployment was performed in this revision.

## Changes

- Includes the previously prepared Gmail API HTTPS transport and its owner-controlled configuration guide, which were absent from the last delivered ZIP.
- Verification/recovery requests now return an honest, uniform service-unavailable response if mail configuration is absent. This check does not reveal whether an email address belongs to an account, create unusable tokens or bypass verification. If credentials are present but invalid, the generic submission response still does not establish delivery; real provider testing remains required.
- Clarifies verification links versus numeric codes and access requests versus invitation-based account creation.
- Corrects CSS variable inheritance so each brand's intended text/background colours apply. Original logos, images and homepage composition retained. Removes unsupported arrow glyphs from HTML link text.
- Adds useful home navigation and brand-specific navigation labels. Updates customer-facing text without exposing unresolved internal planning details.
- Expands Naëqo device, manufacturer, proposed connectivity, repair/loaner and financing information. No commercial offer or carrier integration activated.
- Clarifies Sharim payment-method intentions and Maarah ownership; preserves the original modular card image.
- Includes CLAUDE_WEBSITE_BRIEF.md as the same requirements supplied for comparison. It is a requirements brief, not a claim that every planned capability is implemented.

## Verified locally

Python workflow, operational, release, account-security, Gmail-transport, mail-unavailable and public-asset tests passed. Node consent tests passed. Public-asset test checks 48 internal links/assets. The release test verifies competing bookings, tenant boundaries and no public Ëzqir enrollment. Gmail provider requests are mocked: no real email was sent.

Desktop browser inspection showed the homepage and all six brand pages, updated logos, campaign images and corrected palettes. Cookie Manage Preferences and Save Preferences worked; the saved choice remained in effect on another brand page with Cookie Settings still available. Naëqo's financing disclosure expanded. This was a static preview: browser form submissions/backend journeys were checked by API tests, not browser end-to-end tests. Mobile device QA and full accessibility audit remain outstanding.

## Still required before production acceptance

1. Owner completes Gmail authorization; real sender configuration remains unverified. Do not paste secrets into chat, source or the ZIP.
2. Confirm actual verification/recovery email arrival and link completion with a controlled account. Provider acceptance alone is not delivery.
3. Confirm durable hosting storage, backups, restore and restart behaviour. Local SQLite persistence tests do not prove Render storage durability.
4. Verify the exact deployed source and archive/Dockerfile pairing, inspect staging, approve the release and rollback plan. Uploading to an auto-deploying branch can change production.
5. Supplier, carrier, financing, payment and specialist security services require separate real implementations/agreements. Existing business workflow tests do not establish these planned products are operational.

This is an incremental repair/review build of the existing website. It does not implement the entire long-term roadmap. The live website has not changed as a result of this work.
