# Avëzqi — implementation and readiness review

Prepared for Chinyere Ishionwu • November 24, 2026 • Local v14 preparation

**Actual software changes have been implemented locally. They are not on the live website. No ZIP was created, no GitHub changes were pushed, and no deployment was performed.** The complete request is not yet production-ready: email delivery, durable hosting and several external service integrations remain unresolved.

## Verified starting point

The source was recovered from the exact archive consumed by `Bliuew/avelis-ai-platform`, branch `main`, commit `6e4b81e0c7bb635b44583a52911ff3bc127f3837`. The archive Git blob was verified as `ceb14f79af8a78c38317434b921bde599caf46ce`. Render reported that commit as live. This avoids accidentally editing the older v11 package instead of the deployed v13 work.

The existing application is Python/FastAPI with SQLite, static brand pages and a shared authenticated workspace. Its root deployment consumes nested source archives. **Editing extracted source locally does not update that deployment.** Main has automatic deployment enabled; a future release must be reviewed separately before pushing anything there.

The live `/api/status` returned online, email verification **off**, mail **not configured**, and AI **not configured**. Render listed a free service. A persistent database mount, backup schedule and successful restore were not established. No production credentials were retrieved or changed.

Original brand logo files, campaign imagery, rabbit/fox artwork, approved homepage content and shared account architecture were retained. Public navigation was extended; the approved homepage was not replaced with an unrelated design. New enterprise pages use the existing ivory/burgundy identity and clear typography, tables and purposeful navigation. The supplied reference screenshots were treated as usability references, not copied branding or fabricated operating metrics.

## What works in the local implementation

| Area | Implemented behavior | Important boundary |
|---|---|---|
| Avëzqi public site | Company/founder profile, Investor Relations, partnership opportunities, support, document requests and a five-minute walkthrough | New founder statement is proposed copy for Chinyere’s review; no portrait, staff or achievements invented |
| Public enquiries | Validated investor, partnership, support and document requests persist with references and operator review statuses | A submitted request never grants an account, document permission, financing or a commercial agreement |
| Email responses | Existing real mail transport is invoked when configured; UI reports missing or failed email honestly | Local tests use mocks; actual inbox delivery remains unverified |
| Authentication | Existing sessions/password/recovery architecture retained; new accounts require email verification and email-bound invitations where applicable | Missing mail pauses new account creation instead of treating an address as verified |
| Confidential documents | PDF upload, specific recipient grants, email ownership proof, expiry, revocation, authorized download and audit records | No anonymous public document downloads; other organizations’ ordinary records remain inaccessible |
| Mëvqi documents | Upload and retrieve PDFs inside an authenticated organization | Organization members share these documents; this is separate from individually granted investor documents |
| Connected customer workflow | Create a case from an actual customer record, assign a member and select a phone; review, owner approval and internal preparation persist | Preparation creates one team task and one zero-value draft invoice; no device order, payment or activation |
| Vëqzi | Organization owner membership roles, suspend/restore access, session revocation and manual device inventory | MFA/SSO and remote device enforcement are not connected |
| Ëzqir | Private operator risk, visitor, service, authorized-personnel and monitoring-asset records, plus existing incidents | Records are not camera feeds, automatic detection, licensed guarding or emergency dispatch |
| Sharim | Merchant records, internal payment-request records, draft discount rules, existing invoices and modular preferences | No customer funds, live payment link, checkout discount or financial transfer is processed |
| Notifications | Actual user-specific assignment, case and access notifications with read state | No invented business activity or claimed SMS/push delivery |
| Naëqo | 22 products in 10 categories; search, manufacturer/category filters, comparison, real images and detail pages | Manufacturer reference information is not Naëqo inventory, pricing or a signed partnership |
| Purchasing interfaces | User-input cost/financing calculation and a persisted selected-product enquiry | No lender, APR offer, credit application, eligibility decision, stock reservation or purchase |
| Naëqo services | Stored enquiries for mobile/home/business internet, calling, roaming, temporary replacements, repairs, warranty, urgent assistance and outages | These record requirements and follow-up; external fulfilment and real-time monitoring require providers |
| Cookies | Existing consent storage and optional-loader gate retained; Accept All, Reject All, Manage Preferences and persistent Cookie Settings | Optional integrations must continue to use this gate when added |

### Brands, structure and existing features preserved

Ditheka Intelligence remains the operating home of Avëzqi. Mëvqi, Naëqo, Ëzqir, Vëqzi and Sharim remain integrated within Avëzqi during Phase I. Phase II independence is described in Investor Relations as a future interconnected expansion. **Maarah remains Sharim’s parent**, not a fintech platform. Naëqo’s proposed Canadian incorporation does not separate its user experience prematurely. SleekBella and unrelated ventures are excluded.

All seven named capabilities remain visible: **Advisor™, Forge™, Guardian™, Digital Twin™, AutoRepair™, Trust Passport™ and Opportunity Intelligence™**. Their existing bounded tools include CSV statistics, CRM intelligence, saved arithmetic scenarios, integration health records, scoped API identities and reviewed internal task creation. This preparation does **not** turn those into unrestricted autonomous AI, predictive digital twins, independent identity certification or automatic external repair. Live AI was unconfigured at audit.

The governed enterprise workflow remains **Discover → Understand → Govern → Simulate → Approve → Execute → Verify**. Its existing owner authorization and internal execution boundaries remain. The new customer-case stages are a separate operational process, not a replacement for that workflow.

All 16 Mëvqi module destinations remain: Relations, Discover, Signal, Engage, Respect, Reverse, Fair, Clarity, Passage, Daily, Schedule, Connect, Link, Memory, Flow and Insights. Existing appointment scheduling, shared channels, saved phones, customer plan preferences, data export, contact import, knowledge, scoped API access and invoice locks remain. A module’s visible destination does not imply every prospective service is fully operational.

Sharim retains Essentials, Ritual, Curated and Founder’s Circle preferences. Its closed-loop payment proposal and proposed $1 transaction fee remain subject to infrastructure, commercial and regulatory validation. Naëqo retains its three pillars and proposed $25–$150 CAD connectivity range. No manufacturer wholesale prices, signed agreements or regulatory approvals were invented.

### Catalogue coverage

The 13 phone models include existing Apple, Samsung and Google selections plus Nothing Phone (3a) and CMF Phone 2 Pro. Nine additional products cover tablets, laptops, smartwatches, earbuds, headphones, routers, smart-home devices, chargers and accessories. Each entry includes a manufacturer source and an existing or newly verified manufacturer image. `DEVICE_IMAGE_SOURCES.json` records provenance. Product specifications, regional compatibility and commercial image-use permissions should be rechecked before a public commercial release.

### Document access and legacy accounts

The prior verified flag could have been set without email ownership. Local v14 adds separate proof after an actual verification-token redemption. **Existing accounts and sessions are preserved**, but confidential access requires this new proof. Invalidated or previously used tokens alone are not accepted as proof.

The operator can issue an email-bound, 72-hour invitation after reviewing an enquiry. The external reviewer receives an independent empty organization, **not membership of the founder’s organization**. The invitation is shown once for private sharing; the interface does not pretend an invitation email was sent. A separate document-specific grant is required after verified sign-up.

PDF files are private database BLOBs, with a 1 MB per-file limit and organization limits of 100 files/20 MB. PDF signature validation is not malware scanning. Downloads are attachments, private/no-store and audited. There is no security certification or completed penetration test claim.

The existing confidential **Avezqi_Master_Business_Plan.pdf** was read and remains outside public files and Git. It was not automatically uploaded to a public or preview document room. The pitch deck, finalized forecasts, capital requirements, allocation, executive summary and other requested investor documents must be supplied or prepared and approved; none were fabricated.

## Validation results

**15 Python functional/regression scripts and 4 Node behavior/render checks passed.** These are specific local checks, not a production certification.

| Checks | Evidence covered |
|---|---|
| `test_obsidi_readiness.py` | Persisted requests; no automatic approval; confidential grants, expiry/revocation; CSRF; legacy-email-proof rejection; independent invitations; organization isolation; concurrent case preparation produces exactly one task/invoice |
| `test_obsidi_catalog_operations.py` | All 22 product images decode; 10 categories and detail routes; invalid product rejected; merchant/request/benefit boundaries; manual inventory; security revision conflict; document capacity |
| `test_v13_accounts.py`, `test_account_security.py`, `test_customer_signup.py` | No wildcard owner code; no missing-mail verification bypass; email verification; password length; purpose/expiry/single-use tokens; recovery; customer/workspace separation |
| `test_v13_features.py`, `test_catalog_v11.py` | Saved-phone/customer preferences, plan builder, export, all 13 valid phone selections, invalid configuration rejection and all 50 feature links |
| `test_connected_products.py`, `test_operational.py`, `test_release.py` | Existing cross-brand tools, member/owner/operator limits, scheduling races/cancellation, persisted CRM/tasks/invoices, scoped credentials, reviewed execution and tenant boundaries |
| `test_product_destinations.py`, `test_public_assets.py`, `test_v12_site.py` | Brand/detail destinations and internal links/assets; original account panel/cookie contract; financing explicitly limited to calculation/enquiry |
| `test_mail_unavailable.py`, `test_gmail_transport.py` | Safe missing-mail errors; mocked Gmail HTTPS transport/provider acceptance and failure handling; no actual email sent |
| `test_consent.cjs`, `test_ecosystem_navigation.js` | Optional code blocked before consent and stopped on withdrawal; shared-session navigation and restricted destinations |
| `test_connected_products_ui.js`, `test_obsidi_workspace_ui.js` | Existing and 11 added workspace screens render/bind; preserved brand hubs; owner/operator views remain restricted |

JavaScript syntax and Git whitespace checks also passed. Tests that previously asserted missing-mail auto-verification or removal of financing were updated because those behaviors conflict with the latest security and purchasing requirements; their replacement tests assert the intended boundaries.

**Observed in the local browser:** Investor Relations, original branding, product filtering, product comparison, a $1,200/200-down/20-month/0%-APR calculation returning $50/month, persisted investor enquiry with a real reference and explicit “email confirmation was not sent,” and the signed-out confidential-room boundary. Duplicate sign-in navigation found during review was removed.

**Not verified:** real Gmail inbox delivery; a signed-in private-workspace browser journey; production HTTPS/session behavior; physical iPhone/iPad testing; load/penetration testing; deployment or restart persistence. Responsive CSS was implemented and inspected in source. The review browser blocked DevTools responsive emulation, so mobile/tablet acceptance remains pending rather than claimed complete. A Starlette/httpx deprecation warning appeared in tests; no functional failure resulted, but dependency compatibility should be reviewed before release.

## Remaining requirements and recommended next release sequence

1. **Production reliability first:** preserve/export the existing database, verify a restore, confirm a durable mount and production file permissions, and use a separate staging database/service. Render documents that its default filesystem is ephemeral: https://render.com/docs/disks . No production storage change was made.
2. **Resolve email:** securely configure the existing supported transport, approved sender and origin; then test invitation, registration, verification, resend and recovery with an actual inbox. Never paste secrets into public files or chat. Current live mail is not configured.
3. **Complete identity review:** verify the legitimate operator account, legacy email ownership and onboarding; test signed-in organization roles end to end; add authorized MFA/SSO integration and stronger identity verification as required. This local increment does not deliver full enterprise IAM.
4. **Review content and policies:** Chinyere approves the drafted founder statement and company copy; add a professional portrait only when supplied. Finalize support, retention/deletion, hosting disclosures and legal terms. Confirm appropriate commercial permissions for product images.
5. **Prepare confidential materials:** approve the existing master plan; supply or prepare the missing investor documents. Validate forecasts and funding requirements; upload only through the reviewed protected room. The $250,000 scenario is illustrative, not approved financing.
6. **Provider integrations:** manufacturer/distributor authorizations and inventory; carrier numbers/calling/SIM/eSIM/internet/roaming/outages/credits; actual repair/loaner logistics; video conferencing; AI credentials and bounded evaluations; payment processor/closed-loop infrastructure and applicable approvals; licensed physical security and authorized monitoring. These are not completed merely by displaying forms.
7. **Finish software acceptance:** full signed-in desktop/mobile/tablet journeys; notification and document operations in the browser; accessibility audit; dependency/security review; malware-scan/retention process for uploads; load and backup/restore tests. Additional service-specific lifecycle screens and provider adapters remain development work.
8. **Only after explicit approval:** prepare a separately reviewed release for the existing archive-based pipeline or an approved source-based migration, deploy to staging, repeat critical checks, then seek approval for production. No main push, archive packaging or deployment occurred in this task.

## Five-minute walkthrough

- **0:00–0:45:** use the approved homepage and Investor Relations to explain fragmented business tools and the connected proposition.
- **0:45–1:30:** show all five integrated brands and the seven intelligence capabilities, with explicit operating boundaries.
- **1:30–3:30:** in a verified synthetic review organization, create a customer, assign a case, select a device, record requirements, approve as owner and prepare the internal task/draft invoice. Show the real audit/notification trail. Do not present synthetic records as customer evidence.
- **3:30–4:15:** show the Naëqo catalogue and the existing live-record workspace tools; distinguish working software from carrier, payment and other provider dependencies.
- **4:15–5:00:** explain revenue hypotheses, market validation priorities, partnerships and what funding would enable; show a document-access request, without exposing confidential files publicly.

OBSIDI acceptance is accurately described. BMO financing and grants have not been approved, and neither organization is represented as an investor, endorser or commercial partner.

## Where the work is located

Local source: `/workspace/scratch/1aa3ad65f51a/implementation/avezqi-obsidi-readiness`, branch `preparation/obsidi-readiness`.

Key additions: `server.py`; `public/obsidi-workspace.js`; `public/obsidi-workspace.css`; `public/company/`; `public/investors/`; `public/partnerships/`; `public/support/`; `public/walkthrough/`; `public/naeqo/products/`; `public/technology-catalog.json`; and the new authorization/catalogue/UI tests. The local preview is for review only and is not a public deployed website. The existing live URL will continue to show the previous release until a later authorized deployment.
