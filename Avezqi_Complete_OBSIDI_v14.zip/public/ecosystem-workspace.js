'use strict';
// Navigation repair only: reuse the existing session, APIs and tools.
const ecosystemBrands=[
 {id:'avezqi',name:'Avëzqi',tag:'Intelligence Behind Every Connection.',about:'Business intelligence, analysis and workspace oversight.'},
 {id:'mevqi',name:'Mëvqi',tag:'Exploring Both Worlds.',about:'Relationships, scheduling, communication and team operations.'},
 {id:'naeqo',name:'Naëqo',tag:'A Free Connection Everywhere Possible.',about:'Phone browsing, connectivity requirements and service enquiries.'},
 {id:'sharim',name:'Sharim',tag:'Live Fully With Every Connected Purchase.',about:'Payment-platform information and your existing commerce tools. Under Maarah.'},
 {id:'veqzi',name:'Vëqzi',tag:'Your Identity. Your Authority.',about:'Your workspace identity, membership and account security.'},
 {id:'ezqir',name:'Ëzqir',tag:'Within The Walls.',about:'Private workspace oversight for authorized owners.'}
];
const ecosystemBaseRender=render;
const ecosystemLinks=items=>`<div class="ecosystem-tools">${items.map(([title,target,note])=>`<button class="ecosystem-tool" data-workspace-tool="${esc(target)}"><b>${esc(title)}</b><span>${esc(note)}</span></button>`).join('')}</div>`;
const ecosystemBind=()=>document.querySelectorAll('[data-workspace-tool]').forEach(b=>b.onclick=()=>go(b.dataset.workspaceTool));
const ecosystemHeader=id=>{const b=ecosystemBrands.find(x=>x.id===id);return `<div class="ecosystem-brand-head"><img src="/assets/brand/${b.id}.png" alt="${esc(b.name)}"><div><p class="eyebrow">${esc(b.tag)}</p><h1>${esc(b.name)}</h1><p>${esc(b.about)}</p></div></div><nav class="ecosystem-switch" aria-label="Connected workspaces">${ecosystemBrands.map(x=>`<button data-workspace-tool="${x.id}" ${x.id===id?'aria-current="page"':''}>${esc(x.name)}</button>`).join('')}</nav>`;};
render=async function(v){
 if(v==='worlds')return {html:head('Your connected ecosystem.','Choose a brand. Your workspace session and organization stay with you.')+`<div class="world-grid">${ecosystemBrands.map(b=>`<article class="world-card"><div class="world-logo"><img src="/assets/brand/${b.id}.png" alt="${esc(b.name)}"></div><p class="eyebrow">${esc(b.tag)}</p><h2>${esc(b.name)}</h2><p>${esc(b.about)}</p><button class="btn" data-workspace-tool="${b.id}">Open ${esc(b.name)}</button></article>`).join('')}</div>`,bind:ecosystemBind};
 if(v==='avezqi')return {html:ecosystemHeader(v)+ecosystemLinks([
  ['Command Centre','overview','Live totals calculated from your saved records.'],['Advisor™ Analytics','advisor','Upload CSV data, calculate statistics and save reports.'],['Integrations','integrations','Manage connections and authorized health telemetry.'],['AI Assistant','ai','Use the configured AI provider.'],['Activity & governance','audit','Review recorded workspace actions.']
 ])+panel('Specialist capabilities','<p>Explore the original seven specialist capabilities and their current implementation details.</p><a class="outline" href="/avezqi/features/">View specialist capabilities</a>'),bind:ecosystemBind};
 if(v==='mevqi')return {html:ecosystemHeader(v)+ecosystemLinks([
  ['Relations','relations','Manage contacts and customer relationships.'],['Discover','discover','Search and qualify your prospect records.'],['Signal & Respect','signal','Review advertiser qualification and contact preferences.'],['Schedule','schedule','Publish availability and manage bookings.'],['Pipeline','pipeline','Manage opportunities and sales stages.'],['Connect','connect','Record interaction outcomes and next steps.'],['Link','link','Use shared workplace channels and messages.'],['Flow','flows','Run activated task workflows.'],['Daily & team tasks','teams','Assign and update your team’s work.'],['Insights','insights','See analytics calculated from saved records.'],['Commerce','commerce','Manage invoice records and external settlement references.']
 ])+panel('All Mëvqi features','<a class="outline" href="/mevqi/features/">Explore the complete feature directory</a>'),bind:ecosystemBind};
 if(v==='naeqo'){
  const options=await api('naeqo/options');
  const publicTools=panel('Phones & connectivity','<div class="actions"><a class="btn" href="/naeqo/phones/">Browse and compare phones</a><a class="outline" href="/naeqo/connect/">Mobile & internet enquiries</a><a class="outline" href="/naeqo/track/">Track an enquiry</a></div><p>Apple, Samsung and Google manufacturer pages, device selection, saved requirements and private status tracking.</p>');
  let operations='';if(me.role==='owner'){try{const rows=await api('naeqo/operations');operations=panel('Customer enquiry inbox',`<p>${rows.length} enquiries in your authorized Naëqo organization.</p>`+table(['Reference','Service','Status','Updated'],rows.slice(0,10).map(x=>[esc(x.id),esc(x.service),esc(x.status),esc(x.updated)]))+'<a class="outline" href="/naeqo/operations/">Review and update enquiries</a>');}catch(e){operations=panel('Customer enquiry inbox',`<p>${esc(e.message)}</p><p>Only the designated Naëqo organization can operate the service inbox.</p>`);}}
  return {html:ecosystemHeader(v)+publicTools+operations+panel('Service availability',`<p>${options.accepting_enquiries?'Online enquiries are accepting submissions.':'Online enquiry acceptance requires the operating organization to be configured.'} Device purchases, carrier activation and service appointments require supplier confirmation.</p>`),bind:ecosystemBind};
 }
 if(v==='veqzi'){
  const [account,team]=await Promise.all([api('account/summary'),api('team')]);
  return {html:ecosystemHeader(v)+panel('Your workspace identity',table(['Name','Business email','Organization','Role','Email verified'],[[esc(account.name),esc(account.email),esc(account.organization),esc(account.role),account.email_verified?'Yes':'No']]))+panel('Workspace directory',table(['Name','Business email','Role'],team.map(x=>[esc(x.name),esc(x.email),esc(x.role)])))+ecosystemLinks([['Account security','settings','Manage your existing password and signed-in sessions.'],['Invitations & membership','settings','Use the existing owner invitation-code process.'],['Activity history','audit','Review workspace access and recorded actions.']])+panel('Identity capabilities','<a class="outline" href="/veqzi/features/">Explore Vëqzi capabilities</a><p>This view uses Avëzqi’s existing account system; it does not claim an external identity-provider connection.</p>'),bind:ecosystemBind};
 }
 if(v==='ezqir'){
  if(me.role!=='owner')return {html:ecosystemHeader(v)+panel('Restricted workspace','<p>This workspace is for authorized organization owners.</p>'),bind:ecosystemBind};
  const [activity,connections]=await Promise.all([api('audit'),api('records/integrations')]);
  return {html:ecosystemHeader(v)+panel('Workspace oversight',`<div class="metric-grid">${metric('Recorded events',activity.length,'Latest workspace audit records')}${metric('Registered connections',connections.length,'Your organization’s integration register')}</div>`)+panel('Recent recorded actions',table(['Time','Action','Actor'],activity.slice(0,20).map(x=>[esc(x.created),esc(x.action),esc(x.actor)])))+ecosystemLinks([['Review integrations','integrations','Inspect registered health information and scoped integration keys.'],['Review activity','audit','Read your organization’s recorded activity.'],['Account protection','settings','Use the existing session and password controls.']])+panel('Scope','<p>This view provides workspace oversight using existing records. Network containment, malware scanning and automated security enforcement are not connected by this navigation update.</p>'),bind:ecosystemBind};
 }
 const result=await ecosystemBaseRender(v);
 if(v==='sharim'){
  // Retain the original commerce behavior; do not replace Sharim with a different product.
  result.html=ecosystemHeader(v)+panel('Sharim platform',`<div class="actions"><a class="outline" href="/sharim/features/">Card collection & benefits</a><a class="outline" href="/sharim/features/ways-to-pay/">Payment methods & wallets</a><a class="outline" href="/sharim/">Sharim website</a></div>`)+result.html;
  const bind=result.bind;result.bind=()=>{ecosystemBind();bind?.();};
 }
 return result;
};

// A fast session check may finish before this deferred extension loads.
if(me)go(view);
