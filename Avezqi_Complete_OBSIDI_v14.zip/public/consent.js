'use strict';
// Optional integrations must register a loader. They cannot start until consent allows their category.
(()=>{const registry=new Map(),key='avezqi.cookie-preferences.v2';let preference={analytics:false,marketing:false};try{const v=JSON.parse(localStorage.getItem(key));if(v?.version===2)preference=v;}catch{}
function apply(){for(const [id,entry] of registry){const allowed=preference[entry.category]===true;if(allowed&&!entry.active){entry.active=true;try{entry.stop=entry.start()||null;}catch{entry.active=false;}}else if(!allowed&&entry.active){if(typeof entry.stop==='function')entry.stop();entry.active=false;}}}
window.AvezqiConsent=Object.freeze({register(id,category,start){if(!['analytics','marketing'].includes(category)||typeof start!=='function'||registry.has(id))throw Error('Invalid optional integration');registry.set(id,{category,start,active:false,stop:null});apply();},allows(category){return ['analytics','marketing'].includes(category)&&preference[category]===true;}});
window.addEventListener('avezqi:cookie-preferences',e=>{preference=e.detail;apply();});window.addEventListener('storage',e=>{if(e.key!==key)return;try{preference=JSON.parse(e.newValue)||{analytics:false,marketing:false};}catch{preference={analytics:false,marketing:false};}apply();});
})();
