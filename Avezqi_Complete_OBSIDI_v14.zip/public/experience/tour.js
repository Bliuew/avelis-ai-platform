'use strict';
// Homepage tour: cycles through each company's demo scene. Pause, choose a scene, or open the full demo.
(()=>{
 const box=document.querySelector('.tr-box');if(!box)return;
 const items=[...box.querySelectorAll('.tr-li')],scenes=[...box.querySelectorAll('.tr-scene')],toggle=box.parentElement.querySelector('[data-tour-toggle]');
 const DUR=9000;let i=0,timer=null,left=DUR,started=0;
 const reduce=window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches;
 box.style.setProperty('--dur',DUR/1000+'s');
 const show=n=>{i=(n+scenes.length)%scenes.length;scenes.forEach((s,k)=>{s.classList.toggle('on',k===i);s.setAttribute('aria-hidden',String(k!==i));});items.forEach((b,k)=>{b.setAttribute('aria-current',String(k===i));const bar=b.querySelector('.tr-prog i');if(bar){bar.style.animation='none';void bar.offsetWidth;bar.style.animation='';}});left=DUR;};
 const run=()=>{box.classList.add('playing');clearTimeout(timer);started=Date.now();timer=setTimeout(()=>{show(i+1);run();},left);};
 const pause=()=>{clearTimeout(timer);left=Math.max(0,left-(Date.now()-started));box.classList.add('paused');toggle.textContent='Play tour';toggle.setAttribute('aria-pressed','true');};
 const play=()=>{box.classList.remove('paused');toggle.textContent='Pause tour';toggle.setAttribute('aria-pressed','false');run();};
 items.forEach((b,k)=>b.addEventListener('click',()=>{show(k);if(!box.classList.contains('paused'))run();}));
 toggle.addEventListener('click',()=>box.classList.contains('paused')?play():pause());
 show(0);
 if(reduce)pause();
 else{const io='IntersectionObserver' in window?new IntersectionObserver(es=>{es.forEach(e=>{if(e.isIntersecting&&!box.dataset.started){box.dataset.started='1';run();}});},{threshold:.35}):null;if(io)io.observe(box);else run();}
})();
