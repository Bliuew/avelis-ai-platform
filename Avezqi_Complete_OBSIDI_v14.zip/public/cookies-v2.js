'use strict';
/* Cookie preferences. Same storage key, version and event as before, so consent.js keeps working.
   A slim banner on first visit, and a preference centre with switches that can be reopened at any time. */
(()=>{
 const key='avezqi.cookie-preferences.v2';let saved=null;
 try{const v=JSON.parse(localStorage.getItem(key));if(v&&v.version===2&&typeof v.analytics==='boolean'&&typeof v.marketing==='boolean')saved=v;}catch{}
 const CATS=[
  {id:'necessary',title:'Essential',text:'Keep you signed in securely, protect forms from abuse and remember this choice. These cannot be switched off.',locked:true},
  {id:'analytics',title:'Analytics',text:'Help us understand which pages are useful so we can improve them. No analytics tools are installed today; your choice is saved and applied if one is ever added.'},
  {id:'marketing',title:'Marketing',text:'Allow personalised offers and campaign measurement. No marketing tools are installed today; your choice is saved and applied if one is ever added.'}];
 const shield='<svg aria-hidden="true" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="M9 12l2 2 4-4"/></svg>';
 // Banner
 const banner=document.createElement('section');banner.className='ck-banner';banner.id='cookie-panel';banner.setAttribute('role','region');banner.setAttribute('aria-label','Cookie choices');banner.hidden=!!saved;
 banner.innerHTML='<div class="ck-icon">'+shield+'</div><div class="ck-copy"><h2 id="cookie-heading">Your privacy, your choice.</h2><p id="cookie-summary">We use essential cookies to keep your account secure. Optional analytics and marketing stay off unless you allow them. <a href="/privacy.html">Privacy notice</a></p></div><div class="ck-actions"><button type="button" class="ck-btn ghost" data-choice="manage">Manage preferences</button><button type="button" class="ck-btn ghost" data-choice="reject">Reject all</button><button type="button" class="ck-btn" data-choice="accept">Accept all</button></div><p class="ck-note" role="status"></p>';
 // Preference centre
 const center=document.createElement('div');center.className='ck-overlay';center.hidden=true;
 center.innerHTML='<div class="ck-center" role="dialog" aria-modal="true" aria-labelledby="ck-center-title" tabindex="-1"><div class="ck-head"><div class="ck-icon">'+shield+'</div><div><h2 id="ck-center-title">Privacy preferences</h2><p class="ck-sub">Choose what this website may use. You can change this at any time from Cookie Settings in the footer.</p></div><button type="button" class="ck-x" data-close aria-label="Close privacy preferences">×</button></div><ul class="ck-list">'+
  CATS.map(c=>'<li class="ck-cat"><div><h3 id="ck-'+c.id+'-t">'+c.title+'</h3><p id="ck-'+c.id+'-d">'+c.text+'</p></div>'+(c.locked?'<span class="ck-lock">Always on</span>':'<button type="button" class="ck-switch" role="switch" aria-checked="false" id="cookie-'+c.id+'" aria-labelledby="ck-'+c.id+'-t" aria-describedby="ck-'+c.id+'-d"><span></span></button>')+'</li>').join('')+
  '</ul><p class="ck-updated"></p><div class="ck-foot"><a href="/privacy.html">Read the privacy notice</a><div class="ck-actions"><button type="button" class="ck-btn ghost" data-choice="reject">Reject all</button><button type="button" class="ck-btn ghost" data-choice="save">Save choices</button><button type="button" class="ck-btn" data-choice="accept">Accept all</button></div></div><p class="ck-note" role="status"></p></div>';
 // Footer opener (kept for every page; brand footers have their own styled button that clicks this one)
 const open=document.createElement('button');open.type='button';open.className='cookie-settings-v2';open.textContent='Cookie Settings';open.setAttribute('aria-haspopup','dialog');
 (document.querySelector('footer')||document.body).append(open);document.body.append(banner,center);
 const dialog=center.querySelector('.ck-center'),sw=id=>center.querySelector('#cookie-'+id);let lastFocus=null;
 const setSw=(id,on)=>sw(id).setAttribute('aria-checked',String(!!on));
 center.querySelectorAll('.ck-switch').forEach(b=>b.addEventListener('click',()=>b.setAttribute('aria-checked',String(b.getAttribute('aria-checked')!=='true'))));
 function showCenter(){lastFocus=document.activeElement;setSw('analytics',saved?.analytics);setSw('marketing',saved?.marketing);center.querySelector('.ck-updated').textContent=saved?.updatedAt?'Last updated '+new Date(saved.updatedAt).toLocaleString():'';center.hidden=false;document.documentElement.classList.add('ck-lock-scroll');dialog.focus();}
 function hideCenter(){center.hidden=true;document.documentElement.classList.remove('ck-lock-scroll');if(!saved)banner.hidden=false;(lastFocus&&lastFocus.focus?lastFocus:open).focus({preventScroll:true});}
 open.addEventListener('click',showCenter);
 center.addEventListener('click',e=>{if(e.target===center||e.target.closest('[data-close]'))hideCenter();});
 center.addEventListener('keydown',e=>{if(e.key==='Escape'){e.preventDefault();hideCenter();return;}if(e.key==='Tab'){const f=[...dialog.querySelectorAll('button,a[href]')].filter(x=>!x.hidden);const first=f[0],last=f[f.length-1];if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}}});
 function choose(choice,root){
  if(choice==='manage'){banner.hidden=true;showCenter();return;}
  const on=id=>choice==='accept'||(choice==='save'&&sw(id).getAttribute('aria-checked')==='true');
  const pref={version:2,necessary:true,analytics:on('analytics'),marketing:on('marketing'),updatedAt:new Date().toISOString()};
  try{localStorage.setItem(key,JSON.stringify(pref));saved=pref;banner.hidden=true;if(!center.hidden)hideCenter();window.dispatchEvent(new CustomEvent('avezqi:cookie-preferences',{detail:{...pref}}));toast(choice==='accept'?'All cookies allowed.':choice==='reject'?'Only essential cookies are on.':'Your choices are saved.');}
  catch{root.querySelector('.ck-note').textContent='Your browser could not save this choice. Optional tracking stays off. Allow website storage to keep your preference.';}
 }
 [banner,center].forEach(root=>root.addEventListener('click',e=>{const b=e.target.closest('[data-choice]');if(b)choose(b.dataset.choice,root);}));
 let toastEl=null;function toast(t){if(!toastEl){toastEl=document.createElement('p');toastEl.className='ck-toast';toastEl.setAttribute('role','status');document.body.append(toastEl);}toastEl.textContent=t;toastEl.classList.add('on');clearTimeout(toastEl._t);toastEl._t=setTimeout(()=>toastEl.classList.remove('on'),2600);}
})();
