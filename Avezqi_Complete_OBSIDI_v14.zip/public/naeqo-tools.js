'use strict';
// Naëqo plan builder and "Save" buttons for phones (website v13).
// Saving uses the signed-in customer's own account; nothing is ordered or charged.
(()=>{
 const $=s=>document.querySelector(s);
 let csrf='',profile=null,signedIn=null;
 const toast=t=>{let n=$('#nq-toast');if(!n){n=document.createElement('div');n.id='nq-toast';n.className='nq-toast';n.setAttribute('role','status');document.body.append(n);}n.textContent=t;n.classList.add('show');clearTimeout(toast.t);toast.t=setTimeout(()=>n.classList.remove('show'),2600);};
 const get=async p=>{const r=await fetch('/api/'+p,{credentials:'same-origin',cache:'no-store'});let j={};try{j=await r.json();}catch{}if(!r.ok){const e=Error(typeof j.detail==='string'?j.detail:'Request could not be completed.');e.status=r.status;throw e;}return j;};
 const post=async(p,d)=>{const r=await fetch('/api/'+p,{method:'POST',credentials:'same-origin',cache:'no-store',headers:{'Content-Type':'application/json','X-CSRF-Token':csrf},body:JSON.stringify(d)});let j={};try{j=await r.json();}catch{}if(!r.ok){const e=Error(typeof j.detail==='string'?j.detail:'Request could not be completed.');e.status=r.status;throw e;}return j;};
 const askSignIn=()=>{toast('Sign in or create a free Naëqo account to save.');if(window.avezqiAccount)window.avezqiAccount.open('signin');else location.href='/naeqo/#join';};
 let loading=null;const load=()=>loading||(loading=(async()=>{try{const s=await get('account/summary');csrf=s.csrf;profile=await get('customer/profile');signedIn=true;}catch{signedIn=false;loading=null;}return signedIn;})());
 const saveProfile=async patch=>{
  const body={revision:profile.revision,plan:profile.plan,saved_devices:profile.saved_devices,notifications:profile.notifications,...patch};
  try{profile=await post('customer/profile',body);}
  catch(e){if(e.status===409){profile=await get('customer/profile');body.revision=profile.revision;profile=await post('customer/profile',{...body,...patch,revision:profile.revision});}else throw e;}
  return profile;};

 // Save buttons on phone cards and phone detail pages.
 const phoneButtons=()=>{
  const cards=[...document.querySelectorAll('[data-device]')];
  const detail=location.pathname.match(/^\/naeqo\/phones\/([a-z0-9-]+)\/$/);
  const targets=cards.map(c=>({host:c,id:c.dataset.device}));
  if(!cards.length&&detail){const h=document.querySelector('main h1');if(h)targets.push({host:h.parentElement,id:detail[1],after:h});}
  if(!targets.length)return;
  const paint=()=>targets.forEach(t=>{const b=t.button,on=!!(profile&&profile.saved_devices.includes(t.id));b.setAttribute('aria-pressed',String(on));b.lastChild.textContent=on?'Saved':'Save';});
  targets.forEach(t=>{
   const b=document.createElement('button');b.type='button';b.className='nq-save';b.setAttribute('aria-pressed','false');
   const heart=document.createElement('span');heart.className='nq-heart';heart.setAttribute('aria-hidden','true');heart.textContent='♥';
   b.append(heart,document.createTextNode('Save'));b.setAttribute('aria-label','Save this phone to my account');t.button=b;
   if(t.after)t.after.insertAdjacentElement('afterend',b);else{const spot=t.host.querySelector('label');if(spot)spot.parentElement.insertBefore(b,spot);else t.host.append(b);}
   b.addEventListener('click',async()=>{
    if(!await load())return askSignIn();
    const list=new Set(profile.saved_devices);const had=list.has(t.id);
    if(had)list.delete(t.id);else{if(list.size>=6){toast('You can save up to six phones. Remove one in My account.');return;}list.add(t.id);}
    b.disabled=true;
    try{await saveProfile({saved_devices:[...list]});paint();toast(had?'Removed from your saved phones.':'Saved to your account.');}
    catch(e){toast(e.message);}finally{b.disabled=false;}
   });
  });
  load().then(ok=>{if(ok)paint();});
 };

 // Plan builder.
 const planBuilder=async()=>{
  const form=$('#plan-builder');if(!form)return;
  let opts,devices=[];
  try{opts=await get('naeqo/plan-options');}catch{$('#plan-status').textContent='The plan builder could not load. Refresh to try again.';return;}
  try{devices=await (await fetch('/device-catalog.json',{cache:'no-store'})).json();}catch{}
  const money=v=>'$'+v;
  const group=(name,items,type)=>{const host=form.querySelector('[data-group="'+name+'"]');items.forEach((it,i)=>{const id=typeof it==='string'?it:it.id,label=typeof it==='string'?it:it.label;
   const l=document.createElement('label');l.className='nq-opt';const inp=document.createElement('input');inp.type=type;inp.name=name;inp.value=id;if(type==='radio'&&i===(name==='data'?2:0))inp.checked=true;
   const sp=document.createElement('span');const st=document.createElement('strong');st.textContent=label;const sm=document.createElement('small');
   sm.textContent=typeof it==='string'?(id==='eSIM'?'Activate digitally':'Delivered card'):(name==='data'?money(it.price)+' base':it.price?'+'+money(it.price)+' / month':'Included');
   sp.append(st,sm);l.append(inp,sp);host.append(l);});};
  group('data',opts.data,'radio');group('calling',opts.calling,'radio');group('extras',opts.extras,'checkbox');group('sim',opts.sim,'radio');
  const sel=$('#plan-device');devices.forEach(d=>sel.add(new Option(d.manufacturer+' '+d.name,d.id)));
  const state=()=>({data:form.elements.data.value,calling:form.elements.calling.value,extras:[...form.querySelectorAll('input[name=extras]:checked')].map(x=>x.value),sim:form.elements.sim.value});
  const price=p=>{const d=opts.data.find(x=>x.id===p.data),k=opts.calling.find(x=>x.id===p.calling);const total=d.price+k.price+p.extras.reduce((a,e)=>a+opts.extras.find(x=>x.id===e).price,0);return Math.max(opts.min,Math.min(opts.max,total));};
  const describe=p=>{const d=opts.data.find(x=>x.id===p.data),k=opts.calling.find(x=>x.id===p.calling);return [d.label+' data',k.label].concat(p.extras.map(e=>opts.extras.find(x=>x.id===e).label)).concat([p.sim]);};
  const render=()=>{const p=state(),total=price(p);$('#plan-price').textContent=money(total);
   const ul=$('#plan-lines');ul.replaceChildren();const d=opts.data.find(x=>x.id===p.data),k=opts.calling.find(x=>x.id===p.calling);
   const line=(a,b)=>{const li=document.createElement('li');const x=document.createElement('span');x.textContent=a;const y=document.createElement('span');y.textContent=b;li.append(x,y);ul.append(li);};
   line(d.label+' data',money(d.price));line(k.label,k.price?'+'+money(k.price):'Included');p.extras.forEach(e=>{const x=opts.extras.find(y=>y.id===e);line(x.label,'+'+money(x.price));});line('SIM',p.sim);
   const dev=devices.find(x=>x.id===sel.value);const pv=$('#plan-device-preview');pv.replaceChildren();pv.hidden=!dev;
   if(dev){line('Phone',dev.manufacturer+' '+dev.name);const img=document.createElement('img');img.src=dev.image;img.alt=dev.name;const t=document.createElement('div');const b=document.createElement('strong');b.textContent=dev.manufacturer+' '+dev.name;const s=document.createElement('p');s.style.margin='2px 0';s.textContent=dev.display+' · '+dev.storage;t.append(b,s);pv.append(img,t);}
   const q=new URLSearchParams({service:'Mobile connectivity',budget:String(Math.round(total/5)*5),plan:'Plan builder: '+describe(p).join(', ')+' (estimated $'+total+' CAD/month)'});if(dev)q.set('device',dev.id);
   $('#plan-enquire').href='/naeqo/connect/?'+q.toString();};
  form.addEventListener('change',render);
  // Restore a saved plan when the visitor is signed in.
  load().then(ok=>{if(!ok||!profile.plan)return render();const p=profile.plan;
   const set=(n,v)=>{const i=form.querySelector('input[name="'+n+'"][value="'+CSS.escape(v)+'"]');if(i)i.checked=true;};
   set('data',p.data);set('calling',p.calling);set('sim',p.sim);form.querySelectorAll('input[name=extras]').forEach(i=>i.checked=p.extras.includes(i.value));
   if(profile.saved_devices[0]&&!sel.value)sel.value=profile.saved_devices[0];render();$('#plan-status').textContent='Your saved plan is loaded.';});
  render();
  $('#plan-save').addEventListener('click',async()=>{const st=$('#plan-status');st.dataset.state='';
   if(!await load())return askSignIn();
   st.textContent='Saving…';
   try{const p=state();const saved=new Set(profile.saved_devices);if(sel.value&&saved.size<6)saved.add(sel.value);
    await saveProfile({plan:p,saved_devices:[...saved]});st.textContent='Saved. Find it any time in My account.';toast('Plan saved to your account.');}
   catch(e){st.textContent=e.message;st.dataset.state='error';}});
  form.addEventListener('submit',e=>e.preventDefault());
 };

 const start=()=>{phoneButtons();planBuilder();};
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
