"use strict";
const menu=document.querySelector('.menu'), nav=document.querySelector('.navlinks');
function closeMenu(){nav?.classList.remove('open');menu?.setAttribute('aria-expanded','false');} menu?.addEventListener('click',()=>{const open=nav.classList.toggle('open');menu.setAttribute('aria-expanded',String(open));});nav?.addEventListener('click',e=>{if(e.target.closest('a'))closeMenu()});window.addEventListener('pageshow',closeMenu);document.addEventListener('keydown',e=>{if(e.key==='Escape')closeMenu()});document.addEventListener('click',e=>{if(nav?.classList.contains('open')&&!nav.contains(e.target)&&!menu.contains(e.target))closeMenu()});
const form=document.querySelector('#interest');
if(form){const names={'kavera':'Vëqzi','ama':'Mëvqi','sharim':'Sharim','naeqo':'Naëqo','mevqi':'Mëvqi','veqzi':'Vëqzi','avezqi':'Avëzqi','avelis':'Avëzqi'};const status=document.querySelector('#interest-status');const btn=form.querySelector('button');const select=form.elements.product;const h=document.querySelector('main h1');
 const preset=names[new URLSearchParams(location.search).get('product')];if(preset&&select)select.value=preset;
 const heading=()=>{if(h&&select)h.textContent='Request access to '+select.value+'.';};if(preset)heading();select?.addEventListener('change',heading);
 const say=(text,kind)=>{status.textContent=text;status.className=kind||'';};
 (async()=>{try{const r=await fetch('/api/status',{cache:'no-store'});const d=await r.json();if(!r.ok||!d.online)throw Error();say('Requests are reviewed for invitation-only access.');btn.disabled=false;}catch{say('The request service is unavailable right now. Please try again later.','error');}})();
 form.addEventListener('submit',async e=>{e.preventDefault();
  const first=[...form.elements].find(x=>x.willValidate&&!x.checkValidity());if(first){first.focus();say(first.name==='consent'?'Please confirm you agree to be contacted about this request.':first.name==='email'?'Enter a valid business email address.':'Please complete the highlighted field.','error');return;}
  btn.disabled=true;say('Sending your request…');const d=Object.fromEntries(new FormData(form));d.consent=form.elements.consent.checked;
  try{const r=await fetch('/api/product-interest',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(d)});const x=await r.json();if(!r.ok)throw Error(r.status===429?'Too many requests. Please try again later.':(x.detail||'Could not send request.'));
   const product=x.product||d.product;const mail=['accepted_by_mail_server','accepted_by_provider'].includes(x.email_status)?' A confirmation email was accepted by our email provider; delivery to your inbox is not guaranteed.':' No confirmation email was sent'+(x.email_status==='not_configured'?' because email is not configured yet.':' at this time.');
   say((x.existing?'We already have your request for ':'Request received for ')+product+'. This is not an approval or invitation.'+mail,'success');form.reset();if(preset&&select)select.value=preset;}
  catch(x){say(x.message,'error');}finally{btn.disabled=false;}});}
