'use strict';
// Accounts on every brand page. Forms post only to this site's own API (same origin, JSON, no third parties).
// Pages without an account section get header buttons that open an account panel for that brand.
(()=>{
 const post=async(path,data)=>{
  const r=await fetch('/api/'+path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data),credentials:'same-origin',cache:'no-store'});
  let j={};try{j=await r.json();}catch{}
  if(!r.ok){const d=j.detail;throw Error(typeof d==='string'?d:'Something went wrong. Please check the form and try again.');}
  return j;
 };
 const sent=s=>s==='accepted_by_provider'||s==='accepted_by_mail_server';
 const WS={'Avëzqi':'avezqi','Mëvqi':'mevqi','Naëqo':'naeqo','Sharim':'sharim','Vëqzi':'veqzi','Ëzqir':'ezqir'};
 // One delegated handler, so forms added later (the account panel) work too.
 document.addEventListener('submit',async e=>{
  const f=e.target.closest('form[data-auth]');if(!f)return;
  e.preventDefault();if(!f.reportValidity())return;
  const status=f.querySelector('.gz-status'),button=f.querySelector('button[type="submit"]'),label=button.textContent;
  const v=Object.fromEntries(new FormData(f)),kind=f.dataset.auth,product=f.dataset.product;
  button.disabled=true;button.textContent='Working…';status.textContent='';status.dataset.state='';
  try{
   let msg='';
   if(kind==='request'){
    const r=await post('product-interest',{name:v.name,email:v.email,company:v.company,note:v.note||'',product,consent:!!(f.elements.consent&&f.elements.consent.checked)});
    msg=r.existing?'We already have your request. We will be in touch.':'Request received. '+(sent(r.email_status)?'A confirmation email is on its way. ':'')+'We will review it and contact you.';
   }else if(kind==='code'){
    const r=await post('register',{name:v.name,email:v.email,password:v.password,invite:v.invite,company:v.company||''});
    msg=r.verification_required===false?'Account created. You can sign in now.':'Account created. '+(sent(r.email_status)?'Check your email to verify it, then sign in.':'Verify your email before signing in. If the email does not arrive, use password recovery to request a new link.');
   }else if(kind==='signup'){
    const r=await post('signup',{name:v.name,email:v.email,password:v.password,product,terms:!!(f.elements.terms&&f.elements.terms.checked)});
    msg=r.verification_required===false?'Account created. You can sign in now.':'Account created. '+(sent(r.email_status)?'Check your email to verify it, then sign in.':'Verify your email before signing in.');
   }else if(kind==='signin'){
    await post('login',{email:v.email,password:v.password});
    let s={};try{s=await (await fetch('/api/account/summary',{credentials:'same-origin',cache:'no-store'})).json();}catch{}
    const workspace=WS[product]||'worlds';
    location.href=s.account_type==='customer'?'/my-account/':'/app.html#'+workspace;
    return;
   }
   status.textContent=msg;status.dataset.state='ok';f.reset();
  }catch(err){status.textContent=err.message;status.dataset.state='error';}
  finally{button.disabled=false;button.textContent=label;}
 });
 // Footer Cookie Settings buttons open the cookie preference centre.
 document.addEventListener('click',e=>{if(e.target.closest('.gz-cookie')){const o=document.querySelector('.cookie-settings-v2');if(o)o.click();}});

 /* ---------- Account panel for pages without an account section ---------- */
 const seg=(location.pathname.split('/')[1]||'').toLowerCase();
 const key={avezqi:'avezqi',avelis:'avezqi',products:'avezqi',demo:'avezqi',experience:'avezqi',mevqi:'mevqi',ama:'mevqi',naeqo:'naeqo',sharim:'sharim',veqzi:'veqzi',kavera:'veqzi'}[seg]||(document.body.dataset.brand||'');
 const B={
  avezqi:{name:'Avëzqi',mode:'access',acc:'#4f0e2b',ink:'#fff',tint:'#f7efe3'},
  mevqi:{name:'Mëvqi',mode:'access',acc:'#123e2f',ink:'#fff',tint:'#eef5e1'},
  veqzi:{name:'Vëqzi',mode:'access',acc:'#082a44',ink:'#fff',tint:'#e8f4f5'},
  naeqo:{name:'Naëqo',mode:'open',acc:'#071474',ink:'#fff',tint:'#eef1ff'},
  sharim:{name:'Sharim',mode:'open',acc:'#1b5fd0',ink:'#fff',tint:'#eef3fd'}}[key];
 if(!B||document.querySelector('#join form[data-auth]'))return; // Ëzqir has no public accounts; brand homepages already have their section.
 const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
 const field=(label,type,name,ph,extra='')=>`<label class="ap-field"><span>${label}</span><input type="${type}" name="${name}" placeholder="${esc(ph)}" ${extra}></label>`;
 const check=(name,html)=>`<label class="ap-check"><input type="checkbox" name="${name}" required><span>${html}</span></label>`;
 const form=(auth,title,sub,fields,btn,note)=>`<form data-auth="${auth}" data-product="${B.name}" class="ap-form" hidden><h3>${title}</h3><p class="ap-sub">${sub}</p>${fields}<button type="submit" class="ap-btn">${btn}</button><p class="gz-status" role="status" aria-live="polite"></p><p class="ap-note">${note}</p></form>`;
 const signin=form('signin','Welcome back',`Sign in to your ${B.name} account.`,field('Email','email','email','you@example.com','required autocomplete="email"')+field('Password','password','password','Your password','required autocomplete="current-password"'),'Sign in','<a href="/account/?action=forgot">Forgot your password?</a> We will email a single-use recovery link.');
 const tabs=B.mode==='open'?[['signin','Sign in'],['signup','Create account']]:[['signin','Sign in'],['code','Invitation code'],['request','Request access']];
 const forms=B.mode==='open'?signin+form('signup',`Create your ${B.name} account`,'Sign up with your email. No invitation needed.',field('Full name','text','name','Your name','required autocomplete="name"')+field('Email','email','email','you@example.com','required autocomplete="email"')+field('Password','password','password','At least 12 characters','required minlength="12" autocomplete="new-password"')+check('terms','I agree to the <a href="/terms/">Terms</a> and <a href="/privacy.html">Privacy notice</a>.'),'Create account','You may be asked to confirm your email address before signing in.')
  :signin+form('code','Join with your invitation',`Invited to ${B.name}? Use the code from your invitation.`,field('Invitation code','text','invite','Paste your code','required autocomplete="off"')+field('Full name','text','name','Your name','required autocomplete="name"')+field('Email','email','email','The invited email address','required autocomplete="email"')+field('Company','text','company','Only if you are setting up a new organization','autocomplete="organization"')+field('Password','password','password','At least 12 characters','required minlength="12" autocomplete="new-password"'),'Create account','Codes are single-use and tied to the invited email address.')
   +form('request',`Bring ${B.name} to your organization`,'Tell us who you are and we will be in touch.',field('Full name','text','name','Your name','required autocomplete="name"')+field('Work email','email','email','you@company.com','required autocomplete="email"')+field('Organization','text','company','Company name','required autocomplete="organization"')+check('consent',`I agree to be contacted about ${B.name}. See the <a href="/privacy.html">Privacy notice</a>.`),'Send access request','Requests are stored securely and are not a commitment from either side.');
 const wrap=document.createElement('div');wrap.className='ap-overlay';wrap.hidden=true;
 wrap.style.setProperty('--ap-acc',B.acc);wrap.style.setProperty('--ap-ink',B.ink);wrap.style.setProperty('--ap-tint',B.tint);
 wrap.innerHTML=`<div class="ap-dialog" role="dialog" aria-modal="true" aria-labelledby="ap-title" tabindex="-1"><div class="ap-top"><div><p class="ap-kicker">✦ ${B.name} account</p><h2 id="ap-title">${B.mode==='open'?'Sign in or create an account':'Sign in, join or request access'}</h2></div><button type="button" class="ap-x" aria-label="Close account panel">×</button></div><div class="ap-tabs" role="tablist">${tabs.map(([k,t])=>`<button type="button" role="tab" class="ap-tab" data-tab="${k}" aria-selected="false">${t}</button>`).join('')}</div>${forms}</div>`;
 document.body.append(wrap);
 const dialog=wrap.querySelector('.ap-dialog');let last=null;
 const show=tab=>{wrap.querySelectorAll('.ap-tab').forEach(t=>t.setAttribute('aria-selected',String(t.dataset.tab===tab)));wrap.querySelectorAll('.ap-form').forEach(f=>f.hidden=f.dataset.auth!==tab);};
 const open=tab=>{last=document.activeElement;show(tab);wrap.hidden=false;document.documentElement.classList.add('ap-lock');const first=wrap.querySelector('.ap-form:not([hidden]) input');(first||dialog).focus();};
 const close=()=>{wrap.hidden=true;document.documentElement.classList.remove('ap-lock');if(last&&last.focus)last.focus({preventScroll:true});};
 wrap.addEventListener('click',e=>{if(e.target===wrap||e.target.closest('.ap-x'))close();const t=e.target.closest('.ap-tab');if(t){show(t.dataset.tab);const i=wrap.querySelector('.ap-form:not([hidden]) input');if(i)i.focus();}});
 wrap.addEventListener('keydown',e=>{if(e.key==='Escape')close();if(e.key==='Tab'){const f=[...dialog.querySelectorAll('button,a[href],input')].filter(x=>!x.closest('[hidden]'));const a=f[0],z=f[f.length-1];if(e.shiftKey&&document.activeElement===a){e.preventDefault();z.focus();}else if(!e.shiftKey&&document.activeElement===z){e.preventDefault();a.focus();}}});
 // Header buttons
 const header=document.querySelector('.pd-header,.dm-top-in,header');
 const actions=document.createElement('div');actions.className='ap-actions';
 const primary=B.mode==='open'?['signup','Sign up']:['request','Request access'];
 actions.innerHTML=`<button type="button" class="ap-hbtn ghost" data-open="signin">Sign in</button>${B.mode==='access'?'<button type="button" class="ap-hbtn ghost ap-hide-sm" data-open="code">Invitation code</button>':''}<button type="button" class="ap-hbtn" data-open="${primary[0]}">${primary[1]}</button>`;
 actions.style.setProperty('--ap-acc',B.acc);
 if(header)header.append(actions);else{actions.classList.add('ap-floating');document.body.append(actions);}
 actions.addEventListener('click',e=>{const b=e.target.closest('[data-open]');if(b)open(b.dataset.open);});
 // Signed in already: swap the header buttons for a link to the right account area.
 fetch('/api/account/summary',{credentials:'same-origin',cache:'no-store'}).then(r=>r.ok?r.json():null).then(s=>{if(!s)return;const l=document.createElement('a');l.className='ap-hbtn';l.href=s.account_type==='customer'?'/my-account/':'/app.html';l.textContent=s.account_type==='customer'?'My account':'Open workspace';actions.replaceChildren(l);}).catch(()=>{});
 // Any link to the brand's #join on a page without that section opens the panel instead.
 document.addEventListener('click',e=>{const a=e.target.closest('a[href$="#join"]');if(!a)return;const u=new URL(a.href,location.href);if(u.pathname===location.pathname){e.preventDefault();open(B.mode==='open'?'signup':'request');}});
 if(location.hash==='#account')open('signin');
 window.avezqiAccount={open};document.addEventListener('avezqi:open-account',e=>open((e.detail&&e.detail.tab)||'signin'));
})();
