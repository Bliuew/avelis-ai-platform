'use strict';
(()=>{
const f=document.querySelector('#booking'),s=document.querySelector('#status'),title=document.querySelector('#event-title'),zoneEl=document.querySelector('#zone'),cancelBox=document.querySelector('#cancel');
const params=new URLSearchParams(location.search),id=params.get('event');
const zone=(()=>{try{return Intl.DateTimeFormat().resolvedOptions().timeZone||''}catch{return ''}})();
const label=t=>new Date(t*1000).toLocaleString(undefined,{dateStyle:'full',timeStyle:'short'});
const okMail=x=>['accepted_by_mail_server','accepted_by_provider'].includes(x);
function say(text,kind){s.textContent=text;s.className=kind||'';}

// Cancellation link from a confirmation email: /book/?cancel=1#token=…
if(params.get('cancel')==='1'){
  const token=new URLSearchParams(location.hash.slice(1)).get('token')||'';
  history.replaceState(null,'',location.pathname+'?cancel=1');
  title.textContent='Cancel your appointment';f.hidden=true;cancelBox.hidden=false;
  if(!token){say('This cancellation link is incomplete. Use the full link from your confirmation, or contact the organizer.','error');cancelBox.querySelector('button').disabled=true;return;}
  cancelBox.addEventListener('submit',async e=>{e.preventDefault();const b=cancelBox.querySelector('button');b.disabled=true;say('Cancelling…');
    try{const r=await fetch('/api/booking-cancel',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({token}),cache:'no-store'}),x=await r.json();if(!r.ok)throw Error(x.detail||'Could not cancel.');
      cancelBox.hidden=true;say('Cancelled: '+x.title+' — '+label(x.start)+'. The organizer has been notified if email is configured.'+(okMail(x.email_status)?' A cancellation notice was accepted by the email provider.':''),'success');}
    catch(err){say(err.message,'error');b.disabled=false;}});
  return;
}

if(!id){title.textContent='Booking link incomplete';say('Open the full booking link shared by the organizer.','error');return;}
const endpoint='/api/booking/'+encodeURIComponent(id);
async function load(){say('');
  try{const r=await fetch(endpoint,{cache:'no-store'}),d=await r.json();if(!r.ok)throw Error(d.detail||'Booking page unavailable.');
    title.textContent=d.title+' · '+d.duration+' min';zoneEl.textContent=zone?'Times are shown in your time zone: '+zone+'.':'Times are shown in your device’s local time.';
    f.elements.start.replaceChildren(...d.slots.map(t=>new Option(label(t),t)));f.hidden=!d.slots.length;
    if(!d.slots.length)say('No times are available right now. Please check back later or contact the organizer.');}
  catch(e){title.textContent='Booking unavailable';say(e.message||'Unable to load booking.','error');}}
f.addEventListener('submit',async e=>{e.preventDefault();const b=f.querySelector('button[type=submit]');
  if(!f.reportValidity())return;b.disabled=true;say('Confirming your appointment…');
  const d=Object.fromEntries(new FormData(f));d.consent=f.elements.consent.checked;d.timezone=zone;
  try{const r=await fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(d)}),x=await r.json();
    if(r.status===409){await load();throw Error(x.detail||'That time was just taken. Please choose another.');}
    if(!r.ok)throw Error(x.detail||'Could not book.');
    f.hidden=true;
    say('Appointment booked with '+x.host+' — '+label(x.start)+'. Reference: '+x.id+'. '+(okMail(x.email_status)?'A confirmation was accepted by the email provider; check your inbox.':'No confirmation email was sent. Save this page’s details and your cancellation link below.'),'success');
    const done=document.querySelector('#done');done.hidden=false;
    const cancelLink=done.querySelector('#cancel-link');cancelLink.href='/book/?cancel=1#token='+encodeURIComponent(x.cancel_token);
    if(x.meeting_link){const a=done.querySelector('#meeting-link');a.href=x.meeting_link;a.hidden=false;}
  }catch(err){say(err.message,'error');}finally{b.disabled=false;}});
load();
})();
