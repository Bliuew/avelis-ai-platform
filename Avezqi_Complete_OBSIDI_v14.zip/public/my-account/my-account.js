'use strict';
// My account dashboard for Naëqo and Sharim customer accounts (website v13).
(()=>{
 const $=s=>document.querySelector(s);let csrf='',profile=null,planOpts=null,devices=[],summary=null;
 const call=async(path,data)=>{const r=await fetch('/api/'+path,{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':csrf},body:JSON.stringify(data||{}),credentials:'same-origin',cache:'no-store'});let j={};try{j=await r.json();}catch{}if(!r.ok){const e=Error(typeof j.detail==='string'?j.detail:'Request could not be completed.');e.status=r.status;throw e;}return j;};
 const get=async p=>{const r=await fetch('/api/'+p,{credentials:'same-origin',cache:'no-store'});let j={};try{j=await r.json();}catch{}if(!r.ok){const e=Error(typeof j.detail==='string'?j.detail:'Request could not be completed.');e.status=r.status;throw e;}return j;};
 const el=(tag,text,cls)=>{const n=document.createElement(tag);if(text!=null)n.textContent=text;if(cls)n.className=cls;return n;};
 const toast=t=>{const n=$('#toast');n.textContent=t;n.classList.add('show');clearTimeout(toast.t);toast.t=setTimeout(()=>n.classList.remove('show'),2600);};
 const save=async patch=>{const body={revision:profile.revision,plan:profile.plan,saved_devices:profile.saved_devices,notifications:profile.notifications,...patch};
  try{profile=await call('customer/profile',body);}catch(e){if(e.status!==409)throw e;profile=await get('customer/profile');profile=await call('customer/profile',{...body,revision:profile.revision});}
  render();return profile;};
 const status=(form,text,state)=>{const s=form.querySelector('.status');s.textContent=text;s.dataset.state=state||'';};

 const renderPlan=()=>{
  const host=$('#plan-body');host.replaceChildren();const p=profile&&profile.plan;
  if(!p||!planOpts){host.append(el('p','You haven’t built a plan yet. Choose data, calling and extras in a minute.','muted'));$('#stat-plan').textContent='—';$('#plan-edit').textContent='Build a plan';return;}
  const d=planOpts.data.find(x=>x.id===p.data),k=planOpts.calling.find(x=>x.id===p.calling);
  const price=el('p',null,'plan-price');price.append(document.createTextNode('$'+p.monthly_cad+' '),el('small','CAD / month, estimated'));host.append(price);
  const ul=el('ul',null,'plan-lines');[d&&d.label+' data',k&&k.label].concat(p.extras.map(e=>(planOpts.extras.find(x=>x.id===e)||{}).label)).concat([p.sim]).filter(Boolean).forEach(t=>ul.append(el('li',t)));host.append(ul);
  $('#stat-plan').textContent='$'+p.monthly_cad+'/mo';$('#plan-edit').textContent='Edit plan';
  const q=new URLSearchParams({service:'Mobile connectivity',budget:String(Math.round(p.monthly_cad/5)*5),plan:'Saved plan: '+[d&&d.label+' data',k&&k.label].filter(Boolean).join(', ')+' (estimated $'+p.monthly_cad+' CAD/month)'});
  if(profile.saved_devices[0])q.set('device',profile.saved_devices[0]);$('#plan-ask').href='/naeqo/connect/?'+q;};

 const renderPhones=()=>{
  const host=$('#saved-phones');host.replaceChildren();const list=(profile&&profile.saved_devices)||[];$('#stat-phones').textContent=String(list.length);
  if(!list.length){host.append(el('p','Tap Save on any phone to keep it here. You can save up to six.','muted'));return;}
  list.forEach(id=>{const d=devices.find(x=>x.id===id);if(!d)return;const card=el('article',null,'phone');const img=el('img');img.src=d.image;img.alt=d.manufacturer+' '+d.name;img.loading='lazy';
   card.append(img,el('strong',d.manufacturer+' '+d.name),el('small',d.display+' · '+d.storage));
   const row=el('div',null,'row');const view=el('a','View','btn ghost');view.href='/naeqo/phones/'+d.id+'/';const ask=el('a','Enquire','btn');ask.href='/naeqo/connect/?service=Device%20enquiry&device='+encodeURIComponent(d.id);
   const rm=el('button','Remove','ghost');rm.type='button';rm.setAttribute('aria-label','Remove '+d.name);rm.addEventListener('click',async()=>{rm.disabled=true;try{await save({saved_devices:profile.saved_devices.filter(x=>x!==id)});toast('Removed '+d.name+'.');}catch(e){toast(e.message);rm.disabled=false;}});
   row.append(view,ask);card.append(row,rm);host.append(card);});};

 const render=()=>{if(!profile)return;renderPlan();renderPhones();const f=$('#notify-form');Object.entries(profile.notifications).forEach(([k,v])=>{if(f.elements[k])f.elements[k].checked=v;});};

 (async()=>{
  try{
   const r=await fetch('/api/account/summary',{credentials:'same-origin',cache:'no-store'});
   if(r.status===401){$('#state').hidden=true;$('#signed-out').hidden=false;return;}
   const s=await r.json();if(!r.ok)throw Error(s.detail||'Could not load your account.');
   if(s.account_type!=='customer'){location.replace('/app.html');return;}
   summary=s;csrf=s.csrf;const first=s.name.split(' ')[0];
   $('#hello').textContent='Hi, '+first;$('#name').textContent=s.name;$('#email').textContent=s.email;$('#product').textContent=s.product+' account';$('#sessions').textContent=String(s.active_sessions);
   $('#name-sessions').textContent=s.active_sessions===1?'1 device':s.active_sessions+' devices';$('#product-kicker').textContent=s.product+' member';
   $('#profile-form').elements.name.value=s.name;
   const naeqo=s.product==='Naëqo';$('#naeqo-services').hidden=!naeqo;
   $('#lead').textContent=naeqo?'Your plan, saved phones and enquiries, in one place.':'Your Sharim modules and settings, in one place.';
   if(!naeqo){$('#stat-plan').parentElement.querySelector('dt').textContent='Modules';$('#stat-plan').textContent='4';$('#stat-phones').parentElement.hidden=true;}
   $('#state').hidden=true;$('#details').hidden=false;
   const [p,o,d]=await Promise.all([get('customer/profile'),get('naeqo/plan-options').catch(()=>null),fetch('/device-catalog.json',{cache:'no-store'}).then(x=>x.json()).catch(()=>[])]);
   profile=p;planOpts=o;devices=d;render();
  }catch(e){$('#state').textContent=e.message;}
 })();

 const pf=$('#profile-form');pf.addEventListener('submit',async e=>{e.preventDefault();if(!pf.reportValidity()||!profile)return;status(pf,'Saving…');
  try{await save({name:pf.elements.name.value.trim()});$('#hello').textContent='Hi, '+profile.name.split(' ')[0];status(pf,'Profile saved.','ok');}catch(err){status(pf,err.message,'error');}});
 const nf=$('#notify-form');nf.addEventListener('submit',async e=>{e.preventDefault();if(!profile)return;status(nf,'Saving…');
  const n={};['enquiry_updates','new_phones','offers'].forEach(k=>n[k]=nf.elements[k].checked);
  try{await save({notifications:n});status(nf,'Your choices are saved.','ok');}catch(err){status(nf,err.message,'error');}});
 const f=$('#password');f.addEventListener('submit',async e=>{e.preventDefault();if(!f.reportValidity())return;status(f,'Updating…');
  try{await call('account/password',{current:f.elements.current.value,password:f.elements.password.value});status(f,'Password updated. Other devices have been signed out.','ok');f.reset();}
  catch(err){status(f,err.message,'error');}});
 $('#logout').addEventListener('click',async()=>{try{await call('logout');}catch{}location.href='/';});
 $('#logout-all').addEventListener('click',async()=>{try{await call('account/sessions/revoke');}catch{}location.href='/';});
})();
