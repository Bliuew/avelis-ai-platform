"""Preserve the existing Render founder-invitation bootstrap without logging secrets."""
import os,sys,time
import server
owner_email=os.environ.pop('AVELIS_OWNER_EMAIL','').strip()
owner_invite=os.environ.pop('AVELIS_OWNER_INVITE','').strip()
if owner_email:
    owner_email=server.email(owner_email)
    server.configure_operator(owner_email)

if owner_email and owner_invite:
    owner_email=server.email(owner_email)
    if not 24<=len(owner_invite)<=200:raise SystemExit('Configure a strong founder invitation.')
    with server.db() as connection:
        connection.execute('BEGIN IMMEDIATE')
        if not connection.execute('SELECT 1 FROM users LIMIT 1').fetchone():
            connection.execute('INSERT OR IGNORE INTO invites VALUES(?,?,?,?,0)',(server.digest(owner_invite),None,owner_email,int(time.time())+259200))
os.execv(sys.executable,[sys.executable,'server.py'])
