# Avëzqi website v12 (review build, not deployed)

Prepared 22 November 2026 from the owner-supplied v11 package. `server.py` is unchanged from v11, so `/api/status` still reports `avezqi-industry-browsing-v11`; `/product-release.json` reports `avezqi-website-v12`. Nothing was pushed, deployed, emailed or purchased.

## What changed
- **Accounts on every page.** All 87 brand, product, feature, phone and experience pages now have Sign in plus Sign up or Request access in the header, opening an account panel styled for that brand:
  - Avëzqi, Mëvqi, Vëqzi (and the products hub, walkthrough and experience pages): Sign in, Invitation code, Request access.
  - Naëqo and Sharim: Sign in, Create account (open sign-up with email verification).
  - Ëzqir: no public accounts.
  Forms use the existing real endpoints (`/api/login`, `/api/register`, `/api/signup`, `/api/product-interest`). Form handling is now delegated, so the brand homepages' account sections keep working unchanged.
- **Cookie settings redesigned.** A slim banner (Accept all, Reject all, Customize) and a preference centre with switches for Analytics and Marketing, Essential always on, last-updated time, keyboard focus trap and Escape to close. Same storage key, version and event, so `consent.js` behaves exactly as before.
- **Financing removed again** (it had returned in v11): page, links, directory card, estimator code and wording.
- **No "Planned" or "In development" labels** on any public page; replaced with "Preview" or plain customer wording.
- **Product experience** at `/experience/`: interactive versions of all six companies with sample data, running in the browser (no network requests). v11's server-backed walkthrough stays at `/demo/`.
- **Homepage 60-second tour** restored, leading to the experience page; "Try it" links in every brand navigation and on feature pages.
- **Sub-pages restyled**: glass sticky header, larger type, softer brand-tinted backgrounds, richer cards with hover motion and a cleaner footer.

## Tests
All 17 Python/Node test files and the 2 additional Node UI tests pass. Python tests ran through the test-only FastAPI stand-in (FastAPI could not be installed in this preparation environment); application logic and SQLite are real; email is mocked. New `tests/test_v12_site.py`. `test_catalog_v11.py` now expects 49 feature links (financing removed). Pages were checked in Chrome behind the production Content-Security-Policy at desktop and phone width: cookie banner and preference centre, account panel sign-up and access request payloads, Ëzqir without accounts, the experience page; no script errors and no horizontal overflow.

## Still required for the live site
Configured email (Gmail API on Render), persistent storage, and for Naëqo enquiries an authorized operator organization, as described in REBUILD_REVIEW_V11.md. Manufacturer product images remain as supplied in v11; see the owner's earlier guidance about permissions.
