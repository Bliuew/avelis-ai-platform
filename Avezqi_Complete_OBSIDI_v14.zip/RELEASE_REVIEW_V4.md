# Avëzqi Phase I — repair build v4 (review only)

Prepared November 20, 2026 from the owner-supplied `Avezqi_Phase_I_Updated_Platform.zip` (review build v3). Nothing was pushed, deployed, emailed or purchased. The live website is unchanged. This note supersedes earlier build-status notes.

## Deployment facts checked

- Repository `Bliuew/avelis-ai-platform` has one branch, `main`. Its outer `Dockerfile` unpacks **`Avezqi_Phase_I_Updated_Platform.zip`** and requires `server.py`, `requirements.txt` and `public/` at the archive root.
- The ZIP currently in the repository is **older** than v3: it has no Gmail API transport. The live site therefore cannot send mail on Render's free plan.
- Render free web services block outbound SMTP ports 25, 465 and 587. Use `AVELIS_MAIL_TRANSPORT=gmail_api` (see GMAIL_SETUP.md).
- Render free web services have no persistent disk. SQLite data (accounts, requests, bookings) is lost on redeploy or restart. Production needs a paid instance with a persistent disk mounted at `/app/data`, plus `ops/backup_database.py` run on a schedule with a tested restore.
- Dependencies are Python only (`fastapi`, `uvicorn`). Nothing in the project uses Ruby.

## Repairs

1. **Sign-up no longer spends an invitation when mail is unconfigured.** It returns 503 before touching the invitation, so the same invitation works once mail is configured. The sign-up form shows this state in advance. `/api/status` reports `mail: configured | not_configured` (configuration only, not delivery).
2. **Account settings** (workspace › Account & settings): account details; change password (current password required, CSRF-protected, rate-limited; signs out other sessions and voids unused recovery links); sign out everywhere. Controls that are not implemented are listed as text, not dummy buttons: email change, MFA, member removal/role change, account deletion.
3. **Mëvqi Schedule**: customer cancellation via a hashed, single-use link. The link expires when the meeting starts, is refused after a host cancellation, and notifies the host. Confirmations show the customer's IANA time zone plus UTC; an invalid zone falls back to UTC. The booking page shows the cancellation link, clear loading, empty, conflict, success and error states, and refreshes slots after a conflict.
4. **Send Access Request**: product picker (Avëzqi, Mëvqi, Naëqo, Vëqzi, Sharim; no Ëzqir) preselected from `?product=`, field-level validation, a per-email limit (5/hour) on top of the per-IP limit, and confirmation email using the current public name. Messages distinguish "recorded", "accepted by email provider" and "not sent". Internal product keys are unchanged.
5. **Avëzqi page**: each of the seven specialists marked Available in part / Planned; the Discover → Understand → Govern → Simulate → Approve → Execute → Verify sequence; founder headquarters described as planned with authorized access only; ownership line (Ditheka Intelligence within Umoja Network, part of Kubézema).
6. **Naëqo**: transparent billing, urgent help without mandatory appointments, verified outage notices, qualifying credits and backup connectivity, all stated as proposed. **Ëzqir/Vëqzi**: product-specific readiness statements replace the generic payments/suppliers text.
7. **Cookies**: panel announced as a labelled dialog; "Save Preferences" and "Cookie Settings" labels; Escape closes once a choice exists; choosing no longer scrolls the page to the footer.
8. **Navigation/layout**: workspace responds to Back/Forward and hash links; Vëqzi workspace card uses `/veqzi/`; informational Naëqo card added; descriptive page titles; side padding restored on all editorial sub-pages (a CSS cascade had reset it to 0).
9. Legacy routes (`/avelis/`, `/ama/`, `/eziro/`, `/kavera/`) remain byte-identical copies of the current pages.

Schema change is additive only: new table `ama_booking_cancel`. No existing table or column was altered or removed.

## Tests

Run: `python -m pip install -r requirements.txt httpx`, then `python tests/<name>.py` for each test file and `node tests/test_consent.cjs`.

**Important:** in the preparation environment FastAPI could not be installed, so the Python tests ran through a small test-only stand-in for FastAPI's routing/request/response layer. The stand-in is not included in this ZIP. All application logic (SQLite, hashing, tokens, rate limits, CSRF/origin middleware, booking locks) ran unchanged. As a control, the v3 suite was run through the same stand-in and passed 7/7, matching the v3 report. **Re-run the suite with real FastAPI before release.**

| Test | Result | Provider calls |
|---|---|---|
| test_app, test_operational, test_release, test_account_security, test_mail_unavailable, test_public_assets (existing) | Pass | Mail mocked |
| test_gmail_transport (existing) | Pass | Google endpoints mocked |
| test_repairs_v4 (new): invitation preservation; change password; sign out everywhere; 8 concurrent bookings for one host across two pages → exactly 1; customer cancellation; time zones; tenant isolation; request persistence and limits | Pass | Mail mocked |
| test_brand_pages (new): six routes, logo files, exact taglines, no retired names, no Ëzqir request path, specialist status | Pass | None |
| test_consent.cjs (existing) | Pass | None |

A mutation check confirmed the concurrency test fails (3 of 8 bookings succeeded) when the booking transaction lock is removed.

**Browser (real Chrome, desktop 1440×900 and phone 390×844)**, against a local HTTP bridge to the same stand-in with mail captured to a file: homepage opens directly; Reject/Accept/Manage/Save; a registered optional loader is blocked before consent, starts on Save and stops on withdrawal; choice persists across brand pages; six brand logos decode; skip link is the first Tab stop; request with validation and success; invitation sign-up → sign-in refused until verified → verify link (token removed from address bar, second use refused) → sign-in → change password error and success; public booking → cancellation link → availability restored; phone menu opens/closes with Escape; no horizontal overflow on 11 routes at 390 px.

**Not tested:** real FastAPI/uvicorn; HTTPS cookie transport on Render; Gmail OAuth or any real email delivery; Render disk durability; screen-reader or full WCAG audit; Safari/Firefox.

## Still open (not built, deliberately)

Six of seven specialists, founder headquarters, server-side reviewer access (not present in the supplied source), Engage's five steps (labels not recovered), calendar sync, native calling, Naëqo carrier/supplier/financing services, Sharim payments and wallets, and the Ëzqir/Vëqzi platforms. The homepage's illustrative dashboard (labelled "Illustrative figures only · Not customer metrics") is kept as part of the approved composition; remove its numbers if you prefer no figures at all.

## Release steps (owner approval required)

1. Create a non-production branch or staging service. Do not upload to `main` first, since Render auto-deploys it.
2. Add this build as `Avezqi_Phase_I_Updated_Platform.zip` (the filename the outer Dockerfile expects), or update the Dockerfile's `COPY` line.
3. In Render, set Gmail variables privately (GMAIL_SETUP.md) and confirm `/api/status` shows `release: avezqi-phase1-repair-v4` and `mail: configured`.
4. With a controlled address, confirm real verification and recovery emails arrive and their links work.
5. Before real users: move to a plan with a persistent disk, set `AVELIS_DB=/app/data/avelis.sqlite3`, and test backup and restore.
