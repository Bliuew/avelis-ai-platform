# Investor walkthrough - local review, not deployed

A short interactive walkthrough at /demo/ runs actual backend actions in an isolated expiring example-data session: create/qualify an opportunity, save one example appointment, calculate CSV statistics and download a report. The automatic sequence takes about 30 seconds, excluding network time. Users can pause or operate controls manually.

The session has a separate opaque HttpOnly/SameSite cookie, hashed identifier, CSRF token, rate limits and 30-minute expiry. It grants no user/org privileges. Example data lives only in demo_sessions, not live contacts, opportunities, appointments or leads. Expired sessions are rejected and cleaned when a new session starts. No emails or external provider calls are made. Never present this as company traction or live commercial operations.

CSV calculations are shared with the existing authenticated analysis endpoint. Raw CSV is not retained. The example dataset may be edited or replaced with a small non-confidential CSV.

This is a functional walkthrough of core business software, not completion of all six companies' roadmaps. Email delivery, carrier services, lender/financing arrangements, payment processing and specialist security infrastructure remain unconnected unless separately configured and verified. No financing negotiation or commercial relationship is claimed. Previously requested device-financing scope has not been removed based on ambiguous wording.

No production website, repository, environment variables, credentials or deployment were changed. Existing private access controls remain. Review before uploading to an auto-deploying branch.

Verification: the investor walkthrough tests, existing app workflow tests, release/scheduling tests, account-security tests and 69-page product-destination tests passed. JavaScript and Python syntax checks passed. Desktop browser autoplay completed all three chapters and displayed the saved example appointment and computed report (Revenue_CAD total 4,800; mean 1,600). Mobile-device and complete accessibility testing remain outstanding. No real email delivery or external commercial transaction was tested.
