# Connected workspaces v9 — navigation repair, not deployed

The existing business account, customer signup, invitation code, access request, password recovery and email-verification processes remain. This release repairs destinations and navigation; it does not replace the approved public designs or introduce a different authentication system.

## Repairs

- The signed-in Your Worlds launcher includes all six brands, including the missing Ëzqir entry. All six open brand destinations inside the existing app.html workspace.
- Each brand destination includes switches to the other five brands, reusing the current same-origin session and organization. Existing tools remain in the sidebar and retain their original CRUD behavior.
- Each public brand homepage has an Open workspace link with the matching app.html fragment. Existing forms are unchanged.
- A successful business sign-in from a brand page retains that brand destination instead of always returning to a generic landing view. Naëqo/Sharim customer accounts still go to their customer account page and do not gain business-workspace access.
- Avëzqi opens existing analytics, overview, integration, AI and governance tools. Mëvqi opens its existing business tools. Naëqo opens its catalog, enquiry and tracking journeys and, for the designated owner, the real enquiry queue.
- Sharim retains existing commerce behavior and includes routes to the original card collection and payment-method details. No external payment connection is added.
- Vëqzi displays existing account identity and workspace membership, with links to the existing account-security controls. It is not a newly implemented external identity provider.
- Ëzqir's owner workspace summarizes existing organization activity and integration records. Other members see a restriction message. This is not a new private security infrastructure or network-protection engine; no new privileged data APIs are added or granted.

## Verification

JavaScript syntax checks and the six-destination render/navigation regression test passed. Existing product-destination checks passed (72 pages and 137 internal links/assets). Real backend account-security, release/scheduling and Naëqo service-enquiry tests passed. Backend server.py, consent controls and customer-account code are byte-identical to v8. All six public brand form blocks are byte-identical to v8. Existing app behavior outside the navigation list is byte-identical to v8.

Browser QA verified the public Vëqzi workspace link reaches app.html#veqzi and preserves the existing sign-in boundary and recovery links. Protected workspace render/binding behavior was exercised by the Node regression harness, not a signed-in browser session; full authenticated cross-browser/mobile QA remains outstanding. Test mail is captured only by test fixtures. Real email delivery was not verified.

## Release boundaries

This connects the existing experiences; it does not complete every feature in each brand's product scope. External payment processing, carrier activation and specialist security infrastructure are unchanged. The v8 Naëqo operating-organization, durable-storage and backup setup requirements still apply. Existing email delivery requirements remain.

No live website, repository branch, environment variable or deployment was changed. Review this package before uploading to an auto-deploying branch. After an approved deployment, /product-release.json should report avezqi-connected-workspaces-v9.
