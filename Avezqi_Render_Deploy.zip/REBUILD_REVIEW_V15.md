# Rebuild review v15 · walkthroughs on the website
Builds on v14 (security checklist). Not deployed.
- Added the nine UI/UX collections as website pages with every screen, the see/click/next notes and a downloadable PDF (images as WebP, PDFs compressed to 2-3 MB).
- "See how it works" links added to every brand homepage and its legacy mirror; "All walkthroughs" on the Avëzqi homepage.
- Naëqo website walkthrough has no financing (owner instruction); 17 screens.
- Fixed phone-screen styling in the Mëvqi, Naëqo, Ëzqir, Vëqzi, Sharim and account collections.
- New test: tests/test_v15_walkthroughs.py. All Python test files pass.
