# Avëzqi deployment package v12

Website v12 (product-release.json: avezqi-website-v12; the server is unchanged, so /api/status still reports avezqi-industry-browsing-v11). Prepared for review; not deployed.

This outer ZIP contains the full inner source archive and the Dockerfile designed for the repository's archive-based build. Read REBUILD_REVIEW_V12.md for current changes (and REBUILD_REVIEW_V11.md inside the application archive for the enquiry setup), tests and configuration requirements. Older reviews are historical.

When you approve deployment, extract this OUTER ZIP on your computer. Place its Avezqi_Render_Deploy.zip (this original downloaded archive) and its Dockerfile together in the GitHub repository root. The Dockerfile copies the outer archive and extracts Avezqi_Phase_I_Updated_Platform.zip from it during the build. Do not upload a renamed archive, a folder enclosing the archive, or only a stale sibling inner ZIP. If automatic deployment is enabled, a commit to the connected branch can trigger a live deployment; do not commit before you intend to release.

Retain existing secrets and database configuration. This package contains no user database, passwords, provider keys or founder invitation. Confirm persistent storage and a recoverable database backup before release. Keep the existing SQLite installation on a single instance. Do not reset the database.

The Naëqo public catalogue is browsable without sign-in. Accepting enquiries requires an authorized operator organization; see the review. Email verification and password recovery require the actual configured mail transport. Carrier and payment services require their own real provider connections. Adding Ruby is not necessary for this Python application.

After an approved rebuild, /product-release.json must report avezqi-website-v12 and /api/status avezqi-industry-browsing-v11. Check the public /products/ page, phone filters, a selected-model enquiry, existing account flows and authorized private tools on desktop and phone. Test actual email delivery and restart persistence separately. Preserve the previous application archive and verified database backup for rollback.
