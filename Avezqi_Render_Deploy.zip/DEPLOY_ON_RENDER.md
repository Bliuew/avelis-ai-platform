Review build only. To deploy after approval, the repository root needs Avezqi_Render_Deploy.zip and the Dockerfile contained here. This Dockerfile extracts this outer bundle and its inner application ZIP. Do not upload to an auto-deploying branch until the release is approved.

Version 7 review: /demo/ is a short interactive example-data walkthrough. See INVESTOR_WALKTHROUGH_REVIEW.md for scope and tested boundaries. Review before upload to any auto-deploying branch; this package has not been deployed.

Version 8: see NAEQO_CUSTOMER_JOURNEY_REVIEW.md before release. AVELIS_NAEQO_ORG_ID must point to the intended existing operating organization; enquiry submission stays disabled until this is configured. Durable database storage and backups are required before real customer collection. This package has not been deployed.

Version 9: CONNECTED_WORKSPACES_REVIEW.md documents the six connected destinations and preserved account flows. No live deployment has been made. Review before uploading to an auto-deploying branch.
