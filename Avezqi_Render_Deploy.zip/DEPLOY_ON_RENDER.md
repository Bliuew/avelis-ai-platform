# Deploying the Avëzqi website on Render

This package is ready for your existing setup: GitHub repository **Bliuew/avelis-ai-platform** (branch `main`) deploying to Render service **avelis-ai-platform** with Docker. Nothing has been pushed or deployed for you.

## What is in this package
| File | Purpose |
|---|---|
| `Avezqi_Phase_I_Updated_Platform.zip` | The application (server.py, requirements.txt, public/ website, tests, docs). Replaces the file of the same name in your repository. |
| `Dockerfile` | Identical to the Dockerfile already in your repository. Included for reference; no change needed. |
| `DEPLOY_ON_RENDER.md` | This guide. |
| `CHANGED_FILES.txt` | Files changed or added since repair build v4. |

The archive keeps its original name on purpose: your Dockerfile unpacks exactly `Avezqi_Phase_I_Updated_Platform.zip` and requires `server.py`, `requirements.txt` and `public/` at its root.

## 1. Set Render environment variables (before deploying)
In Render → avelis-ai-platform → Environment:
- `AVELIS_ORIGIN` = `https://avelis-ai-platform.onrender.com` (or your custom domain, exactly, with https and no trailing slash). Forms are refused without it.
- Email (required for sign-up, invitation sign-up, verification and password recovery). Render's free plan blocks SMTP, so use the Gmail API (see GMAIL_SETUP.md inside the archive):
  - `AVELIS_MAIL_TRANSPORT` = `gmail_api`
  - `AVELIS_MAIL_FROM`, `AVELIS_GMAIL_CLIENT_ID`, `AVELIS_GMAIL_CLIENT_SECRET`, `AVELIS_GMAIL_REFRESH_TOKEN`
- First owner invitation (only used while there are no users): `AVELIS_OWNER_EMAIL` and `AVELIS_OWNER_INVITE` (a random code of 24–200 characters). Remove both after the owner account exists.
- Optional: `OPENAI_API_KEY` and `OPENAI_MODEL` for the Advisor™ assistant features.

Enter secrets only in Render's dashboard. Never commit them to GitHub or paste them into chat.

## 2. Keep your data (strongly recommended)
Render's free plan has no persistent disk: accounts, access requests and bookings are erased on every deploy or restart. For real use, upgrade the service to a paid instance, add a persistent disk mounted at **`/app/data`**, and schedule `ops/backup_database.py` with a tested restore. The database path defaults to `/app/data/avelis.sqlite3` (`AVELIS_DB` can override it).

## 3. Deploy
1. In GitHub, open Bliuew/avelis-ai-platform on branch `main`.
2. Replace `Avezqi_Phase_I_Updated_Platform.zip` with the one from this package (Add file → Upload files, same name). Leave the Dockerfile as it is.
3. Commit. Render auto-deploys `main`; watch the deploy log until it reports the service is live.

## 4. Check the live site
- `https://<your-site>/api/status` shows `"release": "avezqi-website-v5"` and `"mail": "configured"`.
- Open `/`, `/mevqi/`, `/naeqo/`, `/sharim/`, `/veqzi/`, `/ezqir/` on desktop and phone.
- Avëzqi, Mëvqi or Vëqzi: send an access request and confirm the email arrives.
- Naëqo or Sharim: sign up with a test address, open the verification email, sign in; you should land on `/my-account/`. Change the password and sign out.
- Invitation sign-up: use the owner invitation from step 1 on any of the Avëzqi, Mëvqi or Vëqzi pages, verify, sign in; you should land in the workspace.
- Use "Forgot your password?" and confirm the recovery email arrives.
- Click Cookie Settings in a footer and save a choice.

## Roll back
In GitHub, revert the commit that replaced the archive (or upload the previous archive). Render redeploys automatically.

## Good to know
- Naëqo and Sharim accounts are customer accounts only. They cannot open the business workspace; workspace access still requires an invitation.
- Ëzqir has no sign-up or access request by design.
- Services described as planned or awaiting agreements are labelled that way on the pages; nothing claims live payments, carrier service or certifications.
