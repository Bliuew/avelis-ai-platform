Review build only. To deploy after approval, the repository root needs Avezqi_Render_Deploy.zip and the Dockerfile contained here. This Dockerfile extracts this outer bundle and its inner application ZIP. Do not upload to an auto-deploying branch until the release is approved.

Version 7 review: /demo/ is a short interactive example-data walkthrough. See INVESTOR_WALKTHROUGH_REVIEW.md for scope and tested boundaries. Review before upload to any auto-deploying branch; this package has not been deployed.
