# Avëzqi connected tools v10 — NOT DEPLOYED

Read REBUILD_REVIEW_V10.md first. This package adds saved product functions across the six connected brands while preserving existing account flows and approved public layouts. It is a review build; it does not claim all commercial services are live.

For an approved Render release, keep Dockerfile and Avezqi_Render_Deploy.zip at the repository root. The Dockerfile unpacks this outer ZIP and its embedded Avezqi_Phase_I_Updated_Platform.zip. Uploading to an auto-deploying main branch changes the live service. Do not do that before release approval, a database backup, durable-storage verification and owner/mail configuration checks.

Keep AVELIS_OWNER_EMAIL set to the intended verified founder/operator. After deployment, the trusted owner can open Naëqo inside the existing workspace and enable the enquiry inbox if it has not been assigned. Existing AVELIS_NAEQO_ORG_ID remains supported. Do not put passwords, invitation codes or API keys in the repository or this ZIP.

After the approved release, /api/status and /product-release.json must both identify avezqi-connected-tools-v10. Test the existing sign-in/signup/invitation/access-request/verification flows, all six workspace entries, actual saved records and database backup/restore. Live payments, phone fulfilment and carrier activation still require provider agreements and integration.
