# Naëqo customer journeys v8 — review package, not deployed

This update preserves the supplied brand compositions, logos, rabbit/fox imagery and existing application. It adds working service-enquiry journeys outside the separate investor example walkthrough.

## What works

- Select one of the three manufacturer-backed models, carry it into an enquiry and choose a manufacturer-listed storage preference.
- Submit device, mobile, home-internet or repair/replacement requirements. For mobile/internet, CAD 25–150 is a customer-entered budget, never a made-up tariff. SIM/eSIM preferences are recorded.
- Persist actual submissions in SQLite. A repeated concurrent submission with the same private key creates only one request. Different payloads cannot silently overwrite that request.
- Return a private reference/key receipt. Only the key hash is stored on the server. The receipt can be downloaded. The current tab session remembers it for tracking; it is not placed in the URL or sent to an email provider.
- Retrieve only service/status/budget/device and customer-visible update, using the reference and private key. Contact details and submitted notes are not returned by the tracking API.
- Authorized verified owners of the configured Naëqo organization can review customer details and post updates. Other organizations, members, unauthenticated visitors and Naëqo/Sharim customer accounts cannot operate the queue. CSRF and revision checks protect updates, which are audited.
- Existing service pages link to these journeys. Naëqo homepage copy now describes browsing and enquiries, with accurate commercial-availability wording.

## Required setup before public acceptance

1. Use the existing secure invited/verified owner account. Do not bypass email verification. Working verification email delivery must be configured separately; this update does not fix the currently unconfigured live mail service.
2. Set **AVELIS_NAEQO_ORG_ID** to the existing Naëqo operating organization ID (the `org` value returned to its signed-in owner by `/api/me`). This is an organization identifier, not a password. Only configure the intended organization. Restart during the approved deployment. Until configured, submission is disabled and APIs reject enquiries with 503, so customer data is never routed to an arbitrary tenant.
3. Set AVELIS_ORIGIN to the exact HTTPS host as required by the existing backend.
4. Store AVELIS_DB on durable hosting storage and include it in the existing SQLite backup procedure. Confirm a backup/restore before accepting real customers. These records are not durable across container replacement if stored only on an ephemeral filesystem.
5. Review the privacy notice, customer communication contact and retention process before collecting real enquiries. Secure saved receipts as private credentials; no email recovery for a lost receipt is implemented.

After approved deployment, verify `/product-release.json` says `avezqi-naeqo-services-v8`; submit a controlled enquiry, review it as the authorized owner, post an update and retrieve that update with the private receipt.

## Verification performed

`tests/test_naeqo_services.py` passed: persistence, concurrent duplicate protection, device/storage/budget validation, consent/origin checks, hashed keys, minimal tracking responses, cross-organization/role/customer isolation, CSRF, revision conflicts, customer updates and audit. Existing product-destination tests passed (72 brand/detail pages); release/scheduling and investor-walkthrough tests passed. Python/JavaScript syntax checks passed.

Desktop browser QA completed phone selection -> actual persisted enquiry -> receipt -> private tracking. Home-internet selection reveals the budget controls. Local tests use isolated disposable storage and an explicitly configured QA organization, never production customer data. Authorized operations were exercised by API tests; no live account was signed into. Full mobile-device/accessibility testing remains outstanding.

## Commercial boundaries

No orders, card transactions, carrier activations, repair appointments, loan inventory, supplier arrangements, financing offers, stock or customer traction were fabricated. These are real enquiries, not accepted commercial orders. No confirmation email is sent or claimed by these new endpoints. This update completes the Naëqo enquiry journey only; it does not claim all six companies' external services are operational. The separate investor example-data walkthrough remains available at `/demo/`.

No live website, GitHub branch, hosting configuration, real credentials or deployment were changed.
