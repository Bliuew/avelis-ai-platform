# Product browsing and connected workspaces review v9 - not deployed

This build starts from the uploaded Avezqi_Render_Deploy.zip v5. The supplied homepage/brand compositions, campaign imagery, logos, fonts and colours remain, with navigation additions and device content inside Naëqo's existing product area. It does not claim pixel-identical layouts after adding navigation. Versions 7–8 add an isolated investor walkthrough, a separate example-session table, shared CSV calculation and genuine Naëqo customer enquiries with authorized operations. Authentication requirements, mail configuration and production were not changed.

## What opens now
- Naëqo: manufacturer catalog, Apple/Samsung/Google destinations, iPhone 17/Galaxy S25/Pixel 10 pages with actual manufacturer images and brief specifications; local search and comparison; connectivity/repair/warranty/support/roaming destinations. This is a selected three-model catalog, not all devices or confirmed stock. Prices and supply are not invented.
- Financing: an explicit user-input estimate calculator covering price, down payment, APR, term and upfront fees. Taxes/connectivity excluded. No lender, financing offer or credit decision is active.
- Mëvqi: all 16 cards open their detail pages. Working tools link to the existing authenticated workspace. Planned modules remain honestly identified.
- Avëzqi: all seven specialists have detail destinations; existing tools are linked without claiming the complete specialist roadmap works.
- Sharim: modular card category details, ways to pay, app/account scope and security information. Actual payment processing is not enabled.
- Vëqzi/Ëzqir: public capability information, proper navigation and restricted Ëzqir boundaries. No confidential architecture or working specialist security console is exposed.
- Six feature directories; mobile menu handlers; repaired empty anchors and fragment destinations. Public pages contain no development-phase labels.

## Verification
Real FastAPI tests (installed environment) passed: product destinations, brand pages, release/scheduling, account security and customer signup. Consent Node tests passed. Route check: 69 brand/detail pages and 119 internal links/assets, including fragment targets. Provider mail is mocked in account tests.
Desktop browser checks: catalog rendering, actual product images, Apple and Google device navigation, Samsung search, multi-device comparison, Mëvqi Relations card, and financing estimates at zero and positive interest. Existing Chrome static preview was used; account forms were not submitted. Full mobile-device/accessibility testing and live email delivery remain outstanding.

Version 9 changes only app.js navigation entries and the brand-auth.js successful business-sign-in destination. Existing account submissions and backend authentication remain unchanged. app.html loads the shared workspace navigation extension and includes the existing authorized Naëqo operations link. server.py now includes the isolated walkthrough endpoints and extracts the existing CSV calculation into a shared function; the authenticated analysis route retains its access and persistence requirements. Existing sign-in/verification restrictions still apply; this build does not fix unconfigured live mail or persistent-hosting storage. Planned commercial services remain planned.

## Package and release
The outer archive keeps the name Avezqi_Render_Deploy.zip. It contains the inner Avezqi_Phase_I_Updated_Platform.zip, deployment Dockerfile and instructions. The outer Dockerfile reads Avezqi_Render_Deploy.zip, then unpacks its inner application archive, so Render cannot silently read the old sibling application ZIP.

FOR REVIEW ONLY. No push or deployment was made. Replacing the outer ZIP on an auto-deploying main branch will change production. Review before authorizing that action. /product-release.json identifies this static browsing build after an approved deployment.

Manufacturer specifications and image sources are recorded in DEVICE_IMAGE_SOURCES.json and linked on device pages. Images/names remain owned by their respective manufacturers; no authorized supplier agreement is claimed.
