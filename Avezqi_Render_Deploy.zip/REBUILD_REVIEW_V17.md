# Rebuild review v17 · founder administration
Not deployed by this file.
- Founder administration at /founder/: owner sign-in plus authenticator-app code (TOTP) on every new session; requests and enquiries with approve/reject; approval creates a single-use, expiring invitation code tied to the email and the chosen platforms (emailed when email is configured, otherwise shown once to copy); invitation list with revoke; organizations with platform permissions enforced by the server; users with suspend/restore (ends sessions, blocks sign-in); activity log and alerts; demo session reset.
- Every public brand (Avëzqi, Mëvqi, Naëqo, Vëqzi, Sharim) has Sign in, Sign up, Sign up with invitation code and Request access, in the page and the header. Ëzqir stays private.
- Each brand homepage shows its design screens ("See … in action") with links to all screens and the PDF.
- Design collections updated with all four account options: 178 screens.
- Deployment is split into Avezqi_Render_Deploy.zip and Avezqi_Part_2_Designs.zip; the Dockerfile combines them.
- New test: tests/test_v17_founder.py. All tests pass.
