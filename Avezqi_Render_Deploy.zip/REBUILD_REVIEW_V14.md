# Rebuild review v14 · security checklist
Builds on v13. Not deployed.
- Fixed: behind Render's proxy all visitors shared one rate-limit bucket (the server saw the proxy address). Now the real visitor address is used on Render (AVELIS_TRUST_PROXY overrides).
- Added: per-visitor burst limit on every API (300 reads / 60 writes per minute); blocking of source, config, database and dot-file paths; stronger CSP (object-src none, font-src, upgrade-insecure-requests), HSTS includeSubDomains, COOP and CORP headers; no server banner.
- Added .gitignore and .dockerignore (env files, databases, caches, keys).
- Removed unused legacy scripts: cookies.js, cookies.css, site.js.
- Already in place and now tested: no API docs, scrypt password hashing, HttpOnly/Secure/SameSite cookies, CSRF and origin checks, parameterized SQL, no CORS, no secrets.
- New test: tests/test_security_checklist.py. 20 Python test files pass.
