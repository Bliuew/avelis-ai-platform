'use strict';
(()=>{
 const key='avezqi.cookie-preferences.v2';let saved=null;
 try{const value=JSON.parse(localStorage.getItem(key));if(value&&value.version===2&&typeof value.analytics==='boolean'&&typeof value.marketing==='boolean')saved=value;}catch{}
 const panel=document.createElement('section');panel.className='cookie-panel';panel.hidden=!!saved;panel.setAttribute('aria-label','Cookie choices');
 panel.innerHTML='<div class="cookie-title"><span aria-hidden="true">🍪</span><h2>Your privacy. Your choice.</h2></div><p>Essential cookies keep your account secure. Optional analytics and marketing tracking are not currently installed. Your choices below are saved for this website; allowing them does not activate any tracking.</p><div class="cookie-preferences" hidden><label><input type="checkbox" checked disabled> Essential — always on</label><label><input id="cookie-analytics" type="checkbox"> Allow optional analytics</label><label><input id="cookie-marketing" type="checkbox"> Allow optional marketing</label></div><div class="cookie-buttons"><button type="button" data-choice="reject">Reject All</button><button type="button" data-choice="accept">Accept All</button><button type="button" data-choice="manage">Manage Preferences</button><button type="button" data-choice="save" hidden>Save preferences</button></div><a href="/privacy.html">Read the privacy notice</a><p class="cookie-storage-note" role="status"></p>';
 const open=document.createElement('button');open.type='button';open.className='cookie-settings-v2';open.textContent='🍪 Cookie settings';open.setAttribute('aria-expanded',String(!panel.hidden));
 (document.querySelector('footer')||document.body).append(open);document.body.append(panel);
 const analytics=panel.querySelector('#cookie-analytics'),marketing=panel.querySelector('#cookie-marketing'),details=panel.querySelector('.cookie-preferences');
 function show(){analytics.checked=!!saved?.analytics;marketing.checked=!!saved?.marketing;panel.hidden=false;details.hidden=false;panel.querySelector('[data-choice="save"]').hidden=false;open.setAttribute('aria-expanded','true');panel.querySelector('button').focus();}
 open.addEventListener('click',show);
 panel.addEventListener('click',event=>{
  const button=event.target.closest('[data-choice]');if(!button)return;const choice=button.dataset.choice;
  if(choice==='manage'){details.hidden=false;panel.querySelector('[data-choice="save"]').hidden=false;analytics.focus();return;}
  const preference={version:2,necessary:true,analytics:choice==='accept'||(choice==='save'&&analytics.checked),marketing:choice==='accept'||(choice==='save'&&marketing.checked),updatedAt:new Date().toISOString()};
  try{localStorage.setItem(key,JSON.stringify(preference));saved=preference;panel.hidden=true;open.setAttribute('aria-expanded','false');open.focus();window.dispatchEvent(new CustomEvent('avezqi:cookie-preferences',{detail:{...preference}}));}
  catch{panel.querySelector('.cookie-storage-note').textContent='Your browser could not save this choice. Optional tracking remains disabled. Allow website storage to keep your preference.';}
 });
})();
