import os,sys,tempfile,secrets,time
from pathlib import Path
os.environ['AVELIS_DEV']='1';os.environ['AVELIS_ORIGIN']='http://testserver';os.environ['AVELIS_DB']=str(Path(tempfile.mkdtemp())/'test.sqlite3')
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import server
from fastapi.testclient import TestClient
ORIGIN={'Origin':'http://testserver'}
def client():return TestClient(server.app,headers=ORIGIN)
def request(c,path,data,method='POST',expected=200):
    r=c.request(method,'/api/'+path,json=data)
    assert r.status_code==expected,(path,r.status_code,r.text);return r.json()
def user(c,email,org,invite=None):
    if invite is None:
        invite=secrets.token_urlsafe(24)
        with server.db() as db:db.execute('INSERT INTO invites VALUES(?,?,?,?,0)',(server.digest(invite),None,email,int(time.time())+3600))
    messages=[];send=server.send_notice
    def capture(recipient,subject,message):messages.append(message);return 'accepted_by_mail_server'
    server.send_notice=capture
    try:request(c,'register',dict(email=email,password='TestPassword2026!',name=email.split('@')[0],company=org,invite=invite))
    finally:server.send_notice=send
    import re
    token=re.search(r'#token=([A-Za-z0-9_-]+)',messages[-1]).group(1)
    request(c,'account/verify',{'token':token});request(c,'login',{'email':email,'password':'TestPassword2026!'})
    m=c.get('/api/me').json();c.headers['X-CSRF-Token']=m['csrf']; return m

def test_workflows():
    a=client(); b=client(); anon=client();m=user(a,'alice@example.com','Alpha');n=user(b,'bravo@example.com','Bravo')
    assert m['org']!=n['org'];assert anon.get('/api/records/contacts').status_code==401
    request(anon,'interest',dict(name='Test',company='Test company',email='lead@example.com',note='Interested',consent=True));
    with server.db() as c:assert c.execute('SELECT COUNT(*) FROM leads').fetchone()[0]==1
    contact=dict(name='Test Customer',company='Test Co',email='test@example.com',phone='+14165550100',status='Prospect',notes='Test')
    cid=request(a,'records/contacts',contact)['id'];assert b.get('/api/records/contacts').json()==[]
    request(b,'records/contacts/'+cid,contact,'PUT',404)
    request(a,'records/contacts/'+cid,{**contact,'status':'Qualified'},'PUT')
    request(a,'records/opportunities',dict(name='Deal',contact=cid,stage='Proposal',amount=100000,probability=75)); assert a.get('/api/overview').json()['weighted']==75000
    request(b,'records/opportunities',dict(name='Deal',contact=cid,stage='Proposal',amount=100000,probability=75),expected=404)
    integration=request(a,'records/integrations',dict(name='System test',system='API',owner='Test',status='Degraded',latency=123,notes='Manual test'))['id']; assert a.get('/api/overview').json()['issues']==1
    key=request(a,'integration-key/'+integration,{})['key'];request(b,'integration-key/'+integration,{},expected=404)
    telemetry=TestClient(server.app,headers={'Authorization':'Bearer '+key});request(telemetry,'ingest',dict(status='Healthy',latency=80,notes='Real telemetry test'));assert a.get('/api/overview').json()['issues']==0
    request(a,'integration-key/'+integration,{},'DELETE');request(telemetry,'ingest',dict(status='Healthy',latency=80),expected=401)
    request(a,'records/calls',dict(contact=cid,outcome='Connected',duration=40,transcript='Test note',next_step='Follow up'))
    flow=request(a,'records/flows',dict(name='Follow up',steps='Call customer\nReview proposal',status='Active'))['id'];assert request(a,'flow/'+flow+'/run',{})['tasks_created']==2;request(a,'flow/'+flow+'/run',{},expected=409)
    channel=request(a,'records/channels',dict(name='general',description='Team'))['id'];request(a,'records/messages',dict(channel=channel,text='Test shared message'))
    invite=request(a,'invite',dict(email='teammate@example.com'))['invite'];mate=client();tm=user(mate,'teammate@example.com','',invite);assert tm['org']==m['org'] and tm['role']=='member';assert mate.get('/api/records/messages').json()[0]['text']=='Test shared message';assert b.get('/api/records/messages').json()==[]
    request(mate,'invite',dict(email='no@example.com'),expected=403)
    request(mate,'records/tasks',dict(name='Test team task',assignee=m['id'],due='',status='Open',notes='Test'));assert a.get('/api/overview').json()['open_tasks']==3
    invoice=dict(customer=cid,description='Service',quantity=2,unit_price=1999,status='Issued',reference='');iid=request(a,'records/invoices',invoice)['id'];assert a.get('/api/overview').json()['outstanding']==3998
    request(a,'records/invoices/'+iid,{**invoice,'status':'Paid externally'},'PUT',400);request(a,'records/invoices/'+iid,{**invoice,'status':'Paid externally','reference':'Test external settlement'},'PUT');assert a.get('/api/overview').json()['paid']==3998
    request(a,'records/invoices/'+iid,invoice,'PUT',409)
    report=request(a,'analyze',dict(name='test.csv',csv='latency,cost\n10,20\n20,40\n30,60'));assert report['metrics'][0]['mean']==20 and report['metrics'][1]['total']==120;assert len(a.get('/api/records/reports').json())==1
    request(a,'analyze',dict(name='bad.csv',csv='a,b\n1,2,3'),expected=400)
    request(a,'ai',dict(prompt='Test',consent=True),expected=503)
    assert a.get('/api/audit').json();assert b.get('/api/audit').json()==[]
    assert a.post('/api/records/contacts',json=contact,headers={'Origin':'https://other.example'}).status_code==403
    orig=a.headers['X-CSRF-Token'];a.headers['X-CSRF-Token']='invalid';request(a,'records/contacts',contact,expected=403);a.headers['X-CSRF-Token']=orig
    request(a,'logout',{});assert a.get('/api/me').status_code==401
    request(a,'login',dict(email='alice@example.com',password='TestPassword2026!'));assert a.get('/api/records/contacts').json()[0]['status']=='Qualified'
    assert a.get('/').status_code==200 and a.get('/app.html').status_code==200 and a.get('/explore.html').status_code==404
    print('PASS: lead registration, account sign-in and persistence, tenant isolation, ID reference isolation, CRM, weighted forecast, manual integration health, call records, workflow duplicate protection, shared messaging, invitations and permissions, tasks, invoice calculation/locks, CSV statistics, AI unconfigured behavior, audit, CSRF/origin, logout, telemetry authentication/revocation, public route separation.')
if __name__=='__main__':test_workflows()
