from test_app import client,user,request,server
from concurrent.futures import ThreadPoolExecutor
import time

def run():
 owner=client();
 for root in ['/', '/ecosystem/']:
  home=owner.get(root);assert home.status_code==200 and 'href="/naeqo/"' in home.text and 'Naëqo' in home.text
 assert owner.get('/api/status').json()['release']=='avezqi-phase1-navigation-fix'
 person=user(owner,'release-owner@example.com','Release workspace');anon=client()
 for path,name in [('avezqi','Avëzqi'),('mevqi','Mëvqi'),('naeqo','Naëqo'),('sharim','Sharim'),('veqzi','Vëqzi'),('ezqir','Ëzqir')]:
  response=anon.get('/'+path+'/');assert response.status_code==200 and name in response.text
 assert anon.get('/app.html').status_code==200
 assert anon.get('/api/ama/schedule').status_code==401
 event=request(owner,'ama/events',dict(title='Release appointment',duration=30,link='https://example.com/approved'))['id']
 start=int(time.time())+10800
 request(owner,'ama/events/'+event+'/slots',dict(host=person['id'],start=start))
 def reserve(address):
  return client().post('/api/booking/'+event,json=dict(name='Synthetic release test',email=address,start=start,link='https://example.org/proposed',consent=True))
 with ThreadPoolExecutor(max_workers=2) as executor:
  result=list(executor.map(reserve,['first-release@example.com','second-release@example.com']))
 assert sorted(x.status_code for x in result)==[200,409]
 winner=next(x.json() for x in result if x.status_code==200)
 assert winner['meeting_link']=='https://example.com/approved'
 # Closing the page must not delete the booking; cancellation must restore availability on another open event.
 request(owner,'ama/bookings/'+winner['id'],dict(status='Cancelled',meeting_link=''))
 assert anon.get('/api/booking/'+event).json()['slots']==[start]
 # Reopen the same SQLite file through an independent connection: persisted records, not in-memory state.
 with server.db() as connection:
  assert connection.execute('SELECT status FROM ama_bookings WHERE id=?',(winner['id'],)).fetchone()['status']=='Cancelled'
 payload=dict(name='Synthetic applicant',company='Synthetic organization',email='release-interest@example.com',note='',consent=True)
 for product in ['Avëzqi','Mëvqi','Naëqo','Vëqzi','Sharim']:
  request(anon,'product-interest',{**payload,'product':product})
 request(anon,'product-interest',{**payload,'product':'Ëzqir'},expected=400)
 request(owner,'ama/events/'+event+'/close',{})
 assert anon.get('/api/booking/'+event).status_code==404
 print('PASS: six renamed brand routes, private scheduler authentication, competing bookings (one succeeds, one conflicts), approved-link boundary, cancellation, SQLite persistence, new product labels and no public Ëzqir enrollment.')
if __name__=='__main__':run()
