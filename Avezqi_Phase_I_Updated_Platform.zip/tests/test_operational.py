from test_app import client, user, request, server
import time

def run():
 a=client();b=client();anon=client();ma=user(a,'owner2@example.com','Alpha 2');mb=user(b,'rival2@example.com','Bravo 2');mate=client();mt=user(mate,'staff2@example.com','',request(a,'invite',{'email':'staff2@example.com'})['invite'])
 ct=request(a,'records/contacts',dict(name='Individual client',company='',email='person@example.com',phone='',status='Prospect',notes=''))['id']
 request(a,'records/opportunities',dict(name='Individual campaign',contact=ct,stage='Discovery',amount=100000,probability=25))
 d=dict(spend=75000,revenue=900000,threshold=100000,period='October 2026',source='Authorized client report',ownership='Unassigned',preference='Interested',attempts=0)
 signal=request(a,'ama/signal/'+ct,d,'PUT');assert signal['classification']=='In Progress' and signal['roas']==12
 assert request(a,'ama/signal/'+ct,{**d,'preference':'Do not contact'},'PUT')['action']=='Do not contact'
 assert request(a,'ama/signal/'+ct,{**d,'ownership':'Other manager'},'PUT')['classification']=='Unqualified'
 assert request(a,'ama/signal/'+ct,{**d,'attempts':3},'PUT')['action']=='Pause — contact attempt limit'
 request(a,'ama/signal/'+ct,d,'PUT');request(b,'ama/signal/'+ct,d,'PUT',404);assert b.get('/api/ama/signal').json()==[]
 ev=request(a,'ama/events',dict(title='Discovery',duration=30,link='https://example.com/meeting'))['id'];request(mate,'ama/events',dict(title='Discovery',duration=30,link=''),expected=403)
 t=int(time.time())+7200
 for host in (ma['id'],mt['id']):request(a,'ama/events/'+ev+'/slots',dict(host=host,start=t))
 request(a,'ama/events/'+ev+'/slots',dict(host=mb['id'],start=t),expected=400)
 assert anon.get('/api/booking/'+ev).json()==dict(title='Discovery',duration=30,slots=[t]);assert b.get('/api/ama/schedule').json()['events']==[]
 dat=dict(name='Individual client',email='person@example.com',start=t,link='https://example.org/client-zoom',consent=True)
 first=request(anon,'booking/'+ev,dat);assert first['email_status']=='not_configured';assert first['meeting_link']=='https://example.com/meeting'
 assert a.get('/api/ama/signal').json()[0]['classification']=='Completed'
 request(anon,'booking/'+ev,dat,expected=409)
 second=request(anon,'booking/'+ev,{**dat,'email':'other@example.com','name':'Second client'});assert first['host']!=second['host'];assert anon.get('/api/booking/'+ev).json()['slots']==[]
 request(anon,'booking/'+ev,{**dat,'email':'third@example.com'},expected=409)
 request(b,'ama/bookings/'+first['id'],dict(status='Cancelled',meeting_link=''),expected=404)
 request(a,'ama/bookings/'+first['id'],dict(status='Booked',meeting_link='https://example.org/client-zoom'));assert a.get('/api/ama/schedule').json()['bookings']
 request(a,'ama/bookings/'+first['id'],dict(status='Cancelled',meeting_link=''));assert anon.get('/api/booking/'+ev).json()['slots']==[t]
 request(a,'ama/events/'+ev+'/close',{});assert anon.get('/api/booking/'+ev).status_code==404
 p=dict(name='Test',email='interest2@example.com',company='Team',note='',product='Kavéra',consent=True);assert request(anon,'product-interest',p)['email_status']=='not_configured';assert request(anon,'product-interest',p)['existing'];request(anon,'product-interest',{**p,'product':'Amā'})
 with server.db() as c:assert c.execute('SELECT COUNT(*) FROM product_requests WHERE email=?',(p['email'],)).fetchone()[0]==2
 print('PASS: individual opportunity, advertiser qualification/12x ROAS, contact preference/ownership, tenant isolation, real public scheduling, host balancing, overlapping bookings, meeting link approval, cancellation, closed page and product-specific requests.')
if __name__=='__main__':run()
