"""Run manually on the service host. Creates a private SQLite snapshot and verifies a restore."""
import argparse,os,sqlite3,tempfile
from pathlib import Path
parser=argparse.ArgumentParser();parser.add_argument('destination',type=Path);args=parser.parse_args()
source=Path(os.environ.get('AVELIS_DB','/app/data/avelis.sqlite3')).resolve()
if not source.is_file():raise SystemExit('Database source does not exist.')
if args.destination.exists():raise SystemExit('Choose a new destination; existing backups are never overwritten.')
args.destination.parent.mkdir(parents=True,exist_ok=True)
fd=os.open(args.destination,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600);os.close(fd)
try:
 with sqlite3.connect(source.as_uri()+'?mode=ro',uri=True) as src,sqlite3.connect(args.destination) as target:src.backup(target)
 with tempfile.TemporaryDirectory() as tmp:
  restored=Path(tmp)/'restored.sqlite3'
  with sqlite3.connect(args.destination) as backup,sqlite3.connect(restored) as check:
   backup.backup(check)
   if check.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise RuntimeError('Restore integrity check failed.')
   if check.execute('PRAGMA foreign_key_check').fetchone():raise RuntimeError('Restored foreign key integrity check failed.')
 print('Backup created with owner-only permissions; isolated restore integrity check passed. Protect and encrypt the backup before off-host retention.')
except Exception:
 args.destination.unlink(missing_ok=True)
 raise
