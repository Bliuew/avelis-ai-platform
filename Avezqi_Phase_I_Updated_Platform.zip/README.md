See [WEBSITE_REVIEW.md](WEBSITE_REVIEW.md) for the latest professional website, cookie, account and email-flow implementation review.

# Avëzqi — Phase I working release preparation

See [DEPLOYMENT_SCHEDULE.md](DEPLOYMENT_SCHEDULE.md) for the verified baseline, current functionality, outstanding dependencies, staging gates and production release sequence. This local preparation has not been pushed or deployed.

Internal configuration names and legacy API paths remain compatible; public branding uses the latest approved names.

---

# Editorial website upgrade — November 2026

This version replaces only the public home and marketing destinations, using the approved clickable design and original embedded brand artwork. The existing backend, database schema, invite-only authentication and workspace are retained byte-for-byte. Independent URL routes: /platform/, /ecosystem/, /security/, /tour/, /pricing/, /about/, /contact/, /early/, /access/, /avelis/, /ama/, /sharim/, /eziro/, /kavera/, /terms/, /privacy.html. /app.html remains the live beta workspace. The early access form uses the existing /api/interest endpoint.

See the previous technical instructions below. Deploy to a **staging test service first**. Do not redeploy a free instance holding data until you have a verified database backup. The separate outer Dockerfile used by the existing GitHub repository is retained; the inner Dockerfile can be used for conventional extracted-source builds but lacks the outer founder bootstrap.

# Avelis AI — Connected Enterprise Platform / private beta release

This project is a new server-backed app plus public landing page, **not a deployed production service**. The original GitHub Pages site is preserved byte-for-byte in `legacy/index.html` (current source commit `c1772a26597daf1e2e330764ba8dd38cf4d840ac`); public tour links reference the existing site at https://bliuew.github.io/avelis-ai/. Keep the existing investor URL unchanged. The archived demo is deliberately not served from the authenticated app origin.

## Quick start (local, Windows/macOS/Linux)

1. Install Python 3.13 if needed. Extract the archive. Open a terminal in this folder. Run `python -m venv .venv`. Activate it (Windows PowerShell `.\.venv\Scripts\Activate.ps1`; macOS/Linux `source .venv/bin/activate`). Run `python -m pip install -r requirements.txt`.
2. In a shell, set environment variables for **localhost only**. PowerShell: `$env:AVELIS_DEV='1'; $env:AVELIS_ORIGIN='http://127.0.0.1:8000'`. Bash: `export AVELIS_DEV=1 AVELIS_ORIGIN=http://127.0.0.1:8000`.
3. Generate a single-use, email-bound invite: `python server.py invite YOUR_BUSINESS_EMAIL` (replace placeholder). Save this invitation privately. It expires in 72 hours. It does not send email automatically.
4. Start `python server.py` and visit http://127.0.0.1:8000/ in a browser. Choose Sign in / Create an account, enter the invite and business email, a company name and a 12+ character password. The initial workspace is empty. Invite colleagues via Workspace settings. Users may belong to one organization in this release.
5. Create business contacts, opportunities, team tasks, integrations, channel messages and CSV reports. For test data only, use synthetic data. The SQLite file persists on disk. `python server.py leads` lists genuine early-access requests in the server terminal; restrict terminal access to the operator.

## Hosting (the remaining step)

**GitHub Pages cannot run Python or databases. Do not replace your existing `index.html` with this folder alone and expect sign-in or registration to work.** The new public site and private app are served together by the backend, on a separate HTTPS domain. Render is one possible host. A Dockerfile is supplied; do not deploy customer data to an ephemeral disk.

- Use the existing private Bliuew/avelis-ai-platform repository and a staging branch for this release; do not commit to main until validated. Never commit `.env`, database files, tokens, real prospect data or customer records. Keep the original public `avelis-ai` GitHub Pages repo unchanged until the new service is verified. Link to the new HTTPS hostname from the existing site after deployment; leave the old product tour on its own origin. Update public tour links if the earlier site moves to a dedicated legacy URL; do not redirect in a loop.
- Choose a hosting plan that supports a persistent writable volume, HTTPS and administrative shell access. Deploy one instance (SQLite). Mount persistent storage (for example `/app/data`; ensure UID 10001 can write there, or use a host-managed non-Docker service). Back up the database using SQLite's online backup API, and verify restores. No host account has been configured. Pricing/plan availability and storage costs need checking before purchase.
- Set `AVELIS_DB=/app/data/avelis.sqlite3`, `AVELIS_ORIGIN=https://YOUR-EXACT-APP-HOSTNAME`, and the host-assigned `PORT`. Do not enable `AVELIS_DEV` in hosted environments. Ensure the HTTPS reverse proxy rejects oversized requests, sets trusted proxy settings, and forwards only expected host names. Launch command `python server.py` (or supplied Dockerfile). Health endpoint `/api/status`. Do not add CORS; the app is same-origin.
- Use the host's administrative shell to generate the founder invitation and list leads. Real credentials must be configured by the account owner using host environment variables; never email or commit API keys. A paid plan or access may be necessary for persistent disks/shell access.
- Optional: configure `OPENAI_API_KEY` and `OPENAI_MODEL` with a model your account can access. The app makes an actual server-side Responses API request with explicit user consent, not a simulated output. Set provider usage limits. No live AI call was tested without credentials.
- Validate from a phone and desktop: apply for access, create separate test organizations, confirm tenant isolation, confirm logout, invite employee, message across accounts, create and edit records, upload CSV, run flows, check persistence after service restart, check backups, revoke telemetry key. Delete all test records/database before production onboarding. Maintain separate staging and production environments.

## Actual functionality

* Public professional website, server-persisted early access requests, email-bound invitations, login/password hashing, HTTP-only cookies, CSRF/origin validation, private organization scoping, owner/member roles, audit event list.
* Command Centre / Amā Insights: backend-computed counts, opportunity weighting, invoice totals, tasks and pipeline stage chart.
* Advisor: strict CSV parser, numerical-column statistics, report persistence, report JSON download. No raw CSV retention. Not AI-generated analysis.
* Integrations: human-maintained inventory plus actual push API. Owner generates a one-time-display bearer key for one record; external producer sends `POST /api/ingest`, `Authorization: Bearer <secret>`, `Content-Type: application/json`, body `{"status":"Healthy","latency":120,"notes":"Authorized health check"}`. Allowed status Healthy, Degraded, Offline. Regenerating/revoking invalidates previous key. Never place bearer keys in frontend code. Direct vendor adapters, alert scheduling and automatic monitoring are not included.
* Amā Discover: manual prospect management/search, not external verified data. Relations and Pipeline: contact management, customer linking and real opportunity forecasts. Connect & Coach: device dial links, interaction records/authorized transcript notes, not native VoIP or recording. AI can review a deliberately submitted excerpt when configured.
* Amā Link: persistent shared company channels; polls every four seconds. All organization members see all channels (not private channels/DMs); message-to-task action. Flow: actual on-demand task creation, no automatic emails, scheduled runs or calls. Teams: task assignment. Commerce: CAD invoices and externally recorded settlement references, no processing. Paid invoice locks.
* Sharim: separate Maarah module, concept link and clear non-operational payment status. Live payments, bank issuing and physical cards require separate agreements, provider setup, compliance and engineering. No real card numbers are accepted.

## Required before accepting confidential data or paid customers

Independent penetration/security review, dependency audit, production privacy policy/terms/support, account verification/recovery/MFA, member removal and granular role permissions, retention and deletion processes, encrypted storage/backups and key management, log access restrictions, quotas/pagination, concurrency/load tests, email delivery, monitoring/incident response, data residency decision, and review of privacy and call recording laws. Record queries presently return up to 5,000 rows per type; designed for small invited pilot workloads only. Audit events are not immutable regulatory logs. The app does not have subscriptions/billing, vendor-specific direct connectors, native VoIP, licensed prospecting data, or live payment processing. No claim of certification or compliance is made. Keep testing restricted to non-sensitive information until reviewed. The public hero illustration and screenshots are not customer metrics.

## Tests

`python -m pip install httpx` then `python tests/test_app.py` runs isolated server integration checks against a temporary database. See TEST_REPORT.md. The browser harness was run in the author environment using inline local assets and the actual server routes through TestClient, because direct browser navigation was restricted. A real host/browser end-to-end test (including HTTPS cookie transport) remains required.
