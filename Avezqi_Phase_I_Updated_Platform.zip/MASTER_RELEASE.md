# Avelis AI — unified operational Phase I

One gateway, individual product modules. Same repository and outer Dockerfile.

- Live: Bliuew/avelis-ai-platform, main, existing Render service. Leave untouched until staging validation and backup.
- Testing: create staging branch from main in the same repository. Upload this ZIP without extracting it to staging, with exactly the existing filename. Existing outer Dockerfile unpacks it. Use temporary Render Docker service linked to staging, health check /api/status and separate private environment variables. Never use production database or credentials in staging.
- Test with fictional data; free storage may disappear on restart or deploy. No real customers until persistent storage, verified backups, privacy/security review and appropriate infrastructure.
- Avelis AI: original approved public homepage and distinct brand pages; existing account/analytics/CRM and workspace backend. Your worlds is the new authenticated launcher.
- Amā: company-optional client opportunities, Signal eligibility and 12x ROAS rules, recorded contact preferences, booking links, explicit availability, balanced round-robin and customer-proposed meeting links, task and channel functions.
- Sharim: recorded external settlements and invoices only, not live or verified provider payments.
- Kavéra: product-specific early-access requests, optional SMTP email configuration (not tested with live provider), no identity provider yet. Ezirö: informational page only; private internal infrastructure not deployed.
- Future phases, not implemented: AI agent security, separate Ezirö and Kavéra identity systems, native WebRTC and carrier calls, live calendar/Gmail integration, licensed prospecting, Salesforce synchronization, full duplicate prevention and migration, advanced knowledge search, independent web and mobile apps, payment processing. Keep identity and financial infrastructure independently protected.
- Original six logo assets unchanged. No secrets or databases included. See OPERATIONAL_PHASE1.md for detailed tests, limitations and email settings.
- Local backend tests and JS syntax checks pass. New launcher, hosted deployment and real iPhone navigation require further validation.
