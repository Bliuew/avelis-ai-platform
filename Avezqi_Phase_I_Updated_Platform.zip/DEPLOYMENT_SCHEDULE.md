# Avëzqi Phase I — implementation and deployment schedule

This is a dependency-based release schedule, not a promise that all proposed services are launch-ready. No production deployment has been performed.

## Verified baseline

- Source: Bliuew/avelis-ai-platform, main commit ca81780e102d08bb3de869a65ca9c2daa8ee6bc4. The repository currently distributes an archive plus an outer Dockerfile. This working copy extracts the existing source and does not create a new archive.
- Local preparation branch: preparation/mevqi-schedule. This is an isolated extracted-source Git baseline, not a checkout whose local commits can be merged directly into GitHub main. The actual repository needs a reviewed migration to ordinary source files before publishing this build.
- Render workspace selected by Chinyere: Chinyere's workspace. Service: avelis-ai-platform, Docker, main branch, automatic deployment on commit, /api/status health check. API reports plan free. Persistent storage, backup coverage and restart durability are not verified.
- Original homepage composition retained, public names/logos updated. Approved realistic campaign assets are used on the new brand destinations. Desktop/mobile browser review remains outstanding.

## Release sequence

| Order | Deliverable | Current state | Exit requirement |
|---|---|---|---|
| 1 | Recover source and map working features | Complete locally | Source and Render configuration reviewed |
| 2 | New brand pages and compatible routes | Implemented locally | Browser review against approved PDF on phone and desktop |
| 3 | Mëvqi scheduling and core business workflows | Existing implementation retained; local regression tests pass | Independent staging test, concurrent booking checks, timezone and email acceptance |
| 4 | Persistence and recovery | Blocked pending hosting verification | Supported persistent storage or approved DB architecture; encrypted backups; restore and service-restart test |
| 5 | Isolated staging release | Not deployed | Separate service and DB, HTTPS origin, synthetic accounts, mail test destination, validated founder bootstrap |
| 6 | Release review | Pending | Approved visual design, successful functional checks, documented known limitations and rollback evidence |
| 7 | Production deployment | Pending release approval | Confirm exact tested commit, take verified backup, deploy, inspect /api/status and run post-deploy checks |
| 8 | Commercial/provider services | Separate future releases | Actual supplier, carrier, licensing, payment-provider and identity/security implementation requirements met |

No dates are invented. Calendar dates can be assigned once staging, persistence and the release scope have been confirmed. Customer-facing actions must not pretend unsupported services are working.

## What can be tested in this build

Invite-only accounts; organization-scoped contacts and opportunities; team tasks; shared company channels; CSV analysis and saved reports; on-demand task workflows; Signal/Respect; booking-page creation, explicit host availability, public appointment booking, automatic balancing among available hosts, owner-selected host through availability, approved meeting links, cancellation and completion. Invoices record externally evidenced settlement; they do not process payments.

Schedule uses UTC timestamps and device-local display/input. The owner publishes explicit slots. Native calling and external calendar synchronization are not connected. Mail is optional and requires real SMTP configuration; a saved booking is not evidence of successful email delivery. Failed email currently requires operational follow-up; no durable mail retry queue exists.

## Remaining feature boundaries

- Avëzqi: seven specialist capabilities remain preserved in design; existing CSV/statistics and configured AI calls do not establish all seven as operational.
- Mëvqi: current routes implement a subset of all sixteen modules. Fair, Clarity, Reverse, full Memory/Passage, automatic background Flow execution, and the exact approved Engage step labels are not complete. Contact preferences cannot block calls in an unconnected external carrier.
- Naëqo: plans, supplier targets, financing, repair/loaner operations, outages and credits require provider/supplier/regulatory arrangements and real implementations. No sale or SIM activation is enabled.
- Sharim: original modular-card concept and supported-method intentions remain intact. No payment processing, wallet provisioning or modular physical card engineering is implemented. Parent company Maarah remains independent.
- Ëzqir: no public registration. The new page describes a planned private service; the existing general workspace login does not implement the specialist security platform.
- Vëqzi: separate identity infrastructure, agent controls and standards integration are not implemented by these pages. No security certification is claimed.

## Staging configuration and checks

Use the extracted-source Dockerfile at this directory root after reviewed source migration. It copies server.py, bootstrap.py, requirements.txt and public/. It preserves the prior founder invite bootstrap behavior. Keep existing internal AVELIS_* configuration names, database tables and /api/ama/* endpoints compatible for this increment; do not run a destructive schema rename.

Configure AVELIS_ORIGIN to the exact HTTPS staging origin; AVELIS_DB to the verified mounted writable database path; AVELIS_DEV must be absent/disabled. Use one instance for the current SQLite architecture. Never expose provider keys or invitations in Git or frontend assets.

1. Provision an independent staging database and verify directory permissions for UID 10001.
2. Configure an owner invitation privately; confirm it does not reset an existing installation.
3. Run python tests/test_app.py, python tests/test_operational.py and python tests/test_release.py.
4. On HTTPS staging, test sign-in, cookie flags, tenant isolation, CSRF, booking creation and cancellation from desktop and phone.
5. Submit competing requests for the same host/time; exactly one must succeed. Review proposed meeting links before approving them.
6. Confirm SMTP status with authorized test mailboxes; no production customer messages during testing.
7. Run ops/backup_database.py with an approved private destination on the service host. Encrypt and retain backups according to the approved policy. Independently test restoring the staging service and check records after restart.
8. Verify /api/status; review all public links, responsive pages and visible working/planned claims.

## Rollback and production acceptance

Before production, retain the exact known-good source version, database backup and deployment ID. Roll back application code only when compatible with the current database. Never replace a database with an older snapshot without accounting for records created since that snapshot. No destructive data migration is included in this increment.

After release: check health; sign in; create a synthetic contact/task/booking; cancel the booking; verify tenant boundaries; check audit and mail status; verify restart persistence; confirm public pages and access restrictions. Record real results. Search-engine visibility and custom domains are a separate configuration task.

## Local validation limitations

Automated TestClient tests passed against temporary SQLite databases with synthetic accounts. Real Render deployment, container build, HTTPS cookie transport, browser layout, external SMTP delivery, restart durability, penetration testing and provider integrations have not been verified. A Starlette/httpx deprecation warning appears in this environment and should be addressed during dependency maintenance.
