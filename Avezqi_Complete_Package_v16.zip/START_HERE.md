# Avëzqi complete package (website v16)

1. GitHub (repository root): upload **Avezqi_Render_Deploy.zip** and **Dockerfile** from this folder, replacing the old ones. Do not rename or unzip Avezqi_Render_Deploy.zip. Committing starts a deploy if auto-deploy is on.
2. UI_UX_Design_PDFs: the nine design collections (Avëzqi, Mëvqi, Naëqo, Ëzqir, Vëqzi, Sharim, BioID, website accounts, founder administration). The same walkthroughs and PDFs are also on the website at /walkthroughs/.
3. DEPLOY_ON_RENDER.md: first owner code, email settings, security checklist and the OBSIDI rehearsal steps.
Nothing has been deployed. No passwords, keys or databases are included.
