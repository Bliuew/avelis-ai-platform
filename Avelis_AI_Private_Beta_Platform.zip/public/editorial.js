"use strict";
const menu=document.querySelector('.menu'), nav=document.querySelector('.navlinks');
menu?.addEventListener('click',()=>{const open=nav.classList.toggle('open');menu.setAttribute('aria-expanded',String(open));});
const form=document.querySelector('#interest');
if(form){const status=document.querySelector('#interest-status');const btn=form.querySelector('button');
(async()=>{try{const r=await fetch('/api/status',{cache:'no-store'});const d=await r.json();if(!r.ok||!d.online)throw Error();status.textContent='Applications are reviewed for invite-only access.';btn.disabled=false;}catch{status.textContent='Registration service is unavailable. Try again later.';}})();
form.addEventListener('submit',async e=>{e.preventDefault();btn.disabled=true;const d=Object.fromEntries(new FormData(form));d.consent=form.elements.consent.checked;try{const r=await fetch('/api/interest',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(d)});const x=await r.json();if(!r.ok)throw Error(x.detail||'Could not send request.');status.textContent='Request received. Thank you for your interest in Avelis AI.';status.className='success';form.reset();}catch(x){status.textContent=x.message;status.className='error';}finally{btn.disabled=false;}});}
